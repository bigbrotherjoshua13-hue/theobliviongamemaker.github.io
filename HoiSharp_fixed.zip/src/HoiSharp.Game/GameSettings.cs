using System.Globalization;

namespace HoiSharp.Game;

/// <summary>
/// Runtime settings (UI scale, etc.) persisted to data/user/settings.txt.
/// </summary>
public sealed class GameSettings
{
    public float UiScale { get; set; } = 1f;
    public bool ShowCityNames { get; set; } = true;
    public bool ShowHelpOnStart { get; set; } = true;
    public int MasterVolumePercent { get; set; } = 100; // reserved for later audio

    public const float MinUiScale = 0.75f;
    public const float MaxUiScale = 2.0f;

    private string? _path;

    public static GameSettings Load(string dataRoot)
    {
        var s = new GameSettings();
        s._path = Path.Combine(dataRoot, "user", "settings.txt");
        try
        {
            if (File.Exists(s._path))
            {
                foreach (var line in File.ReadAllLines(s._path))
                {
                    var t = line.Trim();
                    if (t.Length == 0 || t.StartsWith('#')) continue;
                    int eq = t.IndexOf('=');
                    if (eq <= 0) continue;
                    var key = t[..eq].Trim().ToLowerInvariant();
                    var val = t[(eq + 1)..].Trim();
                    switch (key)
                    {
                        case "ui_scale":
                            if (float.TryParse(val, NumberStyles.Float, CultureInfo.InvariantCulture, out var sc))
                                s.UiScale = Math.Clamp(sc, MinUiScale, MaxUiScale);
                            break;
                        case "show_city_names":
                            s.ShowCityNames = val is "1" or "true" or "yes";
                            break;
                        case "show_help_on_start":
                            s.ShowHelpOnStart = val is "1" or "true" or "yes";
                            break;
                        case "master_volume":
                            if (int.TryParse(val, out var v))
                                s.MasterVolumePercent = Math.Clamp(v, 0, 100);
                            break;
                    }
                }
            }
        }
        catch
        {
            // keep defaults
        }
        return s;
    }

    public void Save()
    {
        if (_path == null) return;
        try
        {
            var dir = Path.GetDirectoryName(_path);
            if (!string.IsNullOrEmpty(dir)) Directory.CreateDirectory(dir);
            File.WriteAllText(_path,
                "# HoiSharp settings\n" +
                $"ui_scale={UiScale.ToString("0.##", CultureInfo.InvariantCulture)}\n" +
                $"show_city_names={(ShowCityNames ? "true" : "false")}\n" +
                $"show_help_on_start={(ShowHelpOnStart ? "true" : "false")}\n" +
                $"master_volume={MasterVolumePercent}\n");
        }
        catch
        {
            // ignore write errors
        }
    }

    public void AdjustUiScale(float delta)
    {
        UiScale = Math.Clamp(UiScale + delta, MinUiScale, MaxUiScale);
    }
}
