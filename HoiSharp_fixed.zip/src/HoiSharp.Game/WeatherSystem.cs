using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;

namespace HoiSharp.Game;

public enum WeatherKind { Sunny, Rain, Storm }

/// <summary>
/// Lightweight 2D weather overlay: sunny, rainy or stormy. Changes every so often with a seasonal bias
/// (more rain in spring and autumn, mostly sunny in summer). Colours are premultiplied for SpriteBatch.
/// </summary>
public sealed class WeatherSystem
{
    private readonly record struct Drop(Vector2 Pos, Vector2 Vel, float Len, float Alpha);

    private readonly List<Drop> _drops = new();
    private readonly Random _rng = new(7);
    private WeatherKind _kind = WeatherKind.Sunny;
    private float _intensity;
    private int _lastMonth = -1;
    private float _switchTimer;
    private float _flash;          // lightning flash, 0..1
    private float _nextLightning = 4f;

    public WeatherKind Kind => _kind;
    public float Intensity => _intensity;

    public void Update(float dt, DateTime date, int viewW, int viewH)
    {
        int month = date.Month;
        if (month != _lastMonth)
        {
            _lastMonth = month;
            PickSeasonal(month);
        }

        _switchTimer -= dt;
        if (_switchTimer <= 0)
        {
            _switchTimer = 40f + (float)_rng.NextDouble() * 80f;
            PickSeasonal(month);
        }

        int targetCount = _kind switch
        {
            WeatherKind.Rain => (int)(180 * _intensity),
            WeatherKind.Storm => (int)(380 * _intensity),
            _ => 0,
        };

        while (_drops.Count < targetCount)
            _drops.Add(Spawn(viewW, viewH));
        while (_drops.Count > targetCount && _drops.Count > 0)
            _drops.RemoveAt(_drops.Count - 1);

        for (int i = 0; i < _drops.Count; i++)
        {
            var d = _drops[i];
            d = d with { Pos = d.Pos + d.Vel * dt };
            if (d.Pos.Y > viewH + 20 || d.Pos.X < -60 || d.Pos.X > viewW + 60)
                d = Spawn(viewW, viewH);
            _drops[i] = d;
        }

        // lightning only in storms
        _flash = MathF.Max(0f, _flash - dt * 3.5f);
        if (_kind == WeatherKind.Storm)
        {
            _nextLightning -= dt;
            if (_nextLightning <= 0)
            {
                _flash = 0.7f + (float)_rng.NextDouble() * 0.3f;
                _nextLightning = 5f + (float)_rng.NextDouble() * 12f;
            }
        }
    }

    private void PickSeasonal(int month)
    {
        double r = _rng.NextDouble();
        // chances of (rain, storm); everything else is sunny
        (double rain, double storm) = month switch
        {
            6 or 7 or 8 => (0.15, 0.10),
            3 or 4 or 5 or 9 or 10 or 11 => (0.35, 0.12),
            _ => (0.30, 0.08),
        };
        if (r < storm) Set(WeatherKind.Storm, 0.65f + (float)_rng.NextDouble() * 0.35f);
        else if (r < storm + rain) Set(WeatherKind.Rain, 0.4f + (float)_rng.NextDouble() * 0.4f);
        else Set(WeatherKind.Sunny, 0f);
    }

    private void Set(WeatherKind k, float intensity)
    {
        _kind = k;
        _intensity = Math.Clamp(intensity, 0f, 1f);
        _drops.Clear();
        _flash = 0f;
        _nextLightning = 3f + (float)_rng.NextDouble() * 5f;
    }

    private Drop Spawn(int w, int h)
    {
        bool storm = _kind == WeatherKind.Storm;
        return new Drop(
            new Vector2((float)_rng.NextDouble() * (w + 120) - 60, (float)_rng.NextDouble() * h),
            new Vector2((storm ? -120f : -40f) - (float)_rng.NextDouble() * 40f, (storm ? 620f : 420f) + (float)_rng.NextDouble() * 280f),
            (storm ? 14f : 10f) + (float)_rng.NextDouble() * 14f,
            0.25f + (float)_rng.NextDouble() * 0.35f);
    }

    public void Draw(SpriteBatch sb, Texture2D pixel, int viewW, int viewH)
    {
        if (_kind == WeatherKind.Sunny) return;

        // darkening sky tint (premultiplied: plain new Color(r, g, b, a) would add colour and wash the map out)
        var overlay = _kind == WeatherKind.Storm
            ? Color.FromNonPremultiplied(15, 20, 32, (int)(95 * _intensity))
            : Color.FromNonPremultiplied(35, 45, 62, (int)(50 * _intensity));
        sb.Draw(pixel, new Rectangle(0, 0, viewW, viewH), overlay);

        foreach (var d in _drops)
        {
            var col = new Color(180, 200, 220) * d.Alpha;
            var end = d.Pos + Vector2.Normalize(d.Vel) * d.Len;
            DrawLine(sb, pixel, d.Pos, end, col, _kind == WeatherKind.Storm ? 1.6f : 1.2f);
        }

        if (_flash > 0.01f)
            sb.Draw(pixel, new Rectangle(0, 0, viewW, viewH), Color.FromNonPremultiplied(230, 235, 255, (int)(110 * _flash)));
    }

    private static void DrawLine(SpriteBatch sb, Texture2D pixel, Vector2 a, Vector2 b, Color c, float thickness)
    {
        var d = b - a;
        float len = d.Length();
        if (len < 0.5f) return;
        sb.Draw(pixel, a, null, c, MathF.Atan2(d.Y, d.X), Vector2.Zero, new Vector2(len, thickness), SpriteEffects.None, 0f);
    }

    public string Label => _kind switch
    {
        WeatherKind.Rain => $"Rain ({(int)(_intensity * 100)}%)",
        WeatherKind.Storm => $"Storm ({(int)(_intensity * 100)}%)",
        _ => "Sunny",
    };
}
