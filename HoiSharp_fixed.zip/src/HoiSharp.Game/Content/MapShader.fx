// HoiSharp map shader (MonoGame DesktopGL / OpenGL, shader model 3.0)
//
// HOI4-inspired layering:
//   1. province id from index texture
//   2. LUT colours (political / terrain / flags / war...)
//   3. terrain tint + relief
//   4. animated water with specular shine + coastal foam
//   5. borders (province / state / country)
//   6. selection / hover

#if OPENGL
    #define SV_POSITION POSITION
    #define PS_SHADERMODEL ps_3_0
#else
    #define PS_SHADERMODEL ps_3_0
#endif

Texture2D SpriteTexture;
sampler2D SpriteTextureSampler = sampler_state
{
    Texture = <SpriteTexture>;
    MagFilter = Point;
    MinFilter = Point;
    MipFilter = Point;
    AddressU = Clamp;
    AddressV = Clamp;
};

Texture2D ColorLut;
sampler2D ColorLutSampler = sampler_state
{
    Texture = <ColorLut>;
    MagFilter = Point;
    MinFilter = Point;
    MipFilter = Point;
    AddressU = Clamp;
    AddressV = Clamp;
};

Texture2D InfoLut;
sampler2D InfoLutSampler = sampler_state
{
    Texture = <InfoLut>;
    MagFilter = Point;
    MinFilter = Point;
    MipFilter = Point;
    AddressU = Clamp;
    AddressV = Clamp;
};

Texture2D TerrainLut;
sampler2D TerrainLutSampler = sampler_state
{
    Texture = <TerrainLut>;
    MagFilter = Point;
    MinFilter = Point;
    MipFilter = Point;
    AddressU = Clamp;
    AddressV = Clamp;
};

float2 TexSize;
float Zoom;
float SelectedId;
float HoverId;
float Time;
float ReliefStrength;
float TerrainBlend;
float FlagMode; // 1 = flag-striped land fill

struct VertexShaderOutput
{
    float4 Position : SV_POSITION;
    float4 Color : COLOR0;
    float2 TextureCoordinates : TEXCOORD0;
};

float2 LutUV(float id)
{
    float row = floor(id / 256.0);
    float col = id - row * 256.0;
    return float2((col + 0.5) / 256.0, (row + 0.5) / 256.0);
}

float IdAt(float2 uv)
{
    float4 c = tex2D(SpriteTextureSampler, uv);
    return floor(c.r * 255.0 + 0.5) + floor(c.g * 255.0 + 0.5) * 256.0;
}

float Hash(float2 p)
{
    return frac(sin(dot(p, float2(127.1, 311.7))) * 43758.5453);
}

float Noise(float2 p)
{
    float2 i = floor(p);
    float2 f = frac(p);
    float2 u = f * f * (3.0 - 2.0 * f);
    float a = Hash(i);
    float b = Hash(i + float2(1.0, 0.0));
    float c = Hash(i + float2(0.0, 1.0));
    float d = Hash(i + float2(1.0, 1.0));
    return lerp(lerp(a, b, u.x), lerp(c, d, u.x), u.y);
}

float HeightAt(float2 px, float rough)
{
    return (Noise(px * 0.045) * 0.65 + Noise(px * 0.12) * 0.35) * rough;
}

float3 BorderTo(float id, float4 info, float2 uv)
{
    float nid = IdAt(uv);
    float4 ni = tex2D(InfoLutSampler, LutUV(nid));
    float differs = (abs(nid - id) > 0.5) ? 1.0 : 0.0;
    float stateDiff = ((abs(ni.g - info.g) + abs(ni.b - info.b)) > 0.001) ? 1.0 : 0.0;
    float countryDiff = (abs(ni.r - info.r) > 0.001) ? 1.0 : 0.0;
    return float3(differs, differs * stateDiff, differs * countryDiff);
}

float LandAt(float2 uv)
{
    float nid = IdAt(uv);
    float4 ni = tex2D(InfoLutSampler, LutUV(nid));
    return 1.0 - ni.a;
}

float4 MainPS(VertexShaderOutput input) : COLOR
{
    float2 uv = input.TextureCoordinates;
    float id = IdAt(uv);
    float2 luv = LutUV(id);
    float4 baseCol = tex2D(ColorLutSampler, luv);
    float4 info = tex2D(InfoLutSampler, luv);
    float4 terr = tex2D(TerrainLutSampler, luv);

    float isSea = (info.a > 0.5) ? 1.0 : 0.0;
    float2 px = uv * TexSize;

    // ---- land
    float3 land = lerp(baseCol.rgb, terr.rgb, TerrainBlend);
    land *= 0.94 + 0.12 * Hash(float2(id, id * 0.37));

    // Flag mode: soft vertical stripes like HOI4 flag-map feel
    if (FlagMode > 0.5 && isSea < 0.5)
    {
        float stripe = frac(px.x * 0.04 + Hash(float2(info.r * 255.0, 3.1)) * 10.0);
        float3 stripeCol = land * (0.75 + 0.45 * step(0.5, stripe));
        // diagonal sash
        float sash = abs(frac((px.x + px.y) * 0.02) - 0.5);
        stripeCol = lerp(stripeCol, float3(1.0, 1.0, 1.0), (1.0 - smoothstep(0.02, 0.06, sash)) * 0.25);
        land = lerp(land, stripeCol, 0.85);
    }

    float h0 = HeightAt(px, terr.a);
    float hx = HeightAt(px + float2(1.5, 0.0), terr.a);
    float hy = HeightAt(px + float2(0.0, 1.5), terr.a);
    float3 n = normalize(float3((h0 - hx) * ReliefStrength * 14.0, (h0 - hy) * ReliefStrength * 14.0, 1.0));
    float3 lightDir = normalize(float3(-0.5, -0.6, 0.65));
    float shade = saturate(dot(n, lightDir));
    land *= 0.72 + 0.5 * shade;

    // ---- sea: deep gradient + animated waves + specular shine + foam
    float deep = Noise(px * 0.015);
    float3 deepBlue = float3(0.02, 0.08, 0.18);
    float3 midBlue = float3(0.05, 0.18, 0.32);
    float3 seaBase = lerp(deepBlue, midBlue, deep);
    seaBase = lerp(seaBase, baseCol.rgb, 0.35);

    float wave = Noise(px * 0.08 + float2(Time * 0.25, Time * 0.15)) * 0.5
               + Noise(px * 0.20 - float2(Time * 0.20, 0.0)) * 0.5;
    float wave2 = Noise(px * 0.35 + float2(-Time * 0.4, Time * 0.1));
    float3 sea = seaBase * (0.88 + 0.22 * wave);

    // coastal shallows
    float r = 5.0;
    float shallow = (LandAt(uv + float2(r, 0.0) / TexSize)
                   + LandAt(uv - float2(r, 0.0) / TexSize)
                   + LandAt(uv + float2(0.0, r) / TexSize)
                   + LandAt(uv - float2(0.0, r) / TexSize)) * 0.25;
    sea = lerp(sea, sea * 1.25 + float3(0.04, 0.10, 0.10), shallow * 0.6);

    // specular shine (HOI4-style glints)
    float3 viewDir = float3(0.0, 0.2, 1.0);
    float3 halfV = normalize(lightDir + viewDir);
    float3 seaN = normalize(float3((wave - 0.5) * 0.8, (wave2 - 0.5) * 0.8, 1.0));
    float spec = pow(saturate(dot(seaN, halfV)), 48.0);
    float glint = pow(saturate(wave2), 6.0) * 0.35;
    sea += float3(0.45, 0.58, 0.72) * (spec * 0.45 + glint * 0.6);

    // foam line near coast
    float foam = smoothstep(0.15, 0.55, shallow) * (0.5 + 0.5 * wave2);
    sea = lerp(sea, float3(0.70, 0.80, 0.85), foam * 0.18);

    float3 col = lerp(land, sea, isSea);

    // ---- borders — trench-warfare style on country fronts
    float wProv = clamp(1.0 / Zoom, 0.5, 2.8);
    float wState = clamp(1.6 / Zoom, 0.8, 4.0);
    float wCountry = clamp(2.8 / Zoom, 1.4, 7.5);

    float jagged = (Noise(px * 0.35 + float2(Time * 0.02, 0.0)) - 0.5) * 1.8;
    float2 jOff = float2(jagged, -jagged) / TexSize;

    float2 oP = float2(wProv, wProv) / TexSize;
    float2 oS = float2(wState, wState) / TexSize;
    float2 oC = float2(wCountry, wCountry) / TexSize;

    float3 b = BorderTo(id, info, uv + float2(oP.x, 0.0));
    b = max(b, BorderTo(id, info, uv - float2(oP.x, 0.0)));
    b = max(b, BorderTo(id, info, uv + float2(0.0, oP.y)));
    b = max(b, BorderTo(id, info, uv - float2(0.0, oP.y)));

    float3 bS = BorderTo(id, info, uv + float2(oS.x, 0.0) + jOff * 0.4);
    bS = max(bS, BorderTo(id, info, uv - float2(oS.x, 0.0) - jOff * 0.4));
    bS = max(bS, BorderTo(id, info, uv + float2(0.0, oS.y) + jOff * 0.4));
    bS = max(bS, BorderTo(id, info, uv - float2(0.0, oS.y) - jOff * 0.4));

    // country trench: outer + inner ring (dual parapet)
    float3 bC = BorderTo(id, info, uv + float2(oC.x, 0.0) + jOff);
    bC = max(bC, BorderTo(id, info, uv - float2(oC.x, 0.0) - jOff));
    bC = max(bC, BorderTo(id, info, uv + float2(0.0, oC.y) + jOff));
    bC = max(bC, BorderTo(id, info, uv - float2(0.0, oC.y) - jOff));
    float2 oC2 = oC * 0.55;
    float3 bCinner = BorderTo(id, info, uv + float2(oC2.x, 0.0));
    bCinner = max(bCinner, BorderTo(id, info, uv - float2(oC2.x, 0.0)));
    bCinner = max(bCinner, BorderTo(id, info, uv + float2(0.0, oC2.y)));
    bCinner = max(bCinner, BorderTo(id, info, uv - float2(0.0, oC2.y)));

    float mudNoise = Noise(px * 0.55);
    float trenchMask = max(bC.z, bCinner.z);
    float3 mud = float3(0.18, 0.14, 0.09);
    float3 darkEarth = float3(0.06, 0.05, 0.04);
    float3 trenchCol = lerp(darkEarth, mud, mudNoise);

    float strength = b.x * lerp(0.18, 0.08, isSea);
    strength = max(strength, bS.y * 0.38);
    col = lerp(col, float3(0.08, 0.07, 0.06), strength);

    // wide mud scar + parapets
    col = lerp(col, trenchCol, trenchMask * (0.55 + 0.25 * mudNoise) * lerp(1.0, 0.35, isSea));
    col = lerp(col, float3(0.28, 0.24, 0.18), bCinner.z * 0.35 * (1.0 - isSea));
    col = lerp(col, darkEarth, bC.z * 0.55 * (1.0 - isSea));

    // sandbag ticks when zoomed in
    if (Zoom > 1.2 && trenchMask > 0.5 && isSea < 0.5)
    {
        float dash = step(0.55, frac(px.x * 0.15 + px.y * 0.11 + mudNoise));
        col = lerp(col, float3(0.35, 0.30, 0.22), dash * trenchMask * 0.4);
    }

    // ---- selection / hover
    float isSel = (abs(id - SelectedId) < 0.5) ? 1.0 : 0.0;
    float isHov = (abs(id - HoverId) < 0.5) ? 1.0 : 0.0;
    col = lerp(col, float3(1.0, 1.0, 1.0), isSel * 0.30 + isHov * 0.14);
    col = lerp(col, float3(1.0, 0.85, 0.15), isSel * b.x * 0.9);

    return float4(col, 1.0);
}

technique SpriteDrawing
{
    pass P0
    {
        PixelShader = compile PS_SHADERMODEL MainPS();
    }
};
