// HoiSharp 2.5D map shader: curved heightfield + lighting + fog + soft specular.

#if OPENGL
    #define SV_POSITION POSITION
    #define VS_SHADERMODEL vs_3_0
    #define PS_SHADERMODEL ps_3_0
#else
    #define VS_SHADERMODEL vs_3_0
    #define PS_SHADERMODEL ps_3_0
#endif

float4x4 WorldViewProjection;
float3 LightDir;
float3 CameraPos;
float3 FogColor;
float FogStart;
float FogEnd;
float CurveAmount; // 0 = flat, 1 = strong cylindrical bend
float MapWidth;
float HeightMul; // 1 = full relief, 0 = perfectly flat terrain mesh

Texture2D MapTexture;
sampler2D MapSampler = sampler_state
{
    Texture = <MapTexture>;
    MagFilter = Linear;
    MinFilter = Anisotropic;
    MipFilter = Linear;
    MaxAnisotropy = 8;
    AddressU = Clamp;
    AddressV = Clamp;
};

struct VSInput
{
    float4 Position : POSITION0;
    float3 Normal : NORMAL0;
    float2 UV : TEXCOORD0;
};

struct VSOutput
{
    float4 Position : SV_POSITION;
    float3 Normal : TEXCOORD1;
    float2 UV : TEXCOORD0;
    float Dist : TEXCOORD2;
    float3 WorldPos : TEXCOORD3;
};

VSOutput MainVS(VSInput input)
{
    VSOutput o;
    float4 pos = input.Position;
    // flatten mountains when HeightMul ~ 0 (sideways pan without terrain blocking)
    pos.y *= HeightMul;
    float3 nrm = input.Normal;
    if (HeightMul < 0.05)
        nrm = float3(0, 1, 0);

    // Cylindrical curve around X: drop Z toward the edges of the map
    if (CurveAmount > 0.001 && MapWidth > 1.0)
    {
        float nx = (pos.x / MapWidth) * 2.0 - 1.0; // -1..1
        float bend = nx * nx * CurveAmount * (MapWidth * 0.08);
        pos.z -= bend;
        nrm.x += nx * CurveAmount * 0.35;
        o.Normal = normalize(nrm);
    }
    else
    {
        o.Normal = normalize(nrm);
    }

    o.Position = mul(pos, WorldViewProjection);
    o.UV = input.UV;
    o.WorldPos = pos.xyz;
    o.Dist = distance(pos.xyz, CameraPos);
    return o;
}

float4 MainPS(VSOutput input) : COLOR
{
    float3 albedo = tex2D(MapSampler, input.UV).rgb;
    float3 n = normalize(input.Normal);
    float diffuse = saturate(dot(n, LightDir));
    float3 lit = albedo * (0.48 + 0.64 * diffuse);

    // soft specular (reads as water shine when albedo is blue-ish)
    float3 viewDir = normalize(CameraPos - input.WorldPos);
    float3 halfV = normalize(LightDir + viewDir);
    float spec = pow(saturate(dot(n, halfV)), 32.0);
    float waterHint = saturate((albedo.b - albedo.r) * 2.5);
    lit += float3(0.55, 0.70, 0.90) * spec * (0.25 + 0.75 * waterHint);

    float fog = saturate((input.Dist - FogStart) / (FogEnd - FogStart));
    return float4(lerp(lit, FogColor, fog * 0.85), 1.0);
}

technique Terrain
{
    pass P0
    {
        VertexShader = compile VS_SHADERMODEL MainVS();
        PixelShader = compile PS_SHADERMODEL MainPS();
    }
};
