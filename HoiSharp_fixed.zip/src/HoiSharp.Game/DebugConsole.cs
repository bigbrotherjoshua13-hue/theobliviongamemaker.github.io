#if DEBUG
using System.Text;
using HoiSharp.Core.Data;
using HoiSharp.Core.Sim;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;

namespace HoiSharp.Game;

/// <summary>
/// In-game debug console (DEBUG builds only). Toggle with ~ or F12.
/// </summary>
public sealed class DebugConsole
{
    private readonly GameWorld _world;
    private readonly MapData _map;
    private readonly Action<string> _log;
    private readonly StringBuilder _input = new();
    private readonly List<string> _history = new();
    private readonly List<string> _output = new() { "HoiSharp debug console — type help" };
    private int _historyIndex = -1;
    private KeyboardState _prev;

    public bool Open { get; set; }

    public DebugConsole(GameWorld world, MapData map, Action<string> log)
    {
        _world = world;
        _map = map;
        _log = log;
    }

    public void Toggle() => Open = !Open;

    public void HandleInput(KeyboardState ks)
    {
        if (!Open)
        {
            if (Pressed(ks, Keys.OemTilde) || Pressed(ks, Keys.F12))
                Open = true;
            _prev = ks;
            return;
        }

        if (Pressed(ks, Keys.OemTilde) || Pressed(ks, Keys.F12) || Pressed(ks, Keys.Escape))
        {
            Open = false;
            _prev = ks;
            return;
        }

        if (Pressed(ks, Keys.Enter))
        {
            string line = _input.ToString().Trim();
            _input.Clear();
            if (line.Length > 0)
            {
                _history.Add(line);
                _historyIndex = _history.Count;
                _output.Add("> " + line);
                Execute(line);
                while (_output.Count > 40) _output.RemoveAt(0);
            }
            _prev = ks;
            return;
        }

        if (Pressed(ks, Keys.Back) && _input.Length > 0)
            _input.Remove(_input.Length - 1, 1);

        if (Pressed(ks, Keys.Up) && _history.Count > 0)
        {
            _historyIndex = Math.Max(0, _historyIndex - 1);
            _input.Clear();
            _input.Append(_history[_historyIndex]);
        }
        if (Pressed(ks, Keys.Down) && _history.Count > 0)
        {
            _historyIndex = Math.Min(_history.Count, _historyIndex + 1);
            _input.Clear();
            if (_historyIndex < _history.Count)
                _input.Append(_history[_historyIndex]);
        }

        // character keys via Keys enum A-Z 0-9 space
        for (Keys k = Keys.A; k <= Keys.Z; k++)
            if (Pressed(ks, k))
                _input.Append((char)('a' + (k - Keys.A)));
        for (Keys k = Keys.D0; k <= Keys.D9; k++)
            if (Pressed(ks, k))
                _input.Append((char)('0' + (k - Keys.D0)));
        if (Pressed(ks, Keys.Space)) _input.Append(' ');
        if (Pressed(ks, Keys.OemMinus)) _input.Append('-');
        if (Pressed(ks, Keys.OemPeriod)) _input.Append('.');
        if (Pressed(ks, Keys.OemComma)) _input.Append(' ');

        _prev = ks;
    }

    private bool Pressed(KeyboardState ks, Keys k) => ks.IsKeyDown(k) && _prev.IsKeyUp(k);

    private void Out(string s) => _output.Add(s);

    private void Execute(string line)
    {
        var parts = line.Split(' ', StringSplitOptions.RemoveEmptyEntries);
        if (parts.Length == 0) return;
        string cmd = parts[0].ToLowerInvariant();

        try
        {
            switch (cmd)
            {
                case "help":
                    Out("help | clear | pause | speed N | date YYYY-MM-DD");
                    Out("tag TAG | observe | manpower N | money N | war TAG | peace TAG");
                    Out("annex STATE_ID | form TAG | release TAG | army TYPE | killarmies");
                    Out("fronts | wars | eval (status dump)");
                    break;
                case "clear":
                    _output.Clear();
                    break;
                case "pause":
                    Out("Use Space in-game to toggle pause (console cannot bind Game.Paused).");
                    break;
                case "speed":
                    if (parts.Length > 1 && int.TryParse(parts[1], out int sp))
                        Out($"Set speed via +/- keys (requested {sp}).");
                    break;
                case "date":
                    if (parts.Length > 1 && DateTime.TryParse(parts[1], out var dt))
                    {
                        _world.SetDate(dt);
                        Out("Date set to " + dt.ToString("yyyy-MM-dd"));
                    }
                    break;
                case "tag":
                    if (parts.Length > 1)
                    {
                        string t = parts[1].ToUpperInvariant();
                        if (_map.CountryOf(t) != null)
                        {
                            _world.SetPlayer(t);
                            if (!_world.HumanTags.Contains(t)) _world.HumanTags.Add(t);
                            Out("Playing as " + t);
                        }
                        else Out("Unknown tag " + t);
                    }
                    break;
                case "observe":
                    _world.SetPlayer(null);
                    _world.HumanTags.Clear();
                    Out("Observe mode");
                    break;
                case "manpower":
                    if (_world.PlayerTag != null && parts.Length > 1 && long.TryParse(parts[1], out long mp))
                    {
                        var c = _map.CountryOf(_world.PlayerTag)!;
                        c.ManpowerPool = mp;
                        Out("Manpower = " + mp);
                    }
                    break;
                case "money":
                    if (_world.PlayerTag != null && parts.Length > 1 && double.TryParse(parts[1], out double money))
                    {
                        var c = _map.CountryOf(_world.PlayerTag)!;
                        c.Treasury = money;
                        Out("Treasury = " + money);
                    }
                    break;
                case "war":
                    if (_world.PlayerTag != null && parts.Length > 1)
                    {
                        bool ok = _world.DeclareWar(_world.PlayerTag, parts[1].ToUpperInvariant());
                        Out(ok ? "War declared" : "Could not declare war");
                    }
                    break;
                case "peace":
                    if (_world.PlayerTag != null && parts.Length > 1)
                    {
                        _world.MakePeace(_world.PlayerTag, parts[1].ToUpperInvariant());
                        Out("Peace attempted");
                    }
                    break;
                case "annex":
                    if (_world.PlayerTag != null && parts.Length > 1 && int.TryParse(parts[1], out int sid))
                    {
                        bool ok = _world.SetStateOwner(sid, _world.PlayerTag);
                        Out(ok ? "Annexed state " + sid : "Failed");
                    }
                    break;
                case "form":
                    if (_world.PlayerTag != null && parts.Length > 1)
                    {
                        var def = _world.AllFormables()
                            .FirstOrDefault(f => string.Equals(f.ResultTag, parts[1], StringComparison.OrdinalIgnoreCase)
                                              || string.Equals(f.Id, parts[1], StringComparison.OrdinalIgnoreCase));
                        if (def != null)
                            Out(_world.FormNation(_world.PlayerTag, def) ? "Formed " + def.Name : "Cannot form yet");
                        else Out("Unknown formable");
                    }
                    break;
                case "release":
                    if (_world.PlayerTag != null && parts.Length > 1)
                    {
                        bool ok = _world.ReleaseNation(_world.PlayerTag, parts[1].ToUpperInvariant(), asPuppet: true);
                        Out(ok ? "Released" : "Cannot release");
                    }
                    break;
                case "army":
                    if (_world.PlayerTag != null)
                    {
                        var type = parts.Length > 1 && Enum.TryParse<UnitType>(parts[1], true, out var ut)
                            ? ut : UnitType.Infantry;
                        int pid = _map.CountryOf(_world.PlayerTag)?.Capital ?? 0;
                        if (pid > 0)
                        {
                            _world.SpawnArmy(_world.PlayerTag, pid, type: type);
                            Out("Spawned " + type);
                        }
                    }
                    break;
                case "killarmies":
                    if (_world.PlayerTag != null)
                    {
                        int n = _world.Armies.RemoveAll(a => a.Owner == _world.PlayerTag);
                        Out("Removed " + n + " armies");
                    }
                    break;
                case "fronts":
                    Out("Wars: " + _world.Wars.Count);
                    break;
                case "wars":
                    foreach (var w in _world.Wars)
                        Out($"{w.Attacker} vs {w.Defender}  score A={w.AttackerScore:0} D={w.DefenderScore:0}");
                    if (_world.Wars.Count == 0) Out("(none)");
                    break;
                case "eval":
                    Out($"Date {_world.Date:yyyy-MM-dd}  Player {_world.PlayerTag ?? "none"}  Armies {_world.Armies.Count}");
                    break;
                default:
                    Out("Unknown command. Type help.");
                    break;
            }
        }
        catch (Exception ex)
        {
            Out("Error: " + ex.Message);
        }

        _log(line);
    }

    public void Draw(SpriteBatch sb, SpriteFont font, Texture2D pixel, int vw, int vh)
    {
        if (!Open) return;
        int h = Math.Min(vh / 3, 220);
        var panel = new Rectangle(0, vh - h, vw, h);
        sb.Draw(pixel, panel, new Color(0, 0, 0, 210));
        sb.Draw(pixel, new Rectangle(0, vh - h, vw, 2), new Color(180, 80, 80));

        float y = vh - h + 6;
        int start = Math.Max(0, _output.Count - 12);
        for (int i = start; i < _output.Count; i++)
        {
            sb.DrawString(font, _output[i], new Vector2(8, y), new Color(200, 230, 200));
            y += font.LineSpacing;
        }
        string prompt = "] " + _input + "_";
        sb.DrawString(font, prompt, new Vector2(8, vh - font.LineSpacing - 6), Color.White);
    }
}
#endif
