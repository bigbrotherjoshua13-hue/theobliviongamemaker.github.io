using System.Globalization;
using HoiSharp.Core;
using HoiSharp.Core.Data;
using HoiSharp.Core.Events;
using HoiSharp.Core.Focus;
using HoiSharp.Core.Modding;
using HoiSharp.Core.Multiplayer;
using HoiSharp.Core.Scenarios;
using HoiSharp.Core.Sim;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;

namespace HoiSharp.Game;

public sealed class HoiGame : Microsoft.Xna.Framework.Game
{
    private static readonly float[] DaysPerSecond = { 1f, 3f, 7f, 15f, 30f };

    private readonly LaunchOptions _options;
    private readonly GraphicsDeviceManager _graphics;

    private SpriteBatch _sb = null!;
    private SpriteFont _font = null!;
    private Texture2D _pixel = null!;
    private Effect _fx = null!;
    private Effect _fx3d = null!;
    private Map3DView? _view3d;
    private bool _mode3D;
    /// <summary>0 = classic 2D, 1 = 3D relief, 2 = 3D flat (no mountain blocking).</summary>
    private int _viewMode;
    private Texture2D? _menuBg;
    private readonly WeatherSystem _weather = new();

    private Gui _gui = null!;
    private readonly EventWindow _events = new();
    private List<ScriptedEvent> _eventList = new();

    private ModFileSystem _fs = null!;
    private MapData _map = null!;
    private GameWorld _world = null!;
    private MapRenderer _renderer = null!;
    private readonly Camera2D _cam = new();
    private FlagGenerator _flags = null!;
    private UnitVisuals _units = null!;
    private CitySprites _citySprites = null!;
    private MusicPlayer _music = null!;
#if DEBUG
    private DebugConsole? _debugConsole;
#endif
    private float _launcherCheckTimer;

    private KeyboardState _prevKeys;
    private MouseState _prevMouse;

    private enum Phase { MainMenu, Playing }
    private Phase _phase = Phase.MainMenu;
    private int _menuIndex;
    private static readonly string[] MenuItems =
    {
        "Play",
        "Observe World",
        "Scenario Builder",
        "Quit",
    };

    private bool _paused = true;
    private bool _observeMode;
    private int _speed = 2;
    private float _dayAccumulator;
    private bool _showHelp = true;
    private Frontlines? _frontlines;
    private bool _showFocusPanel;
    private bool _showConferencePanel;
    private bool _showSettings;
    private bool _showFormablePanel;

    private Army? _selectedArmy;
    private readonly List<(string text, float ttl)> _messages = new();

    private Scenario? _scenario;
    private ScenarioBuilder? _builder;
    private GameSettings _settings = null!;
    private NetSession? _net;
    private int _buildTypeIndex;

    private static readonly UnitType[] BuildCycle =
    {
        UnitType.Infantry, UnitType.Armor, UnitType.Artillery, UnitType.Mountaineer, UnitType.Militia,
        UnitType.Destroyer, UnitType.Cruiser, UnitType.Battleship, UnitType.Submarine,
        UnitType.Fighter, UnitType.Bomber, UnitType.CAS,
    };

    public HoiGame(LaunchOptions options)
    {
        _options = options;
        _graphics = new GraphicsDeviceManager(this)
        {
            PreferredBackBufferWidth = options.Width,
            PreferredBackBufferHeight = options.Height,
            IsFullScreen = options.Fullscreen,
            SynchronizeWithVerticalRetrace = true,
        };
        Content.RootDirectory = "Content";
        IsMouseVisible = true;
        Window.AllowUserResizing = true;
        Window.Title = "HoiSharp";
        _graphics.GraphicsProfile = GraphicsProfile.HiDef; // large (non power of two) textures and render targets
    }

    // ------------------------------------------------------------------ loading
    protected override void LoadContent()
    {
        HoiSharp.Core.Diagnostics.AppLog.Info("LoadContent: start");
        _sb = new SpriteBatch(GraphicsDevice);
        _font = Content.Load<SpriteFont>("Font");
        _fx = Content.Load<Effect>("MapShader");
        _fx3d = Content.Load<Effect>("Map3D");
        _pixel = new Texture2D(GraphicsDevice, 1, 1);
        _pixel.SetData(new[] { Color.White });

        _fs = ModFileSystem.Create(_options.DataRoot, _options.Mods);
        _gui = new Gui(GraphicsDevice, _pixel, _fs.Resolve);
        _eventList = ScriptedEvent.LoadAll(_fs);
        _settings = GameSettings.Load(_options.DataRoot);
        _showHelp = _settings.ShowHelpOnStart;
        HoiSharp.Core.Diagnostics.AppLog.Info("Loading map data...");
        _map = MapData.Load(_fs);
        HoiSharp.Core.Diagnostics.AppLog.Info($"Map data loaded: {_map.Provinces.Length - 1} provinces, {_map.States.Count} states");
        _scenario = LoadScenario();
        _world = new GameWorld(_map, _scenario?.StartDate ?? _options.StartDate);
        _world.Message += AddMessage;
        _world.ConferenceOpened += conf =>
        {
            _showConferencePanel = true;
            _showFocusPanel = false;
            _paused = true;
        };

        // national focus trees
        var trees = FocusLibrary.LoadAll(_fs);
        _world.SetFocusTrees(trees);

        // procedural / file flags
        _flags = new FlagGenerator(GraphicsDevice, _options.DataRoot);
        _units = new UnitVisuals(GraphicsDevice, _pixel);
        _citySprites = new CitySprites(GraphicsDevice);
        _music = new MusicPlayer();
        _music.Volume = (_settings?.MasterVolumePercent ?? 100) / 100f * 0.55f;
        _music.LoadFrom(_options.DataRoot);
        if (_music.CurrentTrack != null)
            AddMessage($"Soundtrack: {_music.CurrentTrack}");

        foreach (var warning in ScenarioApplier.Apply(_map, _scenario).Take(3))
            AddMessage(warning);
        string tag = ChoosePlayer();
        _world.Initialize(tag, _scenario);

        var provincesPath = _fs.Resolve("map/provinces.png")
            ?? _fs.Resolve("map/provinces.bmp")
            ?? throw new FileNotFoundException("map/provinces.png (or .bmp) was not found. Run tools/mapgen.py or import HOI4 map.");
        _renderer = new MapRenderer(GraphicsDevice, _fx, _map, _world, provincesPath);
        _world.MapChanged += _renderer.MarkDirty;
        _frontlines = new Frontlines(_map, _world);
#if DEBUG
        _debugConsole = new DebugConsole(_world, _map, msg => AddMessage("[dbg] " + msg));
        AddMessage("DEBUG build — press ~ or F12 for console.");
#endif

        var heightPath = _fs.Resolve("map/heightmap.png") ?? Path.Combine(_options.DataRoot, "mod_base", "map", "heightmap.png");
        _view3d = new Map3DView(GraphicsDevice, _fx3d, heightPath, _renderer.Width, _renderer.Height);
        _viewMode = _options.Start3D ? 1 : 0;
        ApplyViewMode();

        // Menu always uses the BASE mod map preview (never HOI4 import provinces)
        try
        {
            string menuPath = Path.Combine(_options.DataRoot, "mod_base", "map", "preview_political.png");
            if (!File.Exists(menuPath))
                menuPath = Path.Combine(_options.DataRoot, "mod_base", "map", "provinces.png");
            if (File.Exists(menuPath))
            {
                using var fs = File.OpenRead(menuPath);
                _menuBg = Texture2D.FromStream(GraphicsDevice, fs);
            }
        }
        catch { /* optional */ }

        _builder = new ScenarioBuilder(_map, _world, _renderer, _scenario ?? new Scenario(), _options.DataRoot, AddMessage);
        Window.TextInput += (_, e) => _builder?.OnTextInput(e.Character);

        _cam.MapWidth = _renderer.Width;
        _cam.MapHeight = _renderer.Height;
        UpdateViewport();
        _cam.Zoom = Math.Max(Camera2D.MinZoom, _cam.ViewHeight / (float)_renderer.Height);
        _cam.Center = new Vector2(_renderer.Width * 0.5f, _renderer.Height * 0.5f);
        _view3d.UpdateCamera();

        Window.Title = "HoiSharp";
        AddMessage($"Loaded {_map.Provinces.Length - 1:N0} provinces, {_map.States.Count:N0} states, {_map.CountryList.Count} countries.");

        // skip menu if launched with builder / observe flags
        if (_options.Builder)
        {
            _builder.Active = true;
            _paused = true;
            EnterPlay(observe: false);
        }
        else if (_options.Observe)
            EnterPlay(observe: true);
        else
            _phase = Phase.MainMenu;
    }

    private void EnterPlay(bool observe)
    {
        _observeMode = observe;
        _phase = Phase.Playing;
        _paused = observe ? false : true;
        if (observe)
        {
            _world.SetPlayer(null);
            _world.HumanTags.Clear();
            Window.Title = "HoiSharp — Observe";
            AddMessage("Observe mode — watch the world. Esc returns to menu.");
            _showHelp = false;
        }
        else
        {
            string tag = ChoosePlayer();
            _world.SetPlayer(tag);
            if (!_world.HumanTags.Contains(tag)) _world.HumanTags.Add(tag);
            FocusCapital();
            var country = _map.CountryOf(tag);
            Window.Title = $"HoiSharp - {country?.Name ?? tag}"
                           + (_scenario != null ? $" - {_scenario.Name}" : "");
            AddMessage($"Playing as {country?.Name ?? tag}. Space to unpause.");
        }
        _frontlines?.MarkDirty();
    }

    private void ReturnToMenu()
    {
        _phase = Phase.MainMenu;
        _paused = true;
        _observeMode = false;
        if (_builder != null) _builder.Active = false;
        _showFocusPanel = false;
        _showConferencePanel = false;
        _showFormablePanel = false;
        _showSettings = false;
        Window.Title = "HoiSharp";
    }

    private void ApplyViewMode()
    {
        _mode3D = _viewMode >= 1;
        if (_view3d != null)
            _view3d.FlatTerrain = _viewMode == 2;
    }

    private string ChoosePlayer()
    {
        if (_options.PlayerTag != null && _map.Countries.ContainsKey(_options.PlayerTag))
            return _options.PlayerTag;
        if (_scenario?.Player != null && _map.CountryOf(_scenario.Player) is { } scenarioPlayer)
            return scenarioPlayer.Tag;
        if (_map.Countries.ContainsKey("USA")) return "USA";
        return _map.CountryList.OrderByDescending(c => c.Population).First().Tag;
    }

    private Scenario? LoadScenario()
    {
        if (string.IsNullOrWhiteSpace(_options.ScenarioId)) return null;

        var file = ScenarioLibrary.Find(_fs, _options.DataRoot, _options.ScenarioId);
        if (file == null)
        {
            AddMessage($"Scenario '{_options.ScenarioId}' was not found.");
            return null;
        }
        try
        {
            return Scenario.Load(file.Path);
        }
        catch (Exception ex)
        {
            AddMessage($"Could not read scenario '{file.Id}': {ex.Message}");
            return null;
        }
    }

    private void FocusCapital()
    {
        var c = _map.CountryOf(_world.PlayerTag);
        if (c == null) return;
        int pid = c.Capital;
        if (pid <= 0 || pid >= _map.Provinces.Length)
            pid = _map.StatesOf(c.Tag).SelectMany(s => s.Provinces).FirstOrDefault();
        if (pid <= 0) return;
        var p = _map.Provinces[pid];
        _cam.FocusOn(new Vector2(p.CenterX, p.CenterY), 1.6f);
        _view3d?.FocusOn(new Vector2(p.CenterX, p.CenterY), 700f);
        _renderer.SelectedProvince = pid;
    }

    private void UpdateViewport()
    {
        _cam.ViewWidth = GraphicsDevice.Viewport.Width;
        _cam.ViewHeight = GraphicsDevice.Viewport.Height;
    }

    private void AddMessage(string text) => _messages.Add((text, 8f));

    // ------------------------------------------------------------------ update
    protected override void Update(GameTime gameTime)
    {
        float dt = (float)gameTime.ElapsedGameTime.TotalSeconds;
        var keys = Keyboard.GetState();
        var mouse = Mouse.GetState();
        UpdateViewport();

        if (IsActive)
        {
#if DEBUG
            bool consoleOpen = _debugConsole?.Open == true;
#else
            bool consoleOpen = false;
#endif
            if (!consoleOpen)
            {
                if (_phase == Phase.MainMenu)
                    HandleMenuInput(keys);
                else
                    HandleInput(keys, mouse, dt);
            }
        }

        if (_phase == Phase.Playing && !_paused && _builder?.Active != true)
        {
            _dayAccumulator += dt * DaysPerSecond[_speed - 1];
            int guard = 0;
            while (_dayAccumulator >= 1f && guard++ < 8)
            {
                _world.TickDay();
                FireEvents();
                _frontlines?.MarkDirty();
                _dayAccumulator -= 1f;
            }
            if (guard >= 8) _dayAccumulator = 0f;
        }

        // drop selection of an army that no longer exists
        if (_selectedArmy != null && !_world.Armies.Contains(_selectedArmy)) _selectedArmy = null;

        _renderer.Update(dt);
        _music?.Update();
        _weather.Update(dt, _world?.Date ?? DateTime.Now, _cam.ViewWidth, _cam.ViewHeight);

        // Require launcher to stay open
        _launcherCheckTimer += dt;
        if (_launcherCheckTimer >= 2f)
        {
            _launcherCheckTimer = 0f;
            if (!LauncherGate.AllowBypass() && !LauncherGate.IsLauncherAlive())
            {
                AddMessage("Launcher closed — exiting.");
                Exit();
            }
        }

#if DEBUG
        if (IsActive)
            _debugConsole?.HandleInput(keys);
#endif
        // note: keys still assigned to _prevKeys below
        _view3d?.UpdateCamera();
        for (int i = _messages.Count - 1; i >= 0; i--)
        {
            var m = _messages[i];
            m.ttl -= dt;
            if (m.ttl <= 0) _messages.RemoveAt(i); else _messages[i] = m;
        }

        _prevKeys = keys;
        _prevMouse = mouse;
        base.Update(gameTime);
    }

    private void FireEvents()
    {
        foreach (var e in _eventList)
        {
            if (e.Fired || e.Date == null || _world.Date < e.Date.Value) continue;
            e.Fired = true;
            _events.Show(e);
            _paused = true;
        }
    }

    private void ApplyEvent(ScriptedOption o)
    {
        string? me = _world.PlayerTag;
        foreach (var fx in o.Effects)
        {
            switch (fx.Kind)
            {
                case "war" when me != null: _world.DeclareWar(me, fx.Arg.ToUpperInvariant()); break;
                case "peace" when me != null: _world.MakePeace(me, fx.Arg.ToUpperInvariant()); break;
                case "message": AddMessage(fx.Arg); break;
            }
        }
    }

    private bool Pressed(KeyboardState ks, Keys k) => ks.IsKeyDown(k) && _prevKeys.IsKeyUp(k);

    private void HandleInput(KeyboardState ks, MouseState ms, float dt)
    {
        // an open event window takes all input
        if (_events.Open)
        {
            var chosen = _events.HandleInput(ks, _prevKeys, ms, _prevMouse);
            if (chosen != null) ApplyEvent(chosen);
            return;
        }

        // while a text prompt of the scenario builder is open, it gets all the keys
        if (_builder != null && _builder.IsTyping)
        {
            _builder.HandleTypingKeys(ks, _prevKeys);
            return;
        }

        if (Pressed(ks, Keys.F2) && _builder != null)
        {
            _builder.Active = !_builder.Active;
            if (_builder.Active)
            {
                _paused = true;
                _renderer.SetMode(MapMode.Political);
            }
        }

        if (Pressed(ks, Keys.Escape))
        {
            if (_builder?.Active == true) _builder.Active = false;
            else if (_showSettings || _showFocusPanel || _showConferencePanel || _showFormablePanel || _showHelp)
            {
                _showSettings = false; _showFocusPanel = false;
                _showConferencePanel = false; _showFormablePanel = false; _showHelp = false;
            }
            else ReturnToMenu();
        }
        if (Pressed(ks, Keys.F1)) _showHelp = !_showHelp;
        if (Pressed(ks, Keys.F10) || Pressed(ks, Keys.O))
        {
            _showSettings = !_showSettings;
            if (_showSettings) { _showFocusPanel = false; _showConferencePanel = false; }
        }
        if (_showSettings)
        {
            if (Pressed(ks, Keys.OemPlus) || Pressed(ks, Keys.Add) || Pressed(ks, Keys.Up))
            { _settings.AdjustUiScale(0.1f); _settings.Save(); AddMessage($"UI scale: {_settings.UiScale:0.#}x"); }
            if (Pressed(ks, Keys.OemMinus) || Pressed(ks, Keys.Subtract) || Pressed(ks, Keys.Down))
            { _settings.AdjustUiScale(-0.1f); _settings.Save(); AddMessage($"UI scale: {_settings.UiScale:0.#}x"); }
            if (Pressed(ks, Keys.C))
            { _settings.ShowCityNames = !_settings.ShowCityNames; _settings.Save(); }
            if (Pressed(ks, Keys.H))
            { _settings.ShowHelpOnStart = !_settings.ShowHelpOnStart; _settings.Save(); }
            if (Pressed(ks, Keys.OemPlus) || Pressed(ks, Keys.Add))
            {
                // already used for UI scale above — skip
            }
            if (Pressed(ks, Keys.OemCloseBrackets))
            {
                _settings.MasterVolumePercent = Math.Min(100, _settings.MasterVolumePercent + 10);
                _settings.Save();
                if (_music != null) _music.Volume = _settings.MasterVolumePercent / 100f * 0.55f;
                AddMessage($"Music volume: {_settings.MasterVolumePercent}%");
            }
            if (Pressed(ks, Keys.OemOpenBrackets))
            {
                _settings.MasterVolumePercent = Math.Max(0, _settings.MasterVolumePercent - 10);
                _settings.Save();
                if (_music != null) _music.Volume = _settings.MasterVolumePercent / 100f * 0.55f;
                AddMessage($"Music volume: {_settings.MasterVolumePercent}%");
            }
            if (Pressed(ks, Keys.N))
            {
                _music?.Next();
                AddMessage($"Now playing: {_music?.CurrentTrack ?? "—"}");
            }
            if (Pressed(ks, Keys.M))
            {
                if (_music != null)
                {
                    _music.Enabled = !_music.Enabled;
                    AddMessage(_music.Enabled ? "Music on" : "Music muted");
                }
            }
        }
        if (Pressed(ks, Keys.F)) { _showFocusPanel = !_showFocusPanel; if (_showFocusPanel) { _showConferencePanel = false; _showSettings = false; _showFormablePanel = false; } }
        if (Pressed(ks, Keys.V))
        {
            _showFormablePanel = !_showFormablePanel;
            if (_showFormablePanel) { _showFocusPanel = false; _showConferencePanel = false; _showSettings = false; }
        }
        if (_showFormablePanel && _world.PlayerTag != null)
        {
            // 1-9 form available formables; Shift+1-9 release
            bool shift = ks.IsKeyDown(Keys.LeftShift) || ks.IsKeyDown(Keys.RightShift);
            var forms = _world.AvailableFormables(_world.PlayerTag);
            var releases = _world.GetReleasables(_world.PlayerTag);
            for (int i = 0; i < 9; i++)
            {
                if (!Pressed(ks, Keys.D1 + i)) continue;
                if (shift)
                {
                    if (i < releases.Count)
                    {
                        var r = releases[i];
                        _world.ReleaseNation(_world.PlayerTag, r.Tag, asPuppet: true, PuppetRank.Puppet);
                    }
                }
                else if (i < forms.Count)
                {
                    _world.FormNation(_world.PlayerTag, forms[i]);
                    _showFormablePanel = false;
                }
            }
            // U = release selected province's core tag as free nation
            if (Pressed(ks, Keys.U))
            {
                int selU = _renderer.SelectedProvince;
                var st = selU > 0 && selU < _map.Provinces.Length ? _map.States.GetValueOrDefault(_map.Provinces[selU].StateId) : null;
                if (st != null)
                {
                    var core = st.Cores.FirstOrDefault(c => !string.Equals(c, _world.PlayerTag, StringComparison.OrdinalIgnoreCase));
                    if (core != null)
                        _world.ReleaseNation(_world.PlayerTag, core, asPuppet: false);
                }
            }
        }
        if (Pressed(ks, Keys.K))
        {
            if (_world.ActivePlayerConference != null)
            {
                _showConferencePanel = !_showConferencePanel;
                if (_showConferencePanel) { _showFocusPanel = false; _paused = true; }
            }
            else
                AddMessage("No active peace conference.");
        }
        if (Pressed(ks, Keys.F3))
        {
            _viewMode = (_viewMode + 1) % 3;
            ApplyViewMode();
            AddMessage(_viewMode switch
            {
                1 => "3D relief view (F3 = flat 3D)",
                2 => "3D flat view — free sideways pan (F3 = 2D map)",
                _ => "Classic 2D map (F3 = 3D relief)",
            });
        }
        if (Pressed(ks, Keys.F4) && _mode3D)
        {
            // quick toggle flat vs relief while staying in 3D
            _viewMode = _viewMode == 2 ? 1 : 2;
            ApplyViewMode();
            AddMessage(_viewMode == 2 ? "3D flat (no mountain block)" : "3D relief");
        }

        // conference panel keys
        if (_showConferencePanel && _world.ActivePlayerConference is { } conf)
        {
            // 1-9 toggle demands
            for (int i = 0; i < 9; i++)
            {
                if (Pressed(ks, Keys.D1 + i) && i < conf.Demands.Count)
                {
                    if (!_world.ToggleDemand(conf, conf.Demands[i].StateId))
                        AddMessage("Not enough conference score for that demand.");
                }
            }
            // Enter = enforce peace
            if (Pressed(ks, Keys.Enter))
            {
                _world.ApplyConference(conf);
                _showConferencePanel = false;
            }
            // Backspace = white peace (select nothing)
            if (Pressed(ks, Keys.Back))
            {
                foreach (var d in conf.Demands) d.Selected = false;
                _world.ApplyConference(conf);
                _showConferencePanel = false;
            }
            // T = cycle action on first selected demand (Annex -> Puppet ranks -> Occupy)
            if (Pressed(ks, Keys.T))
            {
                var d = conf.Demands.FirstOrDefault(x => x.Selected) ?? conf.Demands.FirstOrDefault();
                if (d != null)
                {
                    if (d.Action == PeaceActionKind.Annex) { d.Action = PeaceActionKind.Occupy; }
                    else if (d.Action == PeaceActionKind.Occupy) { d.Action = PeaceActionKind.Puppet; d.PuppetRank = PuppetRank.Protectorate; }
                    else if (d.Action == PeaceActionKind.Puppet)
                    {
                        if (d.PuppetRank < PuppetRank.Integrated) d.PuppetRank++;
                        else { d.Action = PeaceActionKind.Annex; d.PuppetRank = PuppetRank.Puppet; }
                        // apply same rank to all puppet-selected demands
                        foreach (var o in conf.Demands.Where(x => x.Selected && x.Action == PeaceActionKind.Puppet))
                            o.PuppetRank = d.PuppetRank;
                    }
                    AddMessage($"Demand action: {d.Action}" + (d.Action == PeaceActionKind.Puppet ? $" ({GameWorld.RankName(d.PuppetRank)})" : ""));
                }
            }
        }

        // L = form alliance with selected province owner
        if (!_showConferencePanel && Pressed(ks, Keys.L))
        {
            string? allyPlayer = _world.PlayerTag;
            string? allyTarget = _map.OwnerOf(_renderer.SelectedProvince);
            if (allyPlayer != null && allyTarget != null && allyTarget != allyPlayer)
            {
                if (_world.AreAllied(allyPlayer, allyTarget))
                    AddMessage($"Already allied with {_map.CountryOf(allyTarget)?.Name}.");
                else if (_world.AtWar(allyPlayer, allyTarget))
                    AddMessage("Cannot ally while at war.");
                else if (_world.FormBilateralAlliance(allyPlayer, allyTarget))
                    AddMessage($"Alliance formed with {_map.CountryOf(allyTarget)?.Name}.");
                else
                    AddMessage("Could not form alliance.");
            }
        }
        if (Pressed(ks, Keys.F11))
        {
            _graphics.IsFullScreen = !_graphics.IsFullScreen;
            _graphics.ApplyChanges();
        }

        // time controls
        if (Pressed(ks, Keys.Space) && _builder?.Active != true) _paused = !_paused;
        if (!_showSettings)
        {
            if (Pressed(ks, Keys.OemPlus) || Pressed(ks, Keys.Add)) _speed = Math.Min(DaysPerSecond.Length, _speed + 1);
            if (Pressed(ks, Keys.OemMinus) || Pressed(ks, Keys.Subtract)) _speed = Math.Max(1, _speed - 1);
        }

        // map modes (or focus selection when panel is open)
        if (_showFocusPanel && _map.CountryOf(_world.PlayerTag) is { } pc)
        {
            var avail = _world.AvailableFocuses(pc).ToList();
            for (int i = 0; i < 9; i++)
            {
                if (Pressed(ks, Keys.D1 + i) && i < avail.Count)
                {
                    if (_world.StartFocus(pc.Tag, avail[i].Id))
                        _showFocusPanel = false;
                }
            }
        }
        else
        {
            if (!_showFormablePanel && !_showFocusPanel && !_showConferencePanel)
            {
                if (Pressed(ks, Keys.D1)) _renderer.SetMode(MapMode.Political);
                if (Pressed(ks, Keys.D2)) _renderer.SetMode(MapMode.Terrain);
                if (Pressed(ks, Keys.D3)) _renderer.SetMode(MapMode.States);
                if (Pressed(ks, Keys.D4)) _renderer.SetMode(MapMode.Manpower);
                if (Pressed(ks, Keys.D5)) _renderer.SetMode(MapMode.War);
                if (Pressed(ks, Keys.D6)) _renderer.SetMode(MapMode.Flags);
            }
        }

        // camera
        var dir = Vector2.Zero;
        if (ks.IsKeyDown(Keys.W) || ks.IsKeyDown(Keys.Up)) dir.Y -= 1;
        if (ks.IsKeyDown(Keys.S) || ks.IsKeyDown(Keys.Down)) dir.Y += 1;
        if (ks.IsKeyDown(Keys.A) || ks.IsKeyDown(Keys.Left)) dir.X -= 1;
        if (ks.IsKeyDown(Keys.D) || ks.IsKeyDown(Keys.Right)) dir.X += 1;
        var mousePos = new Vector2(ms.X, ms.Y);
        var mouseDelta = mousePos - new Vector2(_prevMouse.X, _prevMouse.Y);
        int wheel = ms.ScrollWheelValue - _prevMouse.ScrollWheelValue;

        if (_mode3D && _view3d != null)
        {
            if (dir != Vector2.Zero)
            {
                dir.Normalize();
                _view3d.Move(dir * (dt * 520f * _view3d.Distance / 700f));
            }
            if (ms.MiddleButton == ButtonState.Pressed)
            {
                if (ks.IsKeyDown(Keys.LeftShift) || ks.IsKeyDown(Keys.RightShift))
                {
                    _view3d.Yaw += mouseDelta.X * 0.006f;       // shift + middle drag = orbit
                    _view3d.Pitch += mouseDelta.Y * 0.004f;
                }
                else _view3d.Move(-mouseDelta * _view3d.PanScale);
            }
            if (wheel != 0) _view3d.Zoom(MathF.Pow(1.0016f, wheel));
            if (ks.IsKeyDown(Keys.Q) || ks.IsKeyDown(Keys.OemOpenBrackets)) _view3d.Yaw -= dt * 1.2f;
            if (ks.IsKeyDown(Keys.E) || ks.IsKeyDown(Keys.OemCloseBrackets)) _view3d.Yaw += dt * 1.2f;
            if (ks.IsKeyDown(Keys.PageUp)) _view3d.Pitch += dt * 0.9f;
            if (ks.IsKeyDown(Keys.PageDown)) _view3d.Pitch -= dt * 0.9f;
            if (Pressed(ks, Keys.Home)) FocusCapital();
        }
        else
        {
            if (dir != Vector2.Zero)
            {
                dir.Normalize();
                _cam.Center += dir * (900f * dt / _cam.Zoom);
                _cam.Clamp();
            }
            if (ms.MiddleButton == ButtonState.Pressed) _cam.Pan(mouseDelta);
            if (wheel != 0) _cam.ZoomAt(mousePos, MathF.Pow(1.0016f, wheel));
            if (Pressed(ks, Keys.Home)) FocusCapital();
        }

        // hover / selection
        bool inWindow = mousePos.X >= 0 && mousePos.Y >= 0 && mousePos.X < _cam.ViewWidth && mousePos.Y < _cam.ViewHeight;
        bool overHud = mousePos.Y < 36 * Ui;
        int hover = inWindow && !overHud ? _renderer.ProvinceAt(ScreenToWorld(mousePos)) : 0;
        _renderer.HoverProvince = hover;

        if (_builder != null && _builder.Active)
        {
            _builder.HandleInput(ks, _prevKeys, ms, _prevMouse, hover);
            return;
        }

        bool leftClick = ms.LeftButton == ButtonState.Pressed && _prevMouse.LeftButton == ButtonState.Released;
        bool rightClick = ms.RightButton == ButtonState.Pressed && _prevMouse.RightButton == ButtonState.Released;

        if (leftClick && hover != 0)
        {
            _renderer.SelectedProvince = hover;
            var own = _world.ArmiesIn(hover).Where(a => a.Owner == _world.PlayerTag).ToList();
            if (own.Count == 0) _selectedArmy = null;
            else
            {
                int at = _selectedArmy != null ? own.IndexOf(_selectedArmy) : -1;
                _selectedArmy = own[(at + 1) % own.Count]; // click again to cycle through stacked armies
            }
        }

        if (rightClick && _selectedArmy != null && hover != 0)
        {
            if (!_world.OrderMove(_selectedArmy, hover))
                AddMessage("No route there (blocked, at sea, or not at war with the owner).");
            else if (_paused)
                _paused = false;
        }

        if (Pressed(ks, Keys.C)) { _selectedArmy = null; }

        int sel = _renderer.SelectedProvince;
        string? player = _world.PlayerTag;
        string? selOwner = _map.OwnerOf(sel);

        if (Pressed(ks, Keys.OemOpenBrackets) || Pressed(ks, Keys.OemCloseBrackets))
        {
            int buildDir = Pressed(ks, Keys.OemCloseBrackets) ? 1 : -1;
            _buildTypeIndex = (_buildTypeIndex + buildDir + BuildCycle.Length) % BuildCycle.Length;
            _world.SelectedBuildType = BuildCycle[_buildTypeIndex];
            var ut = _world.SelectedBuildType;
            AddMessage($"Build type: {UnitStats.Label(ut)} (MP {UnitStats.ManpowerCost(ut)}, mil {UnitStats.FactoryCost(ut)})");
        }

        if (Pressed(ks, Keys.B) && player != null && sel > 0)
        {
            var a = _world.RaiseArmy(player, sel, _world.SelectedBuildType);
            if (a != null) { _selectedArmy = a; AddMessage($"Raised {a.Name}."); }
            else
            {
                var ut = _world.SelectedBuildType;
                AddMessage($"Cannot raise {UnitStats.Label(ut)} (need MP {UnitStats.ManpowerCost(ut)}, mil pts {UnitStats.FactoryCost(ut)}, correct terrain).");
            }
        }

        // G / M = build civilian / military factory in selected state's owner must be player
        if (player != null && sel > 0 && sel < _map.Provinces.Length)
        {
            int sid = _map.Provinces[sel].StateId;
            if (Pressed(ks, Keys.G) && sid != 0)
            {
                if (!_world.BuildFactory(player, sid, military: false))
                    AddMessage($"Need ~12 civ production (have {_map.CountryOf(player)?.CivProduction:0}).");
            }
            if (Pressed(ks, Keys.M) && sid != 0)
            {
                if (!_world.BuildFactory(player, sid, military: true))
                    AddMessage($"Need ~15 civ production (have {_map.CountryOf(player)?.CivProduction:0}).");
            }
        }

        // Tab = cycle hotseat human player
        if (Pressed(ks, Keys.Tab) && _world.HumanTags.Count > 1)
            _world.CycleHumanPlayer();

        // Multiplayer: F5 host, F6 join localhost (prototype)
        if (Pressed(ks, Keys.F5))
        {
            _net?.Dispose();
            _net = new NetSession { LocalName = _map.CountryOf(_world.PlayerTag)?.Name ?? "Host" };
            _net.Message += AddMessage;
            _net.StartHost(7777);
        }
        if (Pressed(ks, Keys.F6))
        {
            _net?.Dispose();
            _net = new NetSession { LocalName = _map.CountryOf(_world.PlayerTag)?.Name ?? "Client" };
            _net.Message += AddMessage;
            try { _net.Join("127.0.0.1", 7777); }
            catch (Exception ex) { AddMessage($"Join failed: {ex.Message}"); }
        }
        // Add selected country as human (hotseat)
        if (Pressed(ks, Keys.J) && player != null)
        {
            int s2 = _renderer.SelectedProvince;
            var o = _map.OwnerOf(s2);
            if (o != null) { _world.AddHumanPlayer(o); AddMessage($"{_map.CountryOf(o)?.Name} is now a human player (Tab to switch)."); }
        }

        // Y = form / cancel trade with selected country
        if (Pressed(ks, Keys.Y) && player != null)
        {
            var other = selOwner;
            if (other != null && other != player)
            {
                if (_world.HasTrade(player, other))
                    _world.CancelTrade(player, other);
                else if (!_world.FormTrade(player, other))
                    AddMessage("Cannot trade (at war or invalid).");
            }
        }

        if (!_showConferencePanel)
        {
            if (Pressed(ks, Keys.Enter) && player != null && selOwner != null && selOwner != player)
            {
                if (!_world.DeclareWar(player, selOwner)) AddMessage("Already at war with them.");
            }

            if (Pressed(ks, Keys.P) && player != null && selOwner != null && selOwner != player)
            {
                if (!_world.MakePeace(player, selOwner)) AddMessage("You are not at war with them.");
            }
        }
    }

    // ------------------------------------------------------------------ drawing
    protected override void Draw(GameTime gameTime)
    {
        float time = (float)gameTime.TotalGameTime.TotalSeconds;
        GraphicsDevice.Clear(new Color(12, 14, 20));

        if (_phase == Phase.MainMenu)
        {
            // Always the BASE political preview — never HOI4-import provinces
            _sb.Begin(SpriteSortMode.Deferred, BlendState.AlphaBlend, SamplerState.LinearClamp);
            int vw = GraphicsDevice.Viewport.Width, vh = GraphicsDevice.Viewport.Height;
            if (_menuBg != null)
            {
                // slow ken-burns style pan over base map
                float pan = 0.04f * MathF.Sin(time * 0.06f);
                float panY = 0.03f * MathF.Cos(time * 0.05f);
                int srcW = (int)(_menuBg.Width * 0.88f);
                int srcH = (int)(_menuBg.Height * 0.88f);
                int srcX = (int)((_menuBg.Width - srcW) * (0.5f + pan));
                int srcY = (int)((_menuBg.Height - srcH) * (0.5f + panY));
                _sb.Draw(_menuBg, new Rectangle(0, 0, vw, vh),
                    new Rectangle(srcX, srcY, srcW, srcH), new Color(200, 200, 205));
            }
            else
            {
                _sb.Draw(_pixel, new Rectangle(0, 0, vw, vh), new Color(18, 26, 40));
            }
            DrawMainMenu(time);
            _weather.Draw(_sb, _pixel, vw, vh);
            _sb.End();
            base.Draw(gameTime);
            return;
        }

        if (_mode3D && _view3d != null)
        {
            var flat = _renderer.GetFlatTexture(_sb, (float)gameTime.ElapsedGameTime.TotalSeconds);
            GraphicsDevice.Clear(ClearOptions.Target | ClearOptions.DepthBuffer, new Color(18, 26, 40), 1f, 0);
            _view3d.Draw(flat);
        }
        else _renderer.DrawMap(_sb, _cam);

        _sb.Begin(SpriteSortMode.Deferred, BlendState.AlphaBlend, SamplerState.LinearClamp);
        DrawFrontlines(time);
        DrawCities();
        DrawCountryLabels();
        if (_renderer.Mode == MapMode.Flags)
            DrawFlagStamps();
        DrawArmies();
        _weather.Draw(_sb, _pixel, _cam.ViewWidth, _cam.ViewHeight);
        DrawHud();
#if DEBUG
        _debugConsole?.Draw(_sb, _font, _pixel, _cam.ViewWidth, _cam.ViewHeight);
#endif
        _sb.End();

        base.Draw(gameTime);
    }

    private void HandleMenuInput(KeyboardState ks)
    {
        if (Pressed(ks, Keys.Up) || Pressed(ks, Keys.W))
            _menuIndex = (_menuIndex - 1 + MenuItems.Length) % MenuItems.Length;
        if (Pressed(ks, Keys.Down) || Pressed(ks, Keys.S))
            _menuIndex = (_menuIndex + 1) % MenuItems.Length;
        if (Pressed(ks, Keys.Enter) || Pressed(ks, Keys.Space))
            ActivateMenuItem(_menuIndex);
        if (Pressed(ks, Keys.D1)) ActivateMenuItem(0);
        if (Pressed(ks, Keys.D2)) ActivateMenuItem(1);
        if (Pressed(ks, Keys.D3)) ActivateMenuItem(2);
        if (Pressed(ks, Keys.D4) || Pressed(ks, Keys.Escape)) ActivateMenuItem(3);
    }

    private void ActivateMenuItem(int i)
    {
        switch (i)
        {
            case 0: EnterPlay(observe: false); break;
            case 1: EnterPlay(observe: true); break;
            case 2:
                EnterPlay(observe: false);
                if (_builder != null) { _builder.Active = true; _paused = true; }
                break;
            case 3: Exit(); break;
        }
    }

    private void DrawMainMenu(float time)
    {
        int vw = _cam.ViewWidth, vh = _cam.ViewHeight;
        // dark vignette panels
        _sb.Draw(_pixel, new Rectangle(0, 0, vw, vh), new Color(8, 10, 16, 160));
        int panelW = Math.Min(520, vw - 40);
        int panelH = 340;
        var panel = new Rectangle((vw - panelW) / 2, (vh - panelH) / 2 - 20, panelW, panelH);
        _sb.Draw(_pixel, panel, new Color(14, 16, 22, 230));
        _sb.Draw(_pixel, new Rectangle(panel.X, panel.Y, panel.Width, 3), new Color(180, 140, 60));
        _sb.Draw(_pixel, new Rectangle(panel.X, panel.Bottom - 2, panel.Width, 2), new Color(60, 50, 30));

        string title = "HOISHARP";
        string sub = "BATTLES OF POWER";
        float tScale = 2.2f;
        var tSize = _font.MeasureString(title) * tScale;
        var tPos = new Vector2(panel.X + (panel.Width - tSize.X) * 0.5f, panel.Y + 28);
        _sb.DrawString(_font, title, tPos + new Vector2(2, 2), new Color(0, 0, 0, 180), 0f, Vector2.Zero, tScale, SpriteEffects.None, 0f);
        _sb.DrawString(_font, title, tPos, new Color(240, 220, 160), 0f, Vector2.Zero, tScale, SpriteEffects.None, 0f);

        var sSize = _font.MeasureString(sub);
        _sb.DrawString(_font, sub, new Vector2(panel.X + (panel.Width - sSize.X) * 0.5f, tPos.Y + tSize.Y + 4),
            new Color(160, 150, 130));

        float y = panel.Y + 140;
        for (int i = 0; i < MenuItems.Length; i++)
        {
            bool sel = i == _menuIndex;
            string label = (sel ? "► " : "  ") + MenuItems[i];
            var col = sel ? new Color(255, 230, 140) : new Color(190, 195, 205);
            if (sel)
            {
                float pulse = 0.5f + 0.5f * MathF.Sin(time * 4f);
                _sb.Draw(_pixel, new Rectangle(panel.X + 40, (int)y - 2, panel.Width - 80, _font.LineSpacing + 4),
                    new Color(40, 35, 20) * (0.5f + 0.3f * pulse));
            }
            var sz = _font.MeasureString(label);
            _sb.DrawString(_font, label, new Vector2(panel.X + (panel.Width - sz.X) * 0.5f, y), col);
            y += _font.LineSpacing + 14;
        }

        string footer = "↑↓ / W S  select     Enter  confirm     Esc  quit";
        var fsz = _font.MeasureString(footer);
        _sb.DrawString(_font, footer, new Vector2((vw - fsz.X) * 0.5f, panel.Bottom + 16), new Color(140, 145, 155));
        if (_music?.CurrentTrack != null)
        {
            string track = "♪ " + _music.CurrentTrack;
            var tsz = _font.MeasureString(track);
            _sb.DrawString(_font, track, new Vector2((vw - tsz.X) * 0.5f, panel.Bottom + 36), new Color(120, 125, 140));
        }
    }

    private void DrawFrontlines(float time)
    {
        if (_frontlines == null) return;
        _frontlines.RebuildIfNeeded();
        if (_frontlines.Segments.Count == 0) return;

        float pulse = 0.55f + 0.45f * MathF.Sin(time * 3.2f);
        int mapW = _renderer.Width;

        foreach (var seg in _frontlines.Segments)
        {
            // slight perpendicular jitter for fluid feel
            var dir = seg.B - seg.A;
            float len = dir.Length();
            if (len < 1f) continue;
            dir /= len;
            var perp = new Vector2(-dir.Y, dir.X);
            float j = MathF.Sin(time * 2.1f + seg.A.X * 0.01f) * 3f;

            for (int k = _mode3D ? 0 : -1; k <= (_mode3D ? 0 : 1); k++)
            {
                var a = WorldToScreen(seg.A + new Vector2(k * mapW, 0) + perp * j);
                var b = WorldToScreen(seg.B + new Vector2(k * mapW, 0) - perp * j);
                if (a == null || b == null) continue;

                // trench: dark outer, bright inner pulse
                DrawLine(a.Value, b.Value, new Color(40, 28, 18, 220), 5f);
                DrawLine(a.Value, b.Value, new Color(180, 90, 40) * pulse, 2.2f);
                // dashed mid hash marks
                int steps = Math.Max(2, (int)(len / 18f));
                for (int s = 1; s < steps; s++)
                {
                    float t = s / (float)steps;
                    var mid = Vector2.Lerp(a.Value, b.Value, t);
                    var tick = perp * 4f;
                    DrawLine(mid - tick, mid + tick, new Color(90, 70, 40, 200), 1.5f);
                }
            }
        }
    }

    private Vector2 ScreenToWorld(Vector2 screen) =>
        _mode3D && _view3d != null ? _view3d.Pick(screen) : _cam.ScreenToWorld(screen);

    /// <summary>Screen position of a map pixel in the current view; null when it is not visible (3D only).</summary>
    private Vector2? WorldToScreen(Vector2 world) =>
        _mode3D && _view3d != null ? _view3d.Project(world) : _cam.WorldToScreen(world);

    private void DrawLine(Vector2 a, Vector2 b, Color c, float thickness)
    {
        var d = b - a;
        float len = d.Length();
        if (len < 0.5f) return;
        _sb.Draw(_pixel, a, null, c, MathF.Atan2(d.Y, d.X), Vector2.Zero, new Vector2(len, thickness), SpriteEffects.None, 0f);
    }

    private void DrawCities()
    {
        // dots/names at moderate zoom; full 2D city art only at ~500% zoom
        bool showNames = (_settings?.ShowCityNames ?? true) &&
            (_mode3D ? (_view3d?.Distance ?? 1000f) < 1200f : _cam.Zoom >= 0.7f);
        bool showDots = _mode3D ? (_view3d?.Distance ?? 1000f) < 2200f : _cam.Zoom >= 0.35f;
        bool showSprites = _mode3D
            ? (_view3d?.Distance ?? 1000f) < 280f
            : _cam.Zoom >= CitySprites.MinZoomForSprites;
        if (!showDots && !showSprites) return;

        int w = _renderer.Width;
        float spriteScale = _mode3D
            ? MathHelper.Clamp(220f / Math.Max(80f, _view3d?.Distance ?? 280f), 0.8f, 2.2f)
            : MathHelper.Clamp(_cam.Zoom / CitySprites.MinZoomForSprites, 1f, 2.5f);

        foreach (var city in _map.Cities)
        {
            if (city.ProvinceId <= 0 || city.ProvinceId >= _map.Provinces.Length) continue;
            var p = _map.Provinces[city.ProvinceId];
            bool coastal = p.Coastal;
            for (int k = _mode3D ? 0 : -1; k <= (_mode3D ? 0 : 1); k++)
            {
                var spn = WorldToScreen(new Vector2(p.CenterX + k * w, p.CenterY));
                if (spn == null) continue;
                var sp = spn.Value;
                if (sp.X < -40 || sp.Y < -40 || sp.X > _cam.ViewWidth + 40 || sp.Y > _cam.ViewHeight + 40) continue;

                var col = city.IsCapital ? new Color(255, 220, 100) : new Color(230, 230, 240);

                if (showSprites)
                {
                    var tex = _citySprites.Get(city.IsCapital, coastal);
                    int dw = (int)(tex.Width * spriteScale * (city.IsCapital ? 1.15f : 1f));
                    int dh = (int)(tex.Height * spriteScale * (city.IsCapital ? 1.15f : 1f));
                    var rect = new Rectangle((int)sp.X - dw / 2, (int)sp.Y - dh + 4, dw, dh);
                    _sb.Draw(tex, rect, Color.White);
                }
                else
                {
                    int size = city.IsCapital ? 6 : 4;
                    _sb.Draw(_pixel, new Rectangle((int)sp.X - size / 2, (int)sp.Y - size / 2, size, size), col);
                    if (city.IsCapital)
                        _sb.Draw(_pixel, new Rectangle((int)sp.X - 1, (int)sp.Y - size - 2, 2, size + 2), col);
                }

                if (showNames && (city.IsCapital || _cam.Zoom >= 1.1f || (_mode3D && (_view3d?.Distance ?? 1000f) < 800f)))
                {
                    string label = city.IsCapital ? "★ " + city.Name : city.Name;
                    float nameY = showSprites ? sp.Y + 4 : sp.Y - 6;
                    DrawText(label, new Vector2(sp.X + 8, nameY), col);
                }
            }
        }
    }

    private void DrawArmies()
    {
        int w = _renderer.Width;
        var stack = new Dictionary<int, int>();
        float scale = _mode3D
            ? MathHelper.Clamp(900f / Math.Max(200f, _view3d?.Distance ?? 1000f), 0.5f, 1.8f)
            : MathHelper.Clamp(_cam.Zoom * 1.1f, 0.5f, 2.0f);

        // path of the selected army
        if (_selectedArmy != null && _selectedArmy.Path.Count > 0)
        {
            var from = _map.Provinces[_selectedArmy.ProvinceId];
            var prev = WorldToScreen(new Vector2(from.CenterX, from.CenterY));
            foreach (int pid in _selectedArmy.Path)
            {
                var p = _map.Provinces[pid];
                var next = WorldToScreen(new Vector2(p.CenterX, p.CenterY));
                if (prev != null && next != null)
                {
                    var a = prev.Value; var b = next.Value;
                    if (!_mode3D)
                    {
                        float span = w * _cam.Zoom;
                        while (b.X - a.X > span * 0.5f) b.X -= span;
                        while (a.X - b.X > span * 0.5f) b.X += span;
                    }
                    DrawLine(a, b, new Color(255, 230, 80, 220), 2f);
                    next = b;
                }
                prev = next;
            }
        }

        foreach (var army in _world.Armies)
        {
            var p = _map.Provinces[army.ProvinceId];
            stack.TryGetValue(p.Id, out int n);
            stack[p.Id] = n + 1;
            var c = _map.CountryOf(army.Owner);
            if (c == null) continue;
            bool selected = army == _selectedArmy;

            for (int k = _mode3D ? 0 : -1; k <= (_mode3D ? 0 : 1); k++)
            {
                var spn = WorldToScreen(new Vector2(p.CenterX + k * w, p.CenterY));
                if (spn == null) continue;
                var sp = spn.Value + new Vector2(n * 6f, -n * 5f);
                if (sp.X < -50 || sp.Y < -50 || sp.X > _cam.ViewWidth + 50 || sp.Y > _cam.ViewHeight + 50) continue;
                _units.DrawCounter(_sb, _font, army, c, sp, scale, selected);
            }
        }
    }

    /// <summary>Country names at capital / centre of owned land (when zoomed in enough).</summary>
    private void DrawCountryLabels()
    {
        bool show = _mode3D ? (_view3d?.Distance ?? 1000f) < 2200f : _cam.Zoom >= 0.35f;
        if (!show) return;
        float textScale = _mode3D
            ? MathHelper.Clamp(700f / Math.Max(200f, _view3d?.Distance ?? 1000f), 0.55f, 1.2f)
            : MathHelper.Clamp(_cam.Zoom * 0.9f, 0.55f, 1.3f);

        foreach (var c in _map.CountryList)
        {
            int pid = c.Capital;
            if (pid <= 0 || pid >= _map.Provinces.Length) continue;
            var p = _map.Provinces[pid];
            if (!p.IsLand) continue;
            // only if still controlling capital
            if (p.Controller != null && p.Controller != c.Tag && _map.OwnerOf(pid) != c.Tag) continue;

            var spn = WorldToScreen(new Vector2(p.CenterX, p.CenterY));
            if (spn == null) continue;
            var sp = spn.Value;
            if (sp.X < -80 || sp.Y < -40 || sp.X > _cam.ViewWidth + 80 || sp.Y > _cam.ViewHeight + 40) continue;

            string name = c.Name.Length > 18 ? c.Name[..16] + "…" : c.Name;
            var size = _font.MeasureString(name) * textScale;
            var pos = new Vector2(sp.X - size.X * 0.5f, sp.Y - size.Y - 10f * textScale);
            // soft dark backdrop
            _sb.Draw(_pixel, new Rectangle((int)pos.X - 3, (int)pos.Y - 1, (int)size.X + 6, (int)size.Y + 2),
                new Color(0, 0, 0, 120));
            _sb.DrawString(_font, name, pos + new Vector2(1, 1), new Color(0, 0, 0, 180), 0f, Vector2.Zero, textScale, SpriteEffects.None, 0f);
            _sb.DrawString(_font, name, pos, new Color(245, 245, 250), 0f, Vector2.Zero, textScale, SpriteEffects.None, 0f);
        }
    }

    /// <summary>Stamp real flag textures on each nation's capital when in Flags map mode.</summary>
    private void DrawFlagStamps()
    {
        float scale = _mode3D
            ? MathHelper.Clamp(900f / Math.Max(200f, _view3d?.Distance ?? 1000f), 0.4f, 1.5f)
            : MathHelper.Clamp(_cam.Zoom * 0.85f, 0.4f, 1.6f);
        int fw = (int)(FlagGenerator.FlagW * scale * 1.4f);
        int fh = (int)(FlagGenerator.FlagH * scale * 1.4f);

        foreach (var c in _map.CountryList)
        {
            int pid = c.Capital;
            if (pid <= 0 || pid >= _map.Provinces.Length) continue;
            var p = _map.Provinces[pid];
            if (!p.IsLand) continue;
            var spn = WorldToScreen(new Vector2(p.CenterX, p.CenterY));
            if (spn == null) continue;
            var sp = spn.Value;
            if (sp.X < -fw || sp.Y < -fh || sp.X > _cam.ViewWidth + fw || sp.Y > _cam.ViewHeight + fh) continue;

            var flag = _flags.GetFlag(c);
            var rect = new Rectangle((int)sp.X - fw / 2, (int)sp.Y - fh / 2 - 6, fw, fh);
            _sb.Draw(_pixel, new Rectangle(rect.X - 1, rect.Y - 1, rect.Width + 2, rect.Height + 2), new Color(0, 0, 0, 180));
            _sb.Draw(flag, rect, Color.White);
        }
    }

    private float Ui => _settings?.UiScale ?? 1f;

    private void DrawText(string text, Vector2 pos, Color color)
    {
        float s = Ui;
        _sb.DrawString(_font, text, pos + new Vector2(s, s), new Color(0, 0, 0, 200), 0f, Vector2.Zero, s, SpriteEffects.None, 0f);
        _sb.DrawString(_font, text, pos, color, 0f, Vector2.Zero, s, SpriteEffects.None, 0f);
    }

    private float MeasureUi(string text) => _font.MeasureString(text).X * Ui;
    private float LineH => _font.LineSpacing * Ui;

    private static string ModeName(MapMode m) => m switch
    {
        MapMode.Political => "Political",
        MapMode.Terrain => "Terrain",
        MapMode.States => "States",
        MapMode.Manpower => "Manpower",
        MapMode.War => "War",
        MapMode.Flags => "Flags",
        _ => m.ToString(),
    };

    private void DrawHud()
    {
        int vw = _cam.ViewWidth, vh = _cam.ViewHeight;
        float s = Ui;
        var country = _map.CountryOf(_world.PlayerTag);

        // top bar (height scales)
        int barH = (int)(36 * s);
        _sb.Draw(_pixel, new Rectangle(0, 0, vw, barH), new Color(12, 16, 24, 220));

        float leftX = 10 * s;
        if (country != null)
        {
            var flag = _flags.GetFlag(country);
            int fw = (int)(FlagGenerator.FlagW * s), fh = (int)(FlagGenerator.FlagH * s);
            _sb.Draw(flag, new Rectangle((int)(8 * s), (int)(4 * s), fw, fh), Color.White);
            leftX = 8 * s + fw + 8 * s;
        }

        string leaderBit = country?.Leader != null ? $"{country.Leader.Title} {country.Leader.Name}  |  " : "";
        string capBit = country != null && country.Capitulation > 5 ? $"  Cap {country.Capitulation:0}%" : "";
        string left = country == null
            ? (_observeMode
                ? $"OBSERVE  |  Wars {_world.Wars.Count}  |  Fronts {_frontlines?.Segments.Count ?? 0}  |  Esc menu"
                : "")
            : $"{country.Name}  |  {leaderBit}MP {country.ManpowerPool:N0}  |  $ {country.Treasury:0} GDP {country.Gdp:0} ({country.EconomyPhase})  |  MilF {_world.TotalMilFactories(country.Tag)} CivF {_world.TotalCivFactories(country.Tag)}  |  [{UnitStats.Label(_world.SelectedBuildType)}]";
        DrawText(left, new Vector2(leftX, 8 * s), _observeMode ? new Color(180, 220, 255) : new Color(235, 235, 235));

        if (country?.ActiveFocusId != null)
        {
            var tree = _world.GetTree(country);
            string fname = tree?.ById.GetValueOrDefault(country.ActiveFocusId)?.Name ?? country.ActiveFocusId;
            DrawText($"Focus: {fname} ({country.FocusDaysRemaining}d)", new Vector2(leftX, 22 * s), new Color(180, 220, 255));
        }
        else if (country != null)
        {
            var enemies = _world.EnemiesOf(country.Tag).ToList();
            if (enemies.Count > 0)
            {
                string wsLine = "War score: " + string.Join(", ",
                    enemies.Take(3).Select(e =>
                    {
                        var en = _map.CountryOf(e);
                        return $"{en?.Name ?? e} {_world.WarScoreAgainst(country.Tag, e):0}";
                    }));
                DrawText(wsLine, new Vector2(leftX, 22 * s), new Color(255, 180, 140));
            }
        }

        string date = _world.Date.ToString("d MMM yyyy", CultureInfo.InvariantCulture);
        string speed = _paused ? "PAUSED" : $"Speed {_speed}";
        string mid = $"{date}   {speed}   {_weather.Label}";
        DrawText(mid, new Vector2((vw - MeasureUi(mid)) * 0.5f, 8 * s), _paused ? new Color(255, 190, 90) : new Color(235, 235, 235));

        string confHint = _world.ActivePlayerConference != null ? "  K=Conference!" : "";
        string viewName = _viewMode switch { 1 => " 3D", 2 => " 3D-flat", _ => "" };
        string right = $"Map: {ModeName(_renderer.Mode)}{viewName}   F=Focus{confHint}  O=Settings  F1=Help";
        DrawText(right, new Vector2(vw - MeasureUi(right) - 10 * s, 8 * s),
            _world.ActivePlayerConference != null ? new Color(255, 200, 80) : new Color(190, 205, 230));

        // selected province / army panel
        var lines = DescribeSelection();
        if (lines.Count > 0)
        {
            float lh = LineH;
            float width = lines.Max(MeasureUi) + 20 * s;
            float height = lines.Count * lh + 14 * s;
            var panel = new Rectangle((int)(10 * s), (int)(vh - height - 10 * s), (int)width, (int)height);
            _sb.Draw(_pixel, panel, new Color(12, 16, 24, 215));
            for (int i = 0; i < lines.Count; i++)
                DrawText(lines[i], new Vector2(panel.X + 10 * s, panel.Y + 7 * s + i * lh), i == 0 ? new Color(255, 230, 140) : new Color(225, 225, 225));
        }

        // messages
        float y = barH + 12 * s;
        foreach (var (text, ttl) in _messages.TakeLast(6))
        {
            float a = Math.Clamp(ttl / 2f, 0f, 1f);
            float tw = MeasureUi(text);
            _sb.Draw(_pixel, new Rectangle((int)(8 * s), (int)(y - 2 * s), (int)(tw + 14 * s), (int)(LineH + 4 * s)), new Color(12, 16, 24, (int)(170 * a)));
            DrawText(text, new Vector2(15 * s, y), Color.White * a);
            y += LineH + 6 * s;
        }

        if (_showFocusPanel) DrawFocusPanel(vw, vh);
        if (_showConferencePanel) DrawConferencePanel(vw, vh);
        if (_showSettings) DrawSettingsPanel(vw, vh);
        if (_showFormablePanel) DrawFormablePanel(vw, vh);
        if (_showHelp) DrawHelp(vw, vh);
        if (_builder != null && _builder.Active)
            _builder.DrawHud(_sb, _font, _pixel, vw, vh, _renderer.Time);
        DrawLeaderFrame(_map.CountryOf(_world.PlayerTag), vw);
        _events.Draw(_sb, _font, _pixel, _gui, vw, vh, _prevMouse);
    }

    /// <summary>Leader portrait frame (gui/leader_frame.png) with the country colour and name, top right under the bar.</summary>
    private void DrawLeaderFrame(Country? country, int vw)
    {
        if (country == null) return;
        var frame = new Rectangle(vw - 74 - 8, 44, 74, 84);
        var inner = Gui.Inner(frame);
        var c = new Color(country.R, country.G, country.B);
        _sb.Draw(_pixel, inner, c);
        var dark = Color.Lerp(c, Color.Black, 0.45f);
        _sb.Draw(_pixel, new Rectangle(inner.X + inner.Width / 2 - 11, inner.Y + 14, 22, 24), dark);
        _sb.Draw(_pixel, new Rectangle(inner.X + 8, inner.Y + 42, inner.Width - 16, inner.Height - 42), dark);
        _gui.DrawFrame(_sb, _gui.LeaderFrame, frame);
        var size = _font.MeasureString(country.Name);
        DrawText(country.Name, new Vector2(frame.X + (frame.Width - size.X) / 2f, frame.Bottom + 2), new Color(255, 230, 140));
    }

    private void DrawSettingsPanel(int vw, int vh)
    {
        float s = Ui;
        var lines = new List<string>
        {
            "Settings  (O / F10 to close)",
            "",
            $"UI Scale: {_settings.UiScale:0.#}x     [+ / - or Up / Down]",
            $"City names: {(_settings.ShowCityNames ? "ON" : "OFF")}     [C]",
            $"Show help on start: {(_settings.ShowHelpOnStart ? "ON" : "OFF")}     [H]",
            $"Music volume: {_settings.MasterVolumePercent}%     [ / ]",
            $"Track: {_music?.CurrentTrack ?? "—"}     [N] next  [M] mute",
            "",
            "Soundtrack: Collapsing World · Der Heilige Krieg · pathetic dancing nihilist",
            "Country borders use trench-warfare scarring.",
            "Saved to data/user/settings.txt",
        };
        float lh = LineH;
        float width = Math.Min(vw - 40 * s, lines.Max(MeasureUi) + 28 * s);
        float height = lines.Count * lh + 20 * s;
        var panel = new Rectangle((int)(20 * s), (int)(50 * s), (int)width, (int)height);
        _sb.Draw(_pixel, panel, new Color(14, 16, 22, 240));
        _sb.Draw(_pixel, new Rectangle(panel.X, panel.Y, panel.Width, 2), new Color(120, 160, 220));
        for (int i = 0; i < lines.Count; i++)
        {
            var col = i == 0 ? new Color(255, 220, 120) : new Color(210, 215, 225);
            DrawText(lines[i], new Vector2(panel.X + 12 * s, panel.Y + 10 * s + i * lh), col);
        }
    }

    private void DrawConferencePanel(int vw, int vh)
    {
        var conf = _world.ActivePlayerConference;
        if (conf == null) { _showConferencePanel = false; return; }

        var winner = _map.CountryOf(conf.Winner)?.Name ?? conf.Winner;
        var loser = _map.CountryOf(conf.Loser)?.Name ?? conf.Loser;
        int used = conf.Demands.Where(d => d.Selected).Sum(d => d.ScoreCost);

        var lines = new List<string>
        {
            $"Peace Conference — {winner} vs {loser}" + (conf.ForcedByCapitulation ? "  [CAPITULATION]" : ""),
            $"War score {conf.WinnerWarScore:0}  |  Loser capitulation {conf.LoserCapitulation:0}%  |  Budget {used}/{conf.Score}",
            "1-9 toggle  |  T = cycle Annex/Occupy/Puppet rank  |  Enter enforce  |  Backspace white peace",
            "",
        };

        if (conf.Demands.Count == 0)
            lines.Add("(no occupied states to demand — Enter for white peace)");
        else
        {
            for (int i = 0; i < Math.Min(12, conf.Demands.Count); i++)
            {
                var d = conf.Demands[i];
                string mark = d.Selected ? "[X]" : "[ ]";
                string key = i < 9 ? $"[{i + 1}] " : "    ";
                string act = d.Action == PeaceActionKind.Puppet
                    ? $"Puppet:{GameWorld.RankName(d.PuppetRank)}"
                    : d.Action.ToString();
                lines.Add($"{key}{mark} {d.StateName}  cost {d.ScoreCost}  ({act})");
            }
        }

        float lh = _font.LineSpacing;
        float width = Math.Min(vw - 40, Math.Max(420, lines.Max(l => _font.MeasureString(l).X) + 28));
        float height = lines.Count * lh + 20;
        var panel = new Rectangle(20, 50, (int)width, (int)height);
        _sb.Draw(_pixel, panel, new Color(18, 12, 10, 240));
        _sb.Draw(_pixel, new Rectangle(panel.X, panel.Y, panel.Width, 2), new Color(200, 140, 60));
        for (int i = 0; i < lines.Count; i++)
        {
            var col = i == 0 ? new Color(255, 210, 120)
                    : lines[i].Contains("[X]") ? new Color(140, 230, 140)
                    : lines[i].StartsWith("[") ? new Color(220, 200, 160)
                    : new Color(210, 215, 225);
            DrawText(lines[i], new Vector2(panel.X + 12, panel.Y + 10 + i * lh), col);
        }
    }

    private void DrawFormablePanel(int vw, int vh)
    {
        string? tag = _world.PlayerTag;
        if (tag == null) return;
        float s = Ui;
        var lines = new List<(string text, Color col)>
        {
            ("Formables & Releasables  (V to close)", new Color(255, 220, 120)),
            ("", Color.White),
            ("— Formable nations (1-9 when ready) —", new Color(180, 210, 255)),
        };

        var all = _world.AllFormables()
            .OrderByDescending(d => _world.FormableProgress(tag, d))
            .Take(12).ToList();
        var ready = _world.AvailableFormables(tag);
        int idx = 0;
        foreach (var d in all)
        {
            double prog = _world.FormableProgress(tag, d);
            bool can = ready.Contains(d) || ready.Any(r => r.Id == d.Id);
            string prefix = can && idx < 9 ? $"[{idx + 1}] " : "    ";
            if (can && idx < 9) idx++;
            string bar = new string('|', (int)(prog * 10)) + new string('.', 10 - (int)(prog * 10));
            lines.Add(($"{prefix}{d.Name} ({d.ResultTag})  [{bar}] {(int)(prog * 100)}%",
                can ? new Color(140, 230, 140) : new Color(200, 200, 210)));
        }

        lines.Add(("", Color.White));
        lines.Add(("— Release from your cores (Shift+1-9 = puppet) —", new Color(180, 210, 255)));
        lines.Add(("U = release selected state's non-you core as free", new Color(170, 175, 185)));
        var releases = _world.GetReleasables(tag).Take(9).ToList();
        for (int i = 0; i < releases.Count; i++)
        {
            var r = releases[i];
            lines.Add(($"[S{i + 1}] {r.Name} ({r.Tag}) — {r.StateIds.Count}/{r.TotalCores} states",
                new Color(220, 190, 140)));
        }
        if (releases.Count == 0)
            lines.Add(("  (none — occupy foreign cores to release them)", new Color(150, 150, 160)));

        float lh = LineH;
        float width = Math.Min(vw - 40 * s, Math.Max(420 * s, lines.Max(l => MeasureUi(l.text)) + 28 * s));
        float height = lines.Count * lh + 20 * s;
        var panel = new Rectangle((int)(20 * s), (int)(50 * s), (int)width, (int)Math.Min(height, vh - 70 * s));
        _sb.Draw(_pixel, panel, new Color(14, 16, 22, 240));
        _sb.Draw(_pixel, new Rectangle(panel.X, panel.Y, panel.Width, 2), new Color(120, 180, 220));
        for (int i = 0; i < lines.Count; i++)
        {
            float y = panel.Y + 10 * s + i * lh;
            if (y + lh > panel.Bottom) break;
            DrawText(lines[i].text, new Vector2(panel.X + 12 * s, y), lines[i].col);
        }
    }

    private void DrawFocusPanel(int vw, int vh)
    {
        var country = _map.CountryOf(_world.PlayerTag);
        if (country == null) return;
        var tree = _world.GetTree(country);
        if (tree == null) return;

        var available = _world.AvailableFocuses(country).ToList();
        var completed = country.CompletedFocuses.ToList();

        var lines = new List<string>
        {
            $"National Focus — {tree.Name}",
            country.ActiveFocusId != null
                ? $"In progress: {tree.ById.GetValueOrDefault(country.ActiveFocusId)?.Name ?? country.ActiveFocusId} ({country.FocusDaysRemaining} days left)"
                : "No focus active — pick one below (number key 1-9)",
            "",
        };

        if (available.Count == 0 && country.ActiveFocusId == null)
            lines.Add("(no focuses available right now)");
        else
        {
            for (int i = 0; i < Math.Min(9, available.Count); i++)
            {
                var n = available[i];
                lines.Add($"[{i + 1}] {n.Name}  ({n.CostDays}d) — {n.Description}");
            }
        }

        if (completed.Count > 0)
        {
            lines.Add("");
            lines.Add($"Completed ({completed.Count}): {string.Join(", ", completed.Take(8))}");
        }

        float lh = _font.LineSpacing;
        float width = Math.Min(vw - 40, lines.Max(l => _font.MeasureString(l).X) + 28);
        float height = lines.Count * lh + 20;
        var panel = new Rectangle(20, 50, (int)width, (int)height);
        _sb.Draw(_pixel, panel, new Color(10, 14, 22, 235));
        _sb.Draw(_pixel, new Rectangle(panel.X, panel.Y, panel.Width, 2), new Color(80, 140, 200));
        for (int i = 0; i < lines.Count; i++)
        {
            var col = i == 0 ? new Color(255, 220, 120)
                    : lines[i].StartsWith("[") ? new Color(180, 220, 255)
                    : new Color(210, 215, 225);
            DrawText(lines[i], new Vector2(panel.X + 12, panel.Y + 10 + i * lh), col);
        }
    }

    private List<string> DescribeSelection()
    {
        var lines = new List<string>();
        int pid = _renderer.SelectedProvince;
        if (pid <= 0 || pid >= _map.Provinces.Length) return lines;

        var p = _map.Provinces[pid];
        var (lon, lat) = _map.PixelToGeo(p.CenterX, p.CenterY);
        string kind = p.IsLand ? $"{p.Terrain}{(p.Coastal ? ", coastal" : "")}" : "sea";
        lines.Add(p.Name.Length > 0 ? $"Province {pid}: {p.Name}  ({kind})" : $"Province {pid}  ({kind})");
        lines.Add($"{Math.Abs(lat):0.0}{(lat >= 0 ? "N" : "S")}  {Math.Abs(lon):0.0}{(lon >= 0 ? "E" : "W")}   {p.PixelCount:N0} px");

        if (p.IsLand && _map.States.TryGetValue(p.StateId, out var st))
        {
            var city = _map.CityAt(pid);
            if (city != null)
                lines.Add(city.IsCapital ? $"★ Capital city: {city.Name}" : $"City: {city.Name} (rank {city.Rank})");

            lines.Add($"State: {st.Name}   Manpower: {st.Manpower:N0}   CivF {st.CivilianFactories}  MilF {st.MilitaryFactories}");
            var owner = _map.CountryOf(st.Owner);
            if (owner?.Leader != null)
                lines.Add($"Owner: {owner.Name} — {owner.Leader.Title} {owner.Leader.Name}");
            else
                lines.Add($"Owner: {owner?.Name ?? st.Owner}");
            if (owner != null)
            {
                var sub = _world.GetSubject(owner.Tag);
                if (sub != null)
                    lines.Add($"{GameWorld.RankName(sub.Rank)} of {_map.CountryOf(sub.Overlord)?.Name ?? sub.Overlord}");
                var subs = _world.SubjectsOf(owner.Tag).ToList();
                if (subs.Count > 0)
                    lines.Add($"Subjects: {string.Join(", ", subs.Take(3).Select(s => $"{_map.CountryOf(s.Subject)?.Name ?? s.Subject} ({GameWorld.RankName(s.Rank)})"))}");
                var als = _world.AlliancesOf(owner.Tag).ToList();
                if (als.Count > 0)
                    lines.Add($"Alliances: {string.Join(", ", als.Select(a => a.Name))}");
                lines.Add($"Economy: {owner.EconomyPhase} x{owner.EconomyModifier:0.00}  $ {owner.Treasury:0}  GDP {owner.Gdp:0}  trade {owner.TradeBalance:+0;-0}");
                if (_world.PlayerTag != null && owner.Tag != _world.PlayerTag)
                {
                    if (_world.HasTrade(_world.PlayerTag, owner.Tag))
                        lines.Add("Trading with you  (Y = cancel trade)");
                    else if (!_world.AtWar(_world.PlayerTag, owner.Tag))
                        lines.Add("Y = offer trade deal");
                }
                if (owner.Capitulation > 5)
                    lines.Add($"Capitulation: {owner.Capitulation:0}%");
            }
            var ctrl = _map.CountryOf(p.Controller);
            if (ctrl != null && ctrl != owner) lines.Add($"Occupied by: {ctrl.Name}");
            if (st.Unrest > 5)
                lines.Add($"Unrest: {st.Unrest:0.0}" + (st.Unrest >= 55 ? "  (uprising risk!)" : ""));
            if (st.Cores.Count > 0)
                lines.Add($"Cores: {string.Join(", ", st.Cores.Take(4))}");
            if (owner != null && owner.Tag != _world.PlayerTag)
            {
                if (_world.AtWar(_world.PlayerTag, owner.Tag))
                    lines.Add($"At war  |  your war score {_world.WarScoreAgainst(_world.PlayerTag!, owner.Tag):0}  (P = peace)");
                else
                    lines.Add("Enter = declare war");
            }
        }

        var armies = _world.ArmiesIn(pid).ToList();
        if (armies.Count > 0)
            lines.Add($"Armies here: {armies.Count}");

        if (_selectedArmy != null)
            lines.Add($"> {_selectedArmy.Name} ({UnitStats.Label(_selectedArmy.Type)})  str {_selectedArmy.Strength:0}%  path {_selectedArmy.Path.Count}");
        return lines;
    }

    private void DrawHelp(int vw, int vh)
    {
        string[] help =
        {
            "Controls",
            "WASD / arrows / middle-drag : move the map",
            "Mouse wheel : zoom        Home : go to your capital",
            "Left click : select province / army (click again to cycle stacked armies)",
            "Right click : move the selected army there (route is planned for you)",
            "B : raise an army in the selected province    C : deselect army",
            "Enter : declare war on the selected province's owner    P : make peace",
            "F3 : cycle 2D → 3D relief → 3D flat (free pan)    F4 : toggle flat/relief in 3D",
            "3D: Q E rotate, PgUp PgDn tilt, shift + middle-drag orbit",
            "Space : pause    + / - : game speed",
            "1 Political  2 Terrain  3 States  4 Manpower  5 War  6 Flags",
            "Nation names on map · 3D unit counters · curved 2.5D water shine",
            "F : national focus panel (then 1-9 to pick a focus)",
            "V : formables & releasables (1-9 form, Shift+1-9 puppet release, U free release)",
            "K : peace conference panel (when a conference is open)",
            "L : form alliance with selected country    T : cycle peace demand type",
            "O / F10 : settings (UI scale + / -)    F2 : scenario builder",
            "F11 : fullscreen    F1 : hide help    Esc : quit",
            "B raise unit  [ ] cycle type  G/M build civ/mil factory  Y trade",
            "J add human (hotseat)  Tab switch  F5 host  F6 join local MP",
            "Economy: GDP, treasury, random booms/crashes, bilateral trade",
            "Builder: Q paint, E province/state brush",
        };
        float lh = _font.LineSpacing;
        float width = help.Max(l => _font.MeasureString(l).X) + 24;
        float height = help.Length * lh + 16;
        var panel = new Rectangle((int)(vw - width - 10), (int)(vh - height - 10), (int)width, (int)height);
        _sb.Draw(_pixel, panel, new Color(12, 16, 24, 215));
        for (int i = 0; i < help.Length; i++)
            DrawText(help[i], new Vector2(panel.X + 12, panel.Y + 8 + i * lh), i == 0 ? new Color(255, 230, 140) : new Color(210, 215, 225));
    }

    protected override void UnloadContent()
    {
        _renderer?.Dispose();
        _view3d?.Dispose();
        _gui?.Dispose();
        _pixel?.Dispose();
        _flags?.Dispose();
        _units?.Dispose();
        _citySprites?.Dispose();
        _music?.Dispose();
        _menuBg?.Dispose();
        _net?.Dispose();
        base.UnloadContent();
    }
}
