using HoiSharp.Core;
using HoiSharp.Core.Diagnostics;
using HoiSharp.Core.Import;
using HoiSharp.Game;

AppLog.Init("game"); // first thing: even a crash a millisecond later leaves a log and a marker

try
{
    var options = LaunchOptions.Parse(args);
    AppLog.Info($"Options: data={options.DataRoot} mods=[{string.Join(",", options.Mods)}] scenario={options.ScenarioId} player={options.PlayerTag}");

    // Launcher must be open (unless bypass env is set)
    if (!LauncherGate.AllowBypass() && !LauncherGate.IsLauncherAlive())
    {
        AppLog.Warn("Refused to start: launcher is not running.");
        AppLog.MarkCleanExit();
        string msg =
            "HoiSharp must be started from the HoiSharp Launcher.\n\n" +
            "Open HoiSharpLauncher.exe first, then press Play.\n\n" +
            "Developers: set env HOISHARP_ALLOW_NO_LAUNCHER=1 to bypass.";
        Console.Error.WriteLine(msg);
        return;
    }

    if (!string.IsNullOrEmpty(options.ImportHoi4Path))
    {
        string? path = options.ImportHoi4Path;
        if (string.Equals(path, "auto", StringComparison.OrdinalIgnoreCase))
        {
            Console.WriteLine("Searching for Hearts of Iron IV (Steam)...");
            path = SteamLocator.FindHoi4Install();
            if (path == null)
            {
                Console.Error.WriteLine("Could not find HOI4. Pass the path explicitly:");
                Console.Error.WriteLine("  --import-hoi4 \"C:\\Program Files (x86)\\Steam\\steamapps\\common\\Hearts of Iron IV\"");
                return;
            }
            Console.WriteLine("Found: " + path);
        }

        var result = Hoi4Importer.Import(path, options.DataRoot, progress: Console.WriteLine);
        Console.WriteLine(result.Message);

        if (!options.PlayAfterImport)
            return;

        if (!options.Mods.Contains(Hoi4Importer.DefaultModId, StringComparer.OrdinalIgnoreCase))
            options.Mods.Add(Hoi4Importer.DefaultModId);
    }

    using var game = new HoiGame(options);
    game.Run();
    AppLog.Info("Game closed normally.");
    AppLog.MarkCleanExit();
}
catch (Exception ex)
{
    var report = AppLog.WriteCrash(ex, "Game crashed");
    AppLog.MarkCleanExit(); // reported
    Console.Error.WriteLine(ex);
    if (OperatingSystem.IsWindows())
    {
        // the game window is gone: tell the player where the report is
        try
        {
            System.Diagnostics.Process.Start(new System.Diagnostics.ProcessStartInfo("cmd.exe",
                $"/c echo HoiSharp crashed. Crash report: {report} & echo Send that file when asking for help. & pause")
            { UseShellExecute = true });
        }
        catch (Exception) { }
    }
    Environment.ExitCode = 1;
}
