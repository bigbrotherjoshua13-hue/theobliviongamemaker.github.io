using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;

namespace HoiSharp.Game;

/// <summary>
/// Procedural 2D city sprites with transparent backgrounds (stock-style building silhouettes).
/// Shown only at high zoom so the strategic map stays clean.
/// </summary>
public sealed class CitySprites : IDisposable
{
    public const float MinZoomForSprites = 5.0f; // ~500% (screen px per map px)

    private readonly Texture2D _town;
    private readonly Texture2D _capital;
    private readonly Texture2D _port;

    public CitySprites(GraphicsDevice gd)
    {
        _town = Build(gd, capital: false, port: false);
        _capital = Build(gd, capital: true, port: false);
        _port = Build(gd, capital: false, port: true);
    }

    public Texture2D Get(bool isCapital, bool coastal = false) =>
        isCapital ? _capital : coastal ? _port : _town;

    private static Texture2D Build(GraphicsDevice gd, bool capital, bool port)
    {
        const int w = 64, h = 48;
        var tex = new Texture2D(gd, w, h);
        var data = new Color[w * h];
        // fully transparent
        for (int i = 0; i < data.Length; i++) data[i] = Color.Transparent;

        void Plot(int x, int y, Color c)
        {
            if ((uint)x < w && (uint)y < h) data[y * w + x] = c;
        }
        void FillRect(int x0, int y0, int x1, int y1, Color c)
        {
            for (int y = y0; y <= y1; y++)
                for (int x = x0; x <= x1; x++) Plot(x, y, c);
        }

        // ground shadow (soft)
        var shadow = new Color(0, 0, 0, 60);
        for (int x = 8; x < w - 8; x++)
            for (int y = h - 8; y < h - 3; y++)
                Plot(x, y, shadow);

        var wall = capital ? new Color(210, 200, 185, 240) : new Color(175, 175, 180, 235);
        var roof = capital ? new Color(160, 55, 45, 245) : new Color(95, 110, 130, 240);
        var window = new Color(255, 230, 140, 220);
        var outline = new Color(30, 30, 35, 200);

        // building blocks (simple city skyline)
        (int bx, int bw, int bh)[] blocks = capital
            ? new[] { (6, 12, 28), (18, 14, 36), (32, 10, 24), (42, 14, 32) }
            : new[] { (10, 14, 22), (26, 12, 30), (40, 14, 20) };

        int baseY = h - 10;
        foreach (var (bx, bw, bh) in blocks)
        {
            int top = baseY - bh;
            // outline
            FillRect(bx - 1, top - 1, bx + bw, baseY, outline);
            // body
            FillRect(bx, top, bx + bw - 1, baseY - 1, wall);
            // roof strip
            FillRect(bx, top, bx + bw - 1, top + 3, roof);
            // windows
            for (int wy = top + 6; wy < baseY - 4; wy += 5)
                for (int wx = bx + 2; wx < bx + bw - 2; wx += 4)
                    Plot(wx, wy, window);
        }

        if (capital)
        {
            // small dome / star tower in the middle
            int cx = 32, cy = baseY - 40;
            for (int dy = -6; dy <= 0; dy++)
                for (int dx = -5; dx <= 5; dx++)
                    if (dx * dx + dy * dy <= 30)
                        Plot(cx + dx, cy + dy, roof);
            // flagpole
            for (int y = cy - 10; y < cy; y++) Plot(cx, y, outline);
            FillRect(cx + 1, cy - 10, cx + 6, cy - 6, new Color(220, 50, 50, 250));
        }

        if (port)
        {
            // simple pier / water front
            var water = new Color(60, 120, 180, 180);
            FillRect(4, baseY + 1, w - 5, baseY + 4, water);
            FillRect(8, baseY - 2, 20, baseY, new Color(120, 90, 60, 230));
        }

        tex.SetData(data);
        return tex;
    }

    public void Dispose()
    {
        _town.Dispose();
        _capital.Dispose();
        _port.Dispose();
    }
}
