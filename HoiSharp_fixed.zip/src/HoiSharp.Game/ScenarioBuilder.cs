using System.Globalization;
using HoiSharp.Core.Data;
using HoiSharp.Core.Scenarios;
using HoiSharp.Core.Sim;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;

namespace HoiSharp.Game;

/// <summary>
/// In-game scenario editor. It edits the live world (state owners, armies, wars, player, date) and
/// saves the difference from the base data as a scenario file in data/user/scenarios.
///
/// A "brush country" is the country that painting, armies and wars apply to.
/// </summary>
public sealed class ScenarioBuilder
{
    private enum InputMode { None, Country, Save }

    private readonly MapData _map;
    private readonly GameWorld _world;
    private readonly MapRenderer _renderer;
    private readonly string _dataRoot;
    private readonly Action<string> _toast;
    private Scenario _scenario;

    private InputMode _mode = InputMode.None;
    private string _input = "";
    private bool _paint = true;
    /// <summary>When true, paint only the clicked province; when false, paint the whole state.</summary>
    private bool _provinceBrush = true;
    private bool _dirty;
    private int _lastPaintedState;
    private int _lastPaintedProvince;
    private Rectangle _panel;

    public bool Active { get; set; }
    public string BrushTag { get; private set; }
    public bool IsTyping => Active && _mode != InputMode.None;

    public ScenarioBuilder(MapData map, GameWorld world, MapRenderer renderer, Scenario scenario, string dataRoot, Action<string> toast)
    {
        _map = map;
        _world = world;
        _renderer = renderer;
        _scenario = scenario;
        _dataRoot = dataRoot;
        _toast = toast;
        BrushTag = world.PlayerTag ?? map.CountryList.FirstOrDefault()?.Tag ?? "";
    }

    // ------------------------------------------------------------------ text input
    /// <summary>Called from the window's TextInput event.</summary>
    public void OnTextInput(char ch)
    {
        if (!IsTyping) return;
        if (ch >= 32 && ch != 127 && _input.Length < 60) _input += ch;
    }

    private void BeginInput(InputMode mode, string initial)
    {
        _mode = mode;
        _input = initial;
    }

    public void HandleTypingKeys(KeyboardState ks, KeyboardState prev)
    {
        bool Edge(Keys k) => ks.IsKeyDown(k) && prev.IsKeyUp(k);

        if (Edge(Keys.Escape)) { _mode = InputMode.None; _input = ""; return; }
        if (Edge(Keys.Enter)) { Commit(); return; }
        if (Edge(Keys.Back) && _input.Length > 0) _input = _input[..^1];
    }

    private void Commit()
    {
        var text = _input.Trim();
        var mode = _mode;
        _mode = InputMode.None;
        _input = "";
        if (text.Length == 0) return;

        if (mode == InputMode.Country) CommitCountry(text);
        else if (mode == InputMode.Save) CommitSave(text);
    }

    private void CommitCountry(string text)
    {
        var parts = text.Split(' ', 2, StringSplitOptions.RemoveEmptyEntries | StringSplitOptions.TrimEntries);
        string tag = parts[0].ToUpperInvariant();
        string? name = parts.Length > 1 ? parts[1] : null;

        if (tag.Length < 2 || tag.Length > 5 || !tag.All(char.IsLetterOrDigit))
        {
            _toast("A country tag is 2-5 letters or digits, e.g.  XYZ  or  XYZ My Country");
            return;
        }

        var country = _map.CountryOf(tag);
        if (country == null)
        {
            if (_map.CountryList.Count >= 255)
            {
                _toast("Too many countries (the map shader supports 255).");
                return;
            }
            country = _map.AddCountry(tag, name ?? tag, ScenarioApplier.DefaultColor(tag));
            _toast($"Created country {country.Name} ({country.Tag}). Paint states to give it land.");
            Remember(country);
        }
        else if (name != null && name != country.Name)
        {
            country.Name = name;
            _toast($"Renamed {country.Tag} to {name}.");
            Remember(country);
        }

        BrushTag = country.Tag;
        _renderer.MarkDirty();
    }

    private void Remember(Country c)
    {
        _scenario.Countries[c.Tag] = new CountryDef { Tag = c.Tag, Name = c.Name, HasColor = true, R = c.R, G = c.G, B = c.B };
        _dirty = true;
    }

    private void CommitSave(string name)
    {
        try
        {
            var s = BuildScenario(name);
            var path = ScenarioLibrary.Save(s, _dataRoot);
            _scenario = s;
            _dirty = false;
            _toast($"Saved '{s.Name}' as user/scenarios/{Path.GetFileName(path)} - pick it in the launcher.");
        }
        catch (Exception ex)
        {
            _toast("Could not save: " + ex.Message);
        }
    }

    /// <summary>Snapshot of the live world as a scenario (only differences from the base data are stored).</summary>
    private Scenario BuildScenario(string name)
    {
        var s = new Scenario
        {
            Id = ScenarioLibrary.MakeId(name),
            Name = name,
            Description = _scenario.Description.Length > 0 ? _scenario.Description : "Made in the scenario builder.",
            StartDate = _world.Date,
            Player = _world.PlayerTag,
            ClearDefaultArmies = true,
        };
        foreach (var kv in _scenario.Countries) s.Countries[kv.Key] = kv.Value;

        foreach (var st in _map.States.Values.OrderBy(x => x.Id))
            if (st.Owner.Length > 0 && !string.Equals(st.Owner, st.BaseOwner, StringComparison.OrdinalIgnoreCase))
                s.StateOwners[st.Id] = st.Owner;

        foreach (var w in _world.Wars) s.Wars.Add(new WarDef(w.A, w.B));
        s.Armies.AddRange(_world.SnapshotArmies());
        return s;
    }

    // ------------------------------------------------------------------ normal input
    public void HandleInput(KeyboardState ks, KeyboardState prev, MouseState ms, MouseState prevMs, int hover)
    {
        bool Pressed(Keys k) => ks.IsKeyDown(k) && prev.IsKeyUp(k);
        bool ctrl = ks.IsKeyDown(Keys.LeftControl) || ks.IsKeyDown(Keys.RightControl);
        bool shift = ks.IsKeyDown(Keys.LeftShift) || ks.IsKeyDown(Keys.RightShift);

        if (ctrl && Pressed(Keys.S))
        {
            BeginInput(InputMode.Save, _scenario.Name == "Unnamed scenario" ? "" : _scenario.Name);
            return;
        }
        if (!ctrl && Pressed(Keys.T))
        {
            BeginInput(InputMode.Country, "");
            return;
        }

        if (Pressed(Keys.Q))
        {
            _paint = !_paint;
            _toast(_paint
                ? $"Paint ON ({(_provinceBrush ? "province" : "state")} brush). Click/drag to paint."
                : "Paint OFF — clicking only selects.");
        }
        if (Pressed(Keys.E))
        {
            _provinceBrush = !_provinceBrush;
            _toast(_provinceBrush
                ? "Brush: PROVINCE — only the province under the cursor is transferred."
                : "Brush: STATE — the whole state under the cursor is transferred.");
        }

        // ---- mouse
        bool overPanel = _panel.Contains(ms.X, ms.Y);
        bool leftDown = ms.LeftButton == ButtonState.Pressed;
        bool leftClick = leftDown && prevMs.LeftButton == ButtonState.Released;
        bool rightClick = ms.RightButton == ButtonState.Pressed && prevMs.RightButton == ButtonState.Released;

        if (!overPanel)
        {
            if (leftClick && hover != 0) _renderer.SelectedProvince = hover;

            if (_paint && leftDown && hover > 0 && BrushTag.Length > 0)
            {
                var p = _map.Provinces[hover];
                if (p.IsLand && p.StateId != 0)
                {
                    if (_provinceBrush)
                    {
                        // province-level: only transfer this province, skip if already painted this stroke
                        if (hover != _lastPaintedProvince)
                        {
                            _lastPaintedProvince = hover;
                            if (_world.SetProvinceOwner(hover, BrushTag)) _dirty = true;
                        }
                    }
                    else
                    {
                        if (p.StateId != _lastPaintedState)
                        {
                            _lastPaintedState = p.StateId;
                            if (_world.SetStateOwner(p.StateId, BrushTag)) _dirty = true;
                        }
                    }
                }
            }

            if (rightClick && hover > 0)
            {
                var owner = _map.OwnerOf(hover);
                if (owner != null) BrushTag = owner;
            }
        }
        if (!leftDown) { _lastPaintedState = 0; _lastPaintedProvince = 0; }

        // ---- keys that work on the selected province
        int sel = _renderer.SelectedProvince;
        bool hasSel = sel > 0 && sel < _map.Provinces.Length;

        if (Pressed(Keys.A) && hasSel && BrushTag.Length > 0)
        {
            if (_world.AddArmy(BrushTag, sel) != null) _dirty = true;
            else _toast("Armies can only be placed on land provinces.");
        }

        if (Pressed(Keys.X) && hasSel)
        {
            int n = _world.RemoveArmiesAt(sel);
            if (n > 0) { _dirty = true; _toast($"Removed {n} army(ies)."); }
        }

        if (Pressed(Keys.R) && hasSel && _map.Provinces[sel].StateId != 0
            && _map.States.TryGetValue(_map.Provinces[sel].StateId, out var state))
        {
            if (_world.SetStateOwner(state.Id, state.BaseOwner)) _dirty = true;
        }

        if (Pressed(Keys.Enter) && hasSel)
        {
            var owner = _map.OwnerOf(sel);
            if (owner == null || owner == BrushTag) _toast("Select a province owned by another country first.");
            else if (_world.DeclareWar(BrushTag, owner, permanent: true)) _dirty = true;
            else _toast("They are already at war.");
        }

        if (Pressed(Keys.Back) && hasSel)
        {
            var owner = _map.OwnerOf(sel);
            if (owner != null && owner != BrushTag && _world.MakePeace(BrushTag, owner)) _dirty = true;
        }

        if (Pressed(Keys.P) && BrushTag.Length > 0)
        {
            _world.SetPlayer(BrushTag);
            _dirty = true;
            _toast($"Player country is now {_map.CountryOf(BrushTag)?.Name ?? BrushTag}.");
        }

        if (Pressed(Keys.OemComma) || Pressed(Keys.OemPeriod))
        {
            int step = shift ? 12 : 1;
            if (Pressed(Keys.OemComma)) step = -step;
            _world.SetDate(_world.Date.AddMonths(step));
            _dirty = true;
        }
    }

    // ------------------------------------------------------------------ drawing
    private static void Text(SpriteBatch sb, SpriteFont font, string text, Vector2 pos, Color color)
    {
        sb.DrawString(font, text, pos + new Vector2(1, 1), new Color(0, 0, 0, 200));
        sb.DrawString(font, text, pos, color);
    }

    public void DrawHud(SpriteBatch sb, SpriteFont font, Texture2D pixel, int vw, int vh, float time)
    {
        var brush = _map.CountryOf(BrushTag);
        var normal = new Color(225, 228, 235);
        var lines = new List<(string text, Color color)>
        {
            ("SCENARIO BUILDER", new Color(255, 170, 70)),
            ($"Scenario: {_scenario.Name}{(_dirty ? " *" : "")}", normal),
            ($"Brush: {brush?.Name ?? BrushTag} ({BrushTag})   Paint: {(_paint ? "ON" : "OFF")}   Mode: {(_provinceBrush ? "PROVINCE" : "STATE")}", normal),
            ($"Start: {_world.Date.ToString("d MMM yyyy", CultureInfo.InvariantCulture)}   Player: {_world.PlayerTag}", normal),
            ($"Wars: {_world.Wars.Count}   Armies: {_world.Armies.Count}", normal),
            ("", normal),
        };
        string[] help =
        {
            "Left click / drag : give the state to the brush country",
            "Right click : pick the country under the cursor as brush",
            "T : type a country tag  (TAG, or 'TAG Name' to create / rename)",
            "Q : paint on/off      E : province/state brush      R : revert selected state",
            "A : add army      X : remove armies in the selected province",
            "Enter : brush declares war on the selected owner    Backspace : peace",
            "P : play as brush country      , / . : start date -/+ month (Shift = year)",
            "Ctrl+S : save scenario      F2 / Esc : leave the builder",
        };
        foreach (var h in help) lines.Add((h, new Color(190, 200, 215)));

        float lh = font.LineSpacing;
        float width = lines.Max(l => font.MeasureString(l.text).X) + 36;
        float height = lines.Count * lh + 14;
        _panel = new Rectangle((int)(vw - width - 10), 40, (int)width, (int)height);

        sb.Draw(pixel, _panel, new Color(12, 16, 24, 225));
        for (int i = 0; i < lines.Count; i++)
            Text(sb, font, lines[i].text, new Vector2(_panel.X + 10, _panel.Y + 7 + i * lh), lines[i].color);

        if (brush != null) // colour swatch next to the brush line
        {
            var sw = new Rectangle(_panel.Right - 24, (int)(_panel.Y + 7 + 2 * lh) + 2, 14, 14);
            sb.Draw(pixel, new Rectangle(sw.X - 1, sw.Y - 1, sw.Width + 2, sw.Height + 2), Color.Black);
            sb.Draw(pixel, sw, new Color(brush.R, brush.G, brush.B));
        }

        if (IsTyping)
        {
            string prompt = _mode == InputMode.Country
                ? "Country tag (TAG, or 'TAG Name' to create/rename): "
                : "Save scenario as: ";
            string shown = prompt + _input;
            string widest = shown + "_";
            var size = font.MeasureString(widest);
            var box = new Rectangle((int)((vw - size.X) / 2) - 16, vh - 96, (int)size.X + 32, (int)size.Y + 18);
            sb.Draw(pixel, box, new Color(12, 16, 24, 240));
            sb.Draw(pixel, new Rectangle(box.X, box.Y, box.Width, 2), new Color(255, 170, 70));
            bool blink = (int)(time * 2f) % 2 == 0;
            Text(sb, font, shown + (blink ? "_" : ""), new Vector2(box.X + 16, box.Y + 9), Color.White);
        }
    }
}
