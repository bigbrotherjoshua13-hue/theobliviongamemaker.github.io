using HoiSharp.Core.Data;
using HoiSharp.Core.Sim;
using Microsoft.Xna.Framework;

namespace HoiSharp.Game;

/// <summary>
/// Builds fluid front-line segments between adjacent provinces controlled by warring countries.
/// </summary>
public sealed class Frontlines
{
    public readonly record struct Seg(Vector2 A, Vector2 B, string SideA, string SideB);

    private readonly MapData _map;
    private readonly GameWorld _world;
    private List<Seg> _segs = new();
    private bool _dirty = true;

    public IReadOnlyList<Seg> Segments => _segs;

    public Frontlines(MapData map, GameWorld world)
    {
        _map = map;
        _world = world;
        world.MapChanged += () => _dirty = true;
    }

    public void MarkDirty() => _dirty = true;

    public void RebuildIfNeeded()
    {
        if (!_dirty) return;
        _dirty = false;
        var list = new List<Seg>();
        if (_world.Wars.Count == 0)
        {
            _segs = list;
            return;
        }

        var seen = new HashSet<long>();
        foreach (var p in _map.Provinces)
        {
            if (p == null || !p.IsLand || p.Controller == null) continue;
            string a = p.Controller;
            foreach (var e in p.Edges)
            {
                if (e.Kind is EdgeKind.Sea) continue;
                int to = e.To;
                if (to <= 0 || to >= _map.Provinces.Length) continue;
                var q = _map.Provinces[to];
                if (!q.IsLand || q.Controller == null) continue;
                string b = q.Controller;
                if (a == b) continue;
                if (!_world.AtWar(a, b)) continue;

                int lo = Math.Min(p.Id, to), hi = Math.Max(p.Id, to);
                long key = ((long)lo << 32) | (uint)hi;
                if (!seen.Add(key)) continue;

                var midA = new Vector2(p.CenterX, p.CenterY);
                var midB = new Vector2(q.CenterX, q.CenterY);
                // segment sits between province centres (fluid front)
                list.Add(new Seg(midA, midB, a, b));
            }
        }
        _segs = list;
    }
}
