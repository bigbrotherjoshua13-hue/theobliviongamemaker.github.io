using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using HoiSharp.Core.Data;

namespace HoiSharp.Game;

/// <summary>
/// Generates simple procedural country flags from the country colour.
/// Also supports loading gfx/flags/TAG.png when present.
/// </summary>
public sealed class FlagGenerator
{
    private readonly GraphicsDevice _gd;
    private readonly Dictionary<string, Texture2D> _cache = new(StringComparer.OrdinalIgnoreCase);
    private readonly string? _flagsDir;

    public const int FlagW = 48;
    public const int FlagH = 32;

    public FlagGenerator(GraphicsDevice gd, string? dataRoot = null)
    {
        _gd = gd;
        if (dataRoot != null)
        {
            var candidate = Path.Combine(dataRoot, "mod_base", "gfx", "flags");
            if (Directory.Exists(candidate)) _flagsDir = candidate;
        }
    }

    public Texture2D GetFlag(Country c)
    {
        if (_cache.TryGetValue(c.Tag, out var tex)) return tex;

        // try disk first
        if (_flagsDir != null)
        {
            var path = Path.Combine(_flagsDir, c.Tag + ".png");
            if (File.Exists(path))
            {
                try
                {
                    using var fs = File.OpenRead(path);
                    tex = Texture2D.FromStream(_gd, fs);
                    _cache[c.Tag] = tex;
                    return tex;
                }
                catch { /* fall through to procedural */ }
            }
        }

        tex = GenerateProcedural(c);
        _cache[c.Tag] = tex;
        return tex;
    }

    private Texture2D GenerateProcedural(Country c)
    {
        var tex = new Texture2D(_gd, FlagW, FlagH);
        var data = new Color[FlagW * FlagH];

        var primary = new Color(c.R, c.G, c.B);
        // derive secondary / tertiary by lightening / darkening / hue shift
        var secondary = new Color(
            (byte)Math.Clamp(c.R + 60, 0, 255),
            (byte)Math.Clamp(c.G + 40, 0, 255),
            (byte)Math.Clamp(c.B - 30, 0, 255));
        var accent = new Color(
            (byte)Math.Clamp(255 - c.R, 40, 220),
            (byte)Math.Clamp(255 - c.G, 40, 220),
            (byte)Math.Clamp(255 - c.B, 40, 220));

        // choose a simple design based on tag hash so each country is consistent
        int design = Math.Abs(c.Tag.GetHashCode()) % 6;

        for (int y = 0; y < FlagH; y++)
        for (int x = 0; x < FlagW; x++)
        {
            Color col = primary;
            switch (design)
            {
                case 0: // solid
                    col = primary;
                    break;
                case 1: // horizontal tricolor
                    col = y < FlagH / 3 ? secondary : y < 2 * FlagH / 3 ? primary : accent;
                    break;
                case 2: // vertical tricolor
                    col = x < FlagW / 3 ? secondary : x < 2 * FlagW / 3 ? primary : accent;
                    break;
                case 3: // nordic cross
                    col = primary;
                    if (Math.Abs(x - FlagW / 3) < 3 || Math.Abs(y - FlagH / 2) < 3)
                        col = accent;
                    break;
                case 4: // diagonal
                    col = (x + y) < (FlagW + FlagH) / 2 ? primary : secondary;
                    break;
                case 5: // canton + field
                    col = primary;
                    if (x < FlagW / 3 && y < FlagH / 2)
                        col = accent;
                    break;
            }
            // thin border
            if (x == 0 || y == 0 || x == FlagW - 1 || y == FlagH - 1)
                col = Color.Lerp(col, Color.Black, 0.35f);

            data[y * FlagW + x] = col;
        }

        tex.SetData(data);
        return tex;
    }

    public void Dispose()
    {
        foreach (var t in _cache.Values) t.Dispose();
        _cache.Clear();
    }
}
