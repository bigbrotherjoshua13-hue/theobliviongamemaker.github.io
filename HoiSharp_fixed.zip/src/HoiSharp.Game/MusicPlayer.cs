using Microsoft.Xna.Framework.Media;

namespace HoiSharp.Game;

/// <summary>
/// Plays the bundled soundtrack from data/.../music as a looping playlist.
/// These tracks are the only in-game music.
/// </summary>
public sealed class MusicPlayer : IDisposable
{
    private readonly List<(string name, Song song)> _playlist = new();
    private int _index;
    private bool _enabled = true;
    private float _volume = 0.55f;
    private MediaState _lastState = MediaState.Stopped;

    public bool Enabled
    {
        get => _enabled;
        set
        {
            _enabled = value;
            if (!_enabled) MediaPlayer.Stop();
            else if (_playlist.Count > 0 && MediaPlayer.State != MediaState.Playing)
                PlayCurrent();
        }
    }

    public float Volume
    {
        get => _volume;
        set
        {
            _volume = Math.Clamp(value, 0f, 1f);
            MediaPlayer.Volume = _volume;
        }
    }

    public string? CurrentTrack => _playlist.Count > 0 ? _playlist[_index].name : null;

    public void LoadFrom(string dataRoot)
    {
        DisposeSongs();
        string[] dirs =
        {
            Path.Combine(dataRoot, "mod_base", "music"),
            Path.Combine(dataRoot, "music"),
        };

        foreach (var dir in dirs)
        {
            if (!Directory.Exists(dir)) continue;
            foreach (var file in Directory.GetFiles(dir, "*.mp3").OrderBy(f => f, StringComparer.OrdinalIgnoreCase))
            {
                try
                {
                    var uri = new Uri(Path.GetFullPath(file));
                    var song = Song.FromUri(Path.GetFileNameWithoutExtension(file), uri);
                    _playlist.Add((Path.GetFileNameWithoutExtension(file), song));
                }
                catch
                {
                    // skip unreadable tracks
                }
            }
            if (_playlist.Count > 0) break;
        }

        MediaPlayer.IsRepeating = false;
        MediaPlayer.Volume = _volume;
        if (_enabled && _playlist.Count > 0)
            PlayCurrent();
    }

    public void Update()
    {
        if (!_enabled || _playlist.Count == 0) return;
        var state = MediaPlayer.State;
        // advance when a track ends
        if (_lastState == MediaState.Playing && state == MediaState.Stopped)
        {
            _index = (_index + 1) % _playlist.Count;
            PlayCurrent();
        }
        _lastState = state;
    }

    public void Next()
    {
        if (_playlist.Count == 0) return;
        _index = (_index + 1) % _playlist.Count;
        PlayCurrent();
    }

    public void Previous()
    {
        if (_playlist.Count == 0) return;
        _index = (_index - 1 + _playlist.Count) % _playlist.Count;
        PlayCurrent();
    }

    private void PlayCurrent()
    {
        if (_playlist.Count == 0) return;
        try
        {
            MediaPlayer.Play(_playlist[_index].song);
            _lastState = MediaState.Playing;
        }
        catch
        {
            _lastState = MediaState.Stopped;
        }
    }

    private void DisposeSongs()
    {
        MediaPlayer.Stop();
        foreach (var (_, song) in _playlist)
            song.Dispose();
        _playlist.Clear();
        _index = 0;
    }

    public void Dispose() => DisposeSongs();
}
