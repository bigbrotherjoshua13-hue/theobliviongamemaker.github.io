using HoiSharp.Core.Data;
using HoiSharp.Core.Sim;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;

namespace HoiSharp.Game;

/// <summary>
/// HOI4-inspired unit counters drawn as 3D-ish stacked blocks + NATO-style type glyphs.
/// (Does not ship copyrighted HOI4 meshes — procedural counters that behave like map units.)
/// </summary>
public sealed class UnitVisuals
{
    private readonly GraphicsDevice _gd;
    private readonly Texture2D _pixel;
    private readonly Dictionary<UnitType, Texture2D> _glyphs = new();

    public UnitVisuals(GraphicsDevice gd, Texture2D pixel)
    {
        _gd = gd;
        _pixel = pixel;
        BuildGlyphs();
    }

    private void BuildGlyphs()
    {
        foreach (UnitType t in Enum.GetValues(typeof(UnitType)))
            _glyphs[t] = MakeGlyph(t);
    }

    private Texture2D MakeGlyph(UnitType t)
    {
        const int s = 16;
        var tex = new Texture2D(_gd, s, s);
        var data = new Color[s * s];
        // transparent bg
        for (int i = 0; i < data.Length; i++) data[i] = Color.Transparent;

        void Set(int x, int y, Color c)
        {
            if ((uint)x < s && (uint)y < s) data[y * s + x] = c;
        }
        void HLine(int y, int x0, int x1, Color c) { for (int x = x0; x <= x1; x++) Set(x, y, c); }
        void VLine(int x, int y0, int y1, Color c) { for (int y = y0; y <= y1; y++) Set(x, y, c); }
        void Fill(int x0, int y0, int x1, int y1, Color c)
        {
            for (int y = y0; y <= y1; y++)
                for (int x = x0; x <= x1; x++) Set(x, y, c);
        }

        var ink = Color.White;
        switch (UnitStats.Branch(t))
        {
            case UnitBranch.Naval:
                // boat silhouette
                Fill(2, 9, 13, 11, ink);
                HLine(8, 4, 11, ink);
                HLine(7, 6, 9, ink);
                VLine(8, 4, 7, ink);
                break;
            case UnitBranch.Air:
                // wing
                HLine(8, 2, 13, ink);
                VLine(8, 3, 12, ink);
                HLine(5, 6, 10, ink);
                break;
            default:
                if (t == UnitType.Armor)
                {
                    Fill(3, 7, 12, 11, ink);
                    Fill(5, 5, 10, 7, ink);
                    HLine(9, 2, 13, ink);
                }
                else if (t == UnitType.Artillery)
                {
                    VLine(8, 3, 12, ink);
                    HLine(10, 4, 12, ink);
                    Fill(10, 4, 12, 6, ink);
                }
                else
                {
                    // infantry X (NATO)
                    for (int i = 3; i <= 12; i++)
                    {
                        Set(i, i, ink);
                        Set(s - 1 - i, i, ink);
                    }
                }
                break;
        }
        tex.SetData(data);
        return tex;
    }

    /// <summary>
    /// Draw a HOI4-style counter at screen position with optional 3D stack height.
    /// </summary>
    public void DrawCounter(SpriteBatch sb, SpriteFont font, Army army, Country? owner, Vector2 screen, float scale, bool selected)
    {
        float s = MathHelper.Clamp(scale, 0.55f, 2.2f);
        int w = (int)(28 * s);
        int h = (int)(22 * s);
        int depth = army.IsNaval ? 2 : army.IsAir ? 1 : 3 + (int)(army.Strength / 40);

        var baseCol = owner != null ? new Color(owner.R, owner.G, owner.B) : new Color(120, 120, 120);
        if (army.IsNaval) baseCol = Color.Lerp(baseCol, new Color(30, 60, 140), 0.4f);
        if (army.IsAir) baseCol = Color.Lerp(baseCol, new Color(160, 200, 240), 0.35f);

        // 3D stack: draw offset layers back-to-front
        for (int layer = depth; layer >= 0; layer--)
        {
            float shade = 0.55f + 0.45f * (1f - layer / (float)Math.Max(1, depth));
            var col = new Color(
                (int)(baseCol.R * shade),
                (int)(baseCol.G * shade),
                (int)(baseCol.B * shade));
            int ox = (int)(screen.X - w / 2 + layer);
            int oy = (int)(screen.Y - h / 2 - layer * 2);
            var rect = new Rectangle(ox, oy, w, h);
            sb.Draw(_pixel, new Rectangle(rect.X - 1, rect.Y - 1, rect.Width + 2, rect.Height + 2),
                selected && layer == 0 ? new Color(255, 230, 80) : new Color(0, 0, 0, 200));
            sb.Draw(_pixel, rect, col);

            // top edge highlight
            if (layer == 0)
            {
                sb.Draw(_pixel, new Rectangle(rect.X, rect.Y, rect.Width, 2), Color.White * 0.25f);
                // strength bar
                int sw = (int)(rect.Width * Math.Clamp(army.Strength / 100.0, 0, 1));
                sb.Draw(_pixel, new Rectangle(rect.X, rect.Bottom - 3, rect.Width, 3), new Color(0, 0, 0, 160));
                sb.Draw(_pixel, new Rectangle(rect.X, rect.Bottom - 3, sw, 3), new Color(100, 220, 100));

                // glyph
                if (_glyphs.TryGetValue(army.Type, out var glyph))
                {
                    int gw = (int)(14 * s), gh = (int)(14 * s);
                    sb.Draw(glyph, new Rectangle(rect.X + 2, rect.Y + 2, gw, gh), Color.White);
                }
            }
        }
    }

    public void Dispose()
    {
        foreach (var g in _glyphs.Values) g.Dispose();
        _glyphs.Clear();
    }
}
