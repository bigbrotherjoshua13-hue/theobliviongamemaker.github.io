using HoiSharp.Core.Data;
using HoiSharp.Core.Import;
using HoiSharp.Core.Sim;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;

namespace HoiSharp.Game;

public enum MapMode { Political, Terrain, States, Manpower, War, Flags }

/// <summary>
/// Turns provinces.png into GPU data and draws the map with MapShader.fx.
///
///  * index texture  : one texel per map pixel, R/G = province id (read from provinces.png colours)
///  * ColorLut       : 256x256 texture, one texel per province id = colour for the current map mode
///  * InfoLut        : owner country index + state id per province (for border levels)
///  * TerrainLut     : terrain tint + roughness per province
///
/// Changing the map mode or capturing a province only rewrites the small lookup textures,
/// the big index texture never changes.
/// </summary>
public sealed class MapRenderer : IDisposable
{
    private readonly GraphicsDevice _gd;
    private readonly Effect _fx;
    private readonly MapData _map;
    private readonly GameWorld _world;

    private Texture2D _indexTex = null!;
    private readonly Texture2D _colorLut;
    private readonly Texture2D _infoLut;
    private readonly Texture2D _terrainLut;
    private readonly Color[] _colorData = new Color[65536];
    private readonly Color[] _infoData = new Color[65536];
    private readonly Color[] _terrainData = new Color[65536];

    private bool _dirty = true;
    private float _sinceRebuild;

    public ushort[] PixelIds { get; private set; } = Array.Empty<ushort>();
    public int Width { get; private set; }
    public int Height { get; private set; }

    public MapMode Mode { get; private set; } = MapMode.Political;
    public int SelectedProvince { get; set; }
    public int HoverProvince { get; set; }
    public float Time { get; set; }

    public MapRenderer(GraphicsDevice gd, Effect fx, MapData map, GameWorld world, string provincesPath)
    {
        _gd = gd;
        _fx = fx;
        _map = map;
        _world = world;

        if (map.Provinces.Length > 65536)
            throw new InvalidOperationException("The shader lookup tables support at most 65536 provinces.");

        _colorLut = new Texture2D(gd, 256, 256, false, SurfaceFormat.Color);
        _infoLut = new Texture2D(gd, 256, 256, false, SurfaceFormat.Color);
        _terrainLut = new Texture2D(gd, 256, 256, false, SurfaceFormat.Color);

        LoadProvinceBitmap(provincesPath);
        BuildStaticLuts();
        Rebuild();
    }

    // ------------------------------------------------------------------ province bitmap
    private void LoadProvinceBitmap(string path)
    {
        Color[] px;
        if (path.EndsWith(".bmp", StringComparison.OrdinalIgnoreCase))
        {
            var bmp = BmpReader.Load(path);
            Width = bmp.Width;
            Height = bmp.Height;
            px = new Color[Width * Height];
            for (int k = 0, j = 0; k < px.Length; k++, j += 3)
                px[k] = new Color(bmp.Rgb[j], bmp.Rgb[j + 1], bmp.Rgb[j + 2], (byte)255);
        }
        else
        {
            using var fs = File.OpenRead(path);
            using var src = Texture2D.FromStream(_gd, fs);
            Width = src.Width;
            Height = src.Height;
            px = new Color[Width * Height];
            src.GetData(px);
        }
        PixelIds = new ushort[px.Length];

        int n = _map.Provinces.Length;
        var count = new int[n];
        var sumX = new double[n];
        var sumY = new double[n];
        var minX = new int[n];
        var minY = new int[n];
        var maxX = new int[n];
        var maxY = new int[n];
        Array.Fill(minX, int.MaxValue);
        Array.Fill(minY, int.MaxValue);
        Array.Fill(maxX, -1);
        Array.Fill(maxY, -1);

        int lastKey = -1, lastId = 0;
        int i = 0;
        for (int y = 0; y < Height; y++)
        {
            for (int x = 0; x < Width; x++, i++)
            {
                var c = px[i];
                int key = (c.R << 16) | (c.G << 8) | c.B;
                if (key != lastKey)
                {
                    lastKey = key;
                    lastId = _map.ColorToId.TryGetValue(key, out int id) ? id : 0;
                }
                PixelIds[i] = (ushort)lastId;
                px[i] = new Color(lastId & 255, lastId >> 8, 0, 255);

                count[lastId]++;
                sumX[lastId] += x;
                sumY[lastId] += y;
                if (x < minX[lastId]) minX[lastId] = x;
                if (x > maxX[lastId]) maxX[lastId] = x;
                if (y < minY[lastId]) minY[lastId] = y;
                if (y > maxY[lastId]) maxY[lastId] = y;
            }
        }

        for (int id = 1; id < n; id++)
        {
            var p = _map.Provinces[id];
            p.PixelCount = count[id];
            if (count[id] == 0) continue;
            p.CenterX = (float)(sumX[id] / count[id]);
            p.CenterY = (float)(sumY[id] / count[id]);
            p.MinX = minX[id]; p.MaxX = maxX[id];
            p.MinY = minY[id]; p.MaxY = maxY[id];
        }

        _indexTex = new Texture2D(_gd, Width, Height, false, SurfaceFormat.Color);
        _indexTex.SetData(px);
    }

    // ------------------------------------------------------------------ lookup tables
    private static readonly Dictionary<string, (Color tint, float rough)> TerrainStyle = new()
    {
        ["plains"] = (new Color(150, 176, 96), 0.15f),
        ["forest"] = (new Color(64, 112, 58), 0.25f),
        ["hills"] = (new Color(138, 124, 84), 0.60f),
        ["mountain"] = (new Color(124, 114, 108), 1.00f),
        ["desert"] = (new Color(208, 188, 124), 0.30f),
        ["jungle"] = (new Color(38, 98, 48), 0.30f),
        ["marsh"] = (new Color(98, 128, 98), 0.10f),
        ["urban"] = (new Color(140, 140, 140), 0.10f),
        ["ocean"] = (new Color(30, 60, 100), 0.00f),
    };

    private void BuildStaticLuts()
    {
        for (int id = 1; id < _map.Provinces.Length; id++)
        {
            var p = _map.Provinces[id];
            var key = p.IsLand ? p.Terrain : "ocean";
            var style = TerrainStyle.TryGetValue(key, out var s) ? s : TerrainStyle["plains"];
            _terrainData[id] = new Color(style.tint.R, style.tint.G, style.tint.B, (int)(style.rough * 255f));
        }
        _terrainLut.SetData(_terrainData);
    }

    public void SetMode(MapMode mode)
    {
        if (Mode == mode) return;
        Mode = mode;
        _dirty = true;
        _sinceRebuild = 1f; // rebuild immediately
    }

    public void MarkDirty() => _dirty = true;

    public void Update(float dt)
    {
        Time += dt;
        _sinceRebuild += dt;
        if (_dirty && _sinceRebuild > 0.2f) Rebuild();
    }

    private static Color HsvToColor(float h, float s, float v)
    {
        h = (h % 1f) * 6f;
        int i = (int)h;
        float f = h - i;
        float p = v * (1 - s), q = v * (1 - f * s), t = v * (1 - (1 - f) * s);
        (float r, float g, float b) = i switch
        {
            0 => (v, t, p),
            1 => (q, v, p),
            2 => (p, v, t),
            3 => (p, q, v),
            4 => (t, p, v),
            _ => (v, p, q),
        };
        return new Color(r, g, b);
    }

    private static Color SeaColor(int id)
    {
        // slight variation between sea provinces so that they are distinguishable
        uint hash = unchecked((uint)id * 2654435761u);
        float t = (hash >> 24) / 255f;
        return new Color((int)(28 + 10 * t), (int)(58 + 14 * t), (int)(98 + 16 * t));
    }

    private Color ColorFor(Province p)
    {
        if (!p.IsLand) return SeaColor(p.Id);

        var owner = _map.OwnerOf(p.Id);
        var ownerC = _map.CountryOf(owner);
        var ctrlC = _map.CountryOf(p.Controller);

        switch (Mode)
        {
            case MapMode.Terrain:
                return TerrainStyle.TryGetValue(p.Terrain, out var ts) ? ts.tint : TerrainStyle["plains"].tint;

            case MapMode.States:
                return p.StateId == 0 ? new Color(90, 90, 90) : HsvToColor((p.StateId * 0.6180339f) % 1f, 0.55f, 0.85f);

            case MapMode.Manpower:
            {
                if (p.StateId == 0 || !_map.States.TryGetValue(p.StateId, out var st)) return new Color(60, 60, 60);
                float t = MathHelper.Clamp(MathF.Log10(Math.Max(1, st.Manpower)) / 6f, 0f, 1f);
                return Color.Lerp(new Color(45, 70, 50), new Color(235, 205, 60), t);
            }

            case MapMode.War:
            {
                var me = _world.PlayerTag;
                if (me == null || owner == null) return new Color(95, 95, 95);
                if (p.Controller == me && owner != me) return new Color(190, 230, 90);   // we occupy it
                if (owner == me) return p.Controller == me ? new Color(70, 170, 90) : new Color(200, 110, 40); // lost territory
                if (_world.AtWar(me, owner)) return new Color(190, 60, 60);
                if (_world.Wars.Any(w => w.Involves(owner))) return new Color(205, 150, 60);
                return new Color(105, 105, 105);
            }

            case MapMode.Flags:
            {
                // Base fill is the country colour; the pixel shader adds stripes when FlagMode=1
                if (ownerC == null) return new Color(110, 110, 110);
                var oc = new Color(ownerC.R, ownerC.G, ownerC.B);
                if (ctrlC != null && ctrlC != ownerC)
                    return Color.Lerp(oc, new Color(ctrlC.R, ctrlC.G, ctrlC.B), 0.55f);
                return oc;
            }

            default: // Political
            {
                if (ownerC == null) return new Color(110, 110, 110);
                var oc = new Color(ownerC.R, ownerC.G, ownerC.B);
                if (ctrlC != null && ctrlC != ownerC)
                {
                    var cc = new Color(ctrlC.R, ctrlC.G, ctrlC.B);
                    return Color.Lerp(oc, cc, 0.65f); // occupied land shows the occupier's colour
                }
                return oc;
            }
        }
    }

    public void Rebuild()
    {
        for (int id = 1; id < _map.Provinces.Length; id++)
        {
            var p = _map.Provinces[id];
            _colorData[id] = ColorFor(p);

            var country = p.IsLand ? _map.CountryOf(_map.OwnerOf(id)) : null;
            int idx = country == null ? 0 : Math.Min(255, country.Index);
            int sid = p.StateId;
            _infoData[id] = new Color(idx, sid & 255, (sid >> 8) & 255, p.IsLand ? 0 : 255);
        }
        _colorLut.SetData(_colorData);
        _infoLut.SetData(_infoData);
        _dirty = false;
        _sinceRebuild = 0f;
    }

    // ------------------------------------------------------------------ drawing
    private void Set(string name, float v) => _fx.Parameters[name]?.SetValue(v);

    private RenderTarget2D? _flatTarget;
    private float _flatAge = 99f;
    private int _flatSel = -1, _flatHov = -1;
    private MapMode _flatMode;

    /// <summary>
    /// Renders the whole flat map with MapShader.fx into a (mipmapped) render target that the 2.5D
    /// view uses as its texture. Only redrawn when something changed, plus a few times a second for the water.
    /// </summary>
    public Texture2D GetFlatTexture(SpriteBatch sb, float dt)
    {
        _flatAge += dt;
        bool stale = _flatTarget == null || _flatSel != SelectedProvince || _flatHov != HoverProvince
                     || _flatMode != Mode || _flatAge > 0.25f;
        if (_flatTarget == null)
        {
            int w = Math.Min(Width, 4096);
            int h = (int)Math.Round(Height * (w / (float)Width));
            _flatTarget = new RenderTarget2D(_gd, w, h, true, SurfaceFormat.Color, DepthFormat.None, 0, RenderTargetUsage.PreserveContents);
        }
        if (stale)
        {
            float scale = _flatTarget.Width / (float)Width;
            _gd.SetRenderTarget(_flatTarget);
            DrawMapCore(sb, Matrix.CreateScale(scale, scale, 1f), 0.7f, 0f, wrap: false);
            _gd.SetRenderTarget(null);
            _flatAge = 0f; _flatSel = SelectedProvince; _flatHov = HoverProvince; _flatMode = Mode;
        }
        return _flatTarget;
    }

    public void DrawMap(SpriteBatch sb, Camera2D cam) =>
        DrawMapCore(sb, cam.Transform, cam.Zoom, cam.Zoom > 3f ? 0.5f : 0.9f, wrap: true);

    private void DrawMapCore(SpriteBatch sb, Matrix transform, float zoom, float relief, bool wrap)
    {
        var tex = _fx.Parameters["TexSize"];
        tex?.SetValue(new Vector2(Width, Height));
        Set("Zoom", zoom);
        Set("SelectedId", SelectedProvince);
        Set("HoverId", HoverProvince);
        Set("Time", Time);
        Set("ReliefStrength", relief);
        Set("TerrainBlend", Mode is MapMode.Political or MapMode.Flags ? 0.28f : 0f);
        Set("FlagMode", Mode == MapMode.Flags ? 1f : 0f);
        _fx.Parameters["ColorLut"]?.SetValue(_colorLut);
        _fx.Parameters["InfoLut"]?.SetValue(_infoLut);
        _fx.Parameters["TerrainLut"]?.SetValue(_terrainLut);

        sb.Begin(SpriteSortMode.Immediate, BlendState.Opaque, SamplerState.PointClamp,
                 DepthStencilState.None, RasterizerState.CullNone, _fx, transform);
        for (int k = wrap ? -1 : 0; k <= (wrap ? 1 : 0); k++)
            sb.Draw(_indexTex, new Rectangle(k * Width, 0, Width, Height), Color.White);
        sb.End();
    }

    /// <summary>
    /// Province id under a world position (x wraps around the globe), 0 if none.
    /// Uses a small majority-vote sample so border anti-alias / JPEG-like bleed
    /// does not pick the wrong neighbour province.
    /// </summary>
    public int ProvinceAt(Vector2 world)
    {
        int cy = (int)MathF.Floor(world.Y);
        if (cy < 0 || cy >= Height) return 0;
        int cx = (int)MathF.Floor(world.X) % Width;
        if (cx < 0) cx += Width;

        // radius 1 majority (3x3). Prefer land over sea/unknown when tied.
        Span<(int id, int count)> tallies = stackalloc (int, int)[9];
        int n = 0;
        for (int dy = -1; dy <= 1; dy++)
        {
            int y = cy + dy;
            if (y < 0 || y >= Height) continue;
            for (int dx = -1; dx <= 1; dx++)
            {
                int x = (cx + dx) % Width;
                if (x < 0) x += Width;
                int id = PixelIds[y * Width + x];
                if (id == 0) continue;
                bool found = false;
                for (int i = 0; i < n; i++)
                {
                    if (tallies[i].id == id) { tallies[i].count++; found = true; break; }
                }
                if (!found && n < 9) tallies[n++] = (id, 1);
            }
        }

        if (n == 0) return PixelIds[cy * Width + cx];

        int bestId = 0, bestCount = -1;
        for (int i = 0; i < n; i++)
        {
            int id = tallies[i].id;
            int count = tallies[i].count;
            // centre pixel gets a small bonus so we still favour the exact click
            if (id == PixelIds[cy * Width + cx]) count += 1;
            // prefer land over sea on ties
            bool land = id > 0 && id < _map.Provinces.Length && _map.Provinces[id].IsLand;
            bool bestLand = bestId > 0 && bestId < _map.Provinces.Length && _map.Provinces[bestId].IsLand;
            if (count > bestCount || (count == bestCount && land && !bestLand))
            {
                bestCount = count;
                bestId = id;
            }
        }
        return bestId;
    }

    public void Dispose()
    {
        _indexTex?.Dispose();
        _colorLut.Dispose();
        _infoLut.Dispose();
        _terrainLut.Dispose();
        _flatTarget?.Dispose();
    }
}
