using Microsoft.Xna.Framework;

namespace HoiSharp.Game;

/// <summary>Pan / zoom camera over the flat world map. The map wraps horizontally.</summary>
public sealed class Camera2D
{
    public Vector2 Center;        // map pixel shown in the middle of the screen
    public float Zoom = 0.5f;     // screen pixels per map pixel
    public int ViewWidth, ViewHeight;
    public int MapWidth, MapHeight;

    public const float MinZoom = 0.2f;
    public const float MaxZoom = 12f;

    public Matrix Transform =>
        Matrix.CreateTranslation(-Center.X, -Center.Y, 0f) *
        Matrix.CreateScale(Zoom, Zoom, 1f) *
        Matrix.CreateTranslation(ViewWidth * 0.5f, ViewHeight * 0.5f, 0f);

    public Vector2 ScreenToWorld(Vector2 screen) =>
        (screen - new Vector2(ViewWidth * 0.5f, ViewHeight * 0.5f)) / Zoom + Center;

    public Vector2 WorldToScreen(Vector2 world) =>
        (world - Center) * Zoom + new Vector2(ViewWidth * 0.5f, ViewHeight * 0.5f);

    public void Pan(Vector2 screenDelta)
    {
        Center -= screenDelta / Zoom;
        Clamp();
    }

    /// <summary>Zoom keeping the world point under the cursor fixed.</summary>
    public void ZoomAt(Vector2 screenPoint, float factor)
    {
        var before = ScreenToWorld(screenPoint);
        Zoom = MathHelper.Clamp(Zoom * factor, MinZoom, MaxZoom);
        var after = ScreenToWorld(screenPoint);
        Center += before - after;
        Clamp();
    }

    public void FocusOn(Vector2 world, float? zoom = null)
    {
        Center = world;
        if (zoom.HasValue) Zoom = MathHelper.Clamp(zoom.Value, MinZoom, MaxZoom);
        Clamp();
    }

    public void Clamp()
    {
        // wrap horizontally, clamp vertically
        if (MapWidth > 0)
        {
            Center.X %= MapWidth;
            if (Center.X < 0) Center.X += MapWidth;
        }
        float halfH = ViewHeight * 0.5f / Zoom;
        float minY = Math.Min(halfH, MapHeight * 0.5f);
        float maxY = Math.Max(MapHeight - halfH, MapHeight * 0.5f);
        Center.Y = MathHelper.Clamp(Center.Y, minY, maxY);
    }

    /// <summary>Wrap a map x coordinate into [0, MapWidth).</summary>
    public int WrapX(float x)
    {
        int xi = (int)MathF.Floor(x) % MapWidth;
        return xi < 0 ? xi + MapWidth : xi;
    }
}
