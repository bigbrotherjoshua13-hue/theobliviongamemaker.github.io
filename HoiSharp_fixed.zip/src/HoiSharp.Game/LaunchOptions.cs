namespace HoiSharp.Game;

/// <summary>Command line options. The launcher fills these in; every option also works from a terminal.</summary>
public sealed class LaunchOptions
{
    /// <summary>Folder that contains mod_base/ and mods/.</summary>
    public string DataRoot { get; set; } = FindDataRoot();

    /// <summary>Mods to load on top of mod_base, in load order.</summary>
    public List<string> Mods { get; } = new();

    public string? PlayerTag { get; set; }
    public int Width { get; set; } = 1600;
    public int Height { get; set; } = 900;
    public bool Fullscreen { get; set; }
    public DateTime StartDate { get; set; } = new DateTime(1936, 1, 1);

    /// <summary>Id (file name) or name of a scenario; its start date wins over --date.</summary>
    public string? ScenarioId { get; set; }

    /// <summary>Start in scenario builder mode.</summary>
    public bool Builder { get; set; }

    /// <summary>Start in the 2.5D view (F3 toggles in game).</summary>
    public bool Start3D { get; set; }

    /// <summary>Start in observe mode (no player country, watch AI).</summary>
    public bool Observe { get; set; }

    /// <summary>If set, import HOI4 map from this path (or auto-detect if "auto") then exit unless --play is also given.</summary>
    public string? ImportHoi4Path { get; set; }

    /// <summary>After a successful --import-hoi4, also launch the game with the imported mod.</summary>
    public bool PlayAfterImport { get; set; }

    public static LaunchOptions Parse(string[] args)
    {
        var o = new LaunchOptions();
        for (int i = 0; i < args.Length; i++)
        {
            string a = args[i];
            string? Next() => i + 1 < args.Length ? args[++i] : null;

            switch (a.ToLowerInvariant())
            {
                case "--data": if (Next() is { } d) o.DataRoot = d; break;
                case "--mods":
                    if (Next() is { } m)
                        o.Mods.AddRange(m.Split(',', StringSplitOptions.RemoveEmptyEntries | StringSplitOptions.TrimEntries));
                    break;
                case "--player": o.PlayerTag = Next()?.ToUpperInvariant(); break;
                case "--width": if (int.TryParse(Next(), out int w)) o.Width = w; break;
                case "--height": if (int.TryParse(Next(), out int h)) o.Height = h; break;
                case "--fullscreen": o.Fullscreen = true; break;
                case "--scenario": o.ScenarioId = Next(); break;
                case "--builder": o.Builder = true; break;
                case "--observe": o.Observe = true; break;
                case "--3d": o.Start3D = true; break;
                case "--date": if (DateTime.TryParse(Next(), out var dt)) o.StartDate = dt; break;
                case "--import-hoi4":
                    o.ImportHoi4Path = Next() ?? "auto";
                    break;
                case "--play": o.PlayAfterImport = true; break;
            }
        }
        return o;
    }

    /// <summary>Walks up from the executable looking for a data/mod_base folder.</summary>
    public static string FindDataRoot()
    {
        var dir = new DirectoryInfo(AppContext.BaseDirectory);
        while (dir != null)
        {
            var candidate = Path.Combine(dir.FullName, "data");
            if (Directory.Exists(Path.Combine(candidate, "mod_base"))) return candidate;
            dir = dir.Parent;
        }
        return Path.Combine(AppContext.BaseDirectory, "data");
    }
}
