using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;

namespace HoiSharp.Game;

/// <summary>
/// 2.5D view: a heightfield mesh (from map/heightmap.png) textured with the flat map that
/// MapRenderer draws into a RenderTarget, seen through an orbiting perspective camera.
/// World units: x = map pixel x, z = map pixel y (north is -z), y = height (sea is 0).
/// </summary>
public sealed class Map3DView : IDisposable
{
    public const float HeightScale = 70f;  // height of the highest peaks in map pixels
    private const float SeaLevel = 95f / 255f;
    private const int CellsX = 352, CellsY = 128;

    private readonly GraphicsDevice _gd;
    private readonly Effect _fx;
    private readonly int _mapW, _mapH;
    private readonly float[] _heights;   // per heightmap texel, world units, 0 for sea
    private readonly int _hw, _hh;
    private readonly VertexBuffer _vb;
    private readonly IndexBuffer _ib;
    private readonly int _triangles;

    // camera
    public Vector2 Target;               // ground point (map pixels) in the middle of the screen
    public float Distance = 1100f;
    public float Yaw;                    // radians, 0 = looking north
    public float Pitch = MathHelper.ToRadians(52f);

    /// <summary>
    /// When true, terrain height is forced to 0 so the camera can pan sideways
    /// without mountains blocking the view (flat 3D board).
    /// </summary>
    public bool FlatTerrain;

    public const float MinDistance = 120f, MaxDistance = 5000f;

    private Matrix _view, _proj, _viewProj;
    private Vector3 _eye;

    public Map3DView(GraphicsDevice gd, Effect fx, string heightmapPath, int mapW, int mapH)
    {
        _gd = gd;
        _fx = fx;
        _mapW = mapW;
        _mapH = mapH;

        // ---- heights
        if (File.Exists(heightmapPath))
        {
            using var fs = File.OpenRead(heightmapPath);
            using var tex = Texture2D.FromStream(gd, fs);
            _hw = tex.Width; _hh = tex.Height;
            var px = new Color[_hw * _hh];
            tex.GetData(px);
            _heights = new float[px.Length];
            for (int i = 0; i < px.Length; i++)
            {
                float v = px[i].R / 255f;
                _heights[i] = v <= SeaLevel ? 0f : (v - SeaLevel) / (1f - SeaLevel) * HeightScale;
            }
        }
        else
        {
            _hw = 2; _hh = 2;
            _heights = new float[4];
        }

        // ---- mesh
        int vx = CellsX + 1, vy = CellsY + 1;
        var verts = new VertexPositionNormalTexture[vx * vy];
        for (int j = 0; j < vy; j++)
        {
            for (int i = 0; i < vx; i++)
            {
                float u = i / (float)CellsX, v = j / (float)CellsY;
                float x = u * mapW, z = v * mapH;
                float h = HeightAt(x, z);
                float e = mapW / (float)CellsX;
                float hl = HeightAt(x - e, z), hr = HeightAt(x + e, z);
                float hu = HeightAt(x, z - e), hd = HeightAt(x, z + e);
                // exaggerate slopes a little so low relief is visible from far away
                var n = Vector3.Normalize(new Vector3((hl - hr) * 1.6f, 2f * e, (hu - hd) * 1.6f));
                verts[j * vx + i] = new VertexPositionNormalTexture(new Vector3(x, h, z), n, new Vector2(u, v));
            }
        }
        var idx = new ushort[CellsX * CellsY * 6];
        int k = 0;
        for (int j = 0; j < CellsY; j++)
        {
            for (int i = 0; i < CellsX; i++)
            {
                ushort a = (ushort)(j * vx + i), b = (ushort)(a + 1), c = (ushort)(a + vx), d = (ushort)(c + 1);
                idx[k++] = a; idx[k++] = b; idx[k++] = c;
                idx[k++] = b; idx[k++] = d; idx[k++] = c;
            }
        }
        _triangles = idx.Length / 3;
        _vb = new VertexBuffer(gd, typeof(VertexPositionNormalTexture), verts.Length, BufferUsage.WriteOnly);
        _vb.SetData(verts);
        _ib = new IndexBuffer(gd, IndexElementSize.SixteenBits, idx.Length, BufferUsage.WriteOnly);
        _ib.SetData(idx);

        Target = new Vector2(mapW * 0.5f, mapH * 0.5f);
    }

    /// <summary>Terrain height (world units) at a map position, bilinear.</summary>
    public float HeightAt(float x, float z)
    {
        float fx = Math.Clamp(x / _mapW * (_hw - 1), 0, _hw - 1);
        float fy = Math.Clamp(z / _mapH * (_hh - 1), 0, _hh - 1);
        int x0 = (int)fx, y0 = (int)fy;
        int x1 = Math.Min(x0 + 1, _hw - 1), y1 = Math.Min(y0 + 1, _hh - 1);
        float tx = fx - x0, ty = fy - y0;
        float a = _heights[y0 * _hw + x0], b = _heights[y0 * _hw + x1];
        float c = _heights[y1 * _hw + x0], d = _heights[y1 * _hw + x1];
        float h = MathHelper.Lerp(MathHelper.Lerp(a, b, tx), MathHelper.Lerp(c, d, tx), ty);
        return FlatTerrain ? 0f : h;
    }

    // ------------------------------------------------------------------ camera
    public void UpdateCamera()
    {
        var vp = _gd.Viewport;
        float minPitch = FlatTerrain ? MathHelper.ToRadians(25f) : MathHelper.ToRadians(20f);
        Pitch = MathHelper.Clamp(Pitch, minPitch, MathHelper.ToRadians(85f));
        Distance = MathHelper.Clamp(Distance, MinDistance, MaxDistance);
        Target.X = MathHelper.Clamp(Target.X, 0, _mapW);
        Target.Y = MathHelper.Clamp(Target.Y, 0, _mapH);

        var target = new Vector3(Target.X, 0f, Target.Y);
        float cp = MathF.Cos(Pitch);
        _eye = target + new Vector3(-MathF.Sin(Yaw) * cp, MathF.Sin(Pitch), MathF.Cos(Yaw) * cp) * Distance;
        _view = Matrix.CreateLookAt(_eye, target, Vector3.Up);
        _proj = Matrix.CreatePerspectiveFieldOfView(MathHelper.ToRadians(45f), vp.AspectRatio, 20f, 30000f);
        _viewProj = _view * _proj;
    }

    /// <summary>Move the camera target; (dx, dy) is in screen-aligned map units (right, down).</summary>
    public void Move(Vector2 d)
    {
        float s = MathF.Sin(Yaw), c = MathF.Cos(Yaw);
        // forward (up the screen) is (sin yaw, -cos yaw) in map x/y; right is (cos yaw, sin yaw)
        Target += new Vector2(c * d.X - s * d.Y, s * d.X + c * d.Y);
    }

    public float PanScale => Distance / Math.Max(1, _gd.Viewport.Height) * 1.1f;

    public void Zoom(float factor) => Distance = MathHelper.Clamp(Distance / factor, MinDistance, MaxDistance);

    public void FocusOn(Vector2 mapPx, float? distance = null)
    {
        Target = mapPx;
        if (distance.HasValue) Distance = distance.Value;
    }

    // ------------------------------------------------------------------ projection / picking
    /// <summary>Screen position of a map pixel (on the terrain), or null when it is behind the camera.</summary>
    public Vector2? Project(Vector2 mapPx, float lift = 3f)
    {
        var p = new Vector4(mapPx.X, HeightAt(mapPx.X, mapPx.Y) + lift, mapPx.Y, 1f);
        var clip = Vector4.Transform(p, _viewProj);
        if (clip.W <= 0.01f) return null;
        var vp = _gd.Viewport;
        float nx = clip.X / clip.W, ny = clip.Y / clip.W;
        if (MathF.Abs(nx) > 2f || MathF.Abs(ny) > 2f) return null;
        return new Vector2((nx * 0.5f + 0.5f) * vp.Width, (1f - (ny * 0.5f + 0.5f)) * vp.Height);
    }

    /// <summary>Ray vs heightfield. Returns the map pixel under the screen position or (-1,-1).</summary>
    public Vector2 Pick(Vector2 screen)
    {
        var vp = _gd.Viewport;
        var near = vp.Unproject(new Vector3(screen, 0f), _proj, _view, Matrix.Identity);
        var far = vp.Unproject(new Vector3(screen, 1f), _proj, _view, Matrix.Identity);
        var dir = Vector3.Normalize(far - near);
        float step = Math.Max(2f, Distance * 0.008f);
        float maxT = Distance * 4f;

        Vector3 prev = near;
        for (float t = 0; t < maxT; t += step)
        {
            var p = near + dir * t;
            if (p.X < -50 || p.X > _mapW + 50 || p.Z < -50 || p.Z > _mapH + 50)
            {
                // outside the map: keep going, the ray may enter later
                prev = p;
                continue;
            }
            if (p.Y <= HeightAt(p.X, p.Z))
            {
                // bisect between prev and p
                var lo = prev; var hi = p;
                for (int i = 0; i < 8; i++)
                {
                    var mid = (lo + hi) * 0.5f;
                    if (mid.Y <= HeightAt(mid.X, mid.Z)) hi = mid; else lo = mid;
                }
                return new Vector2(hi.X, hi.Z);
            }
            prev = p;
        }
        return new Vector2(-1, -1);
    }

    // ------------------------------------------------------------------ drawing
    public void Draw(Texture2D mapTexture)
    {
        _gd.DepthStencilState = DepthStencilState.Default;
        _gd.RasterizerState = RasterizerState.CullNone;
        _gd.BlendState = BlendState.Opaque;
        _gd.SamplerStates[0] = SamplerState.AnisotropicClamp;

        _fx.Parameters["WorldViewProjection"].SetValue(_viewProj);
        _fx.Parameters["LightDir"].SetValue(Vector3.Normalize(new Vector3(-0.45f, 0.8f, -0.35f)));
        _fx.Parameters["CameraPos"].SetValue(_eye);
        _fx.Parameters["HeightMul"]?.SetValue(FlatTerrain ? 0f : 1f);
        _fx.Parameters["FogColor"].SetValue(new Vector3(18f / 255f, 26f / 255f, 40f / 255f));
        _fx.Parameters["FogStart"].SetValue(Distance * 1.6f);
        _fx.Parameters["FogEnd"].SetValue(Distance * 6f);
        _fx.Parameters["CurveAmount"]?.SetValue(0.85f); // cylindrical bend (HOI4-ish globe feel)
        _fx.Parameters["MapWidth"]?.SetValue((float)_mapW);
        _fx.Parameters["MapTexture"].SetValue(mapTexture);

        _gd.SetVertexBuffer(_vb);
        _gd.Indices = _ib;
        foreach (var pass in _fx.CurrentTechnique.Passes)
        {
            pass.Apply();
            _gd.DrawIndexedPrimitives(PrimitiveType.TriangleList, 0, 0, _triangles);
        }
    }

    public void Dispose()
    {
        _vb.Dispose();
        _ib.Dispose();
    }
}
