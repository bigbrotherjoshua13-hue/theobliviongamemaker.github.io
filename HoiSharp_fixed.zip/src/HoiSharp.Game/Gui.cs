using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;

namespace HoiSharp.Game;

/// <summary>GUI frame sprites (gui/*.png in the mod file system, so mods can replace them) and 9-slice drawing.</summary>
public sealed class Gui : IDisposable
{
    public Texture2D? EventFrame { get; }
    public Texture2D? LeaderFrame { get; }
    private readonly Texture2D _pixel;

    /// <summary>Border thickness of the frame sprites in texels (the sprites are 74x84 with a 9 px border).</summary>
    public const int Border = 9;

    public Gui(GraphicsDevice gd, Texture2D pixel, Func<string, string?> resolve)
    {
        _pixel = pixel;
        EventFrame = Load(gd, resolve("gui/event_frame.png"));
        LeaderFrame = Load(gd, resolve("gui/leader_frame.png"));
    }

    private static Texture2D? Load(GraphicsDevice gd, string? path)
    {
        if (path == null || !File.Exists(path)) return null;
        using var fs = File.OpenRead(path);
        return Texture2D.FromStream(gd, fs);
    }

    /// <summary>Draws a frame sprite stretched to <paramref name="r"/>, corners and edges kept crisp. Falls back to a plain cream border.</summary>
    public void DrawFrame(SpriteBatch sb, Texture2D? tex, Rectangle r, int scaledBorder = 0)
    {
        int b = scaledBorder > 0 ? scaledBorder : Border;
        if (tex == null)
        {
            var cream = new Color(245, 228, 156);
            sb.Draw(_pixel, new Rectangle(r.X, r.Y, r.Width, b), cream);
            sb.Draw(_pixel, new Rectangle(r.X, r.Bottom - b, r.Width, b), cream);
            sb.Draw(_pixel, new Rectangle(r.X, r.Y, b, r.Height), cream);
            sb.Draw(_pixel, new Rectangle(r.Right - b, r.Y, b, r.Height), cream);
            return;
        }

        int tb = Border, tw = tex.Width, th = tex.Height;
        int[] sx = { 0, tb, tw - tb, tw };
        int[] sy = { 0, tb, th - tb, th };
        int[] dx = { r.X, r.X + b, r.Right - b, r.Right };
        int[] dy = { r.Y, r.Y + b, r.Bottom - b, r.Bottom };
        for (int j = 0; j < 3; j++)
        {
            for (int i = 0; i < 3; i++)
            {
                if (i == 1 && j == 1) continue; // the middle is transparent: content goes there
                var src = new Rectangle(sx[i], sy[j], sx[i + 1] - sx[i], sy[j + 1] - sy[j]);
                var dst = new Rectangle(dx[i], dy[j], dx[i + 1] - dx[i], dy[j + 1] - dy[j]);
                if (dst.Width > 0 && dst.Height > 0) sb.Draw(tex, dst, src, Color.White);
            }
        }
    }

    public static Rectangle Inner(Rectangle r, int scaledBorder = 0)
    {
        int b = scaledBorder > 0 ? scaledBorder : Border;
        return new Rectangle(r.X + b, r.Y + b, r.Width - 2 * b, r.Height - 2 * b);
    }

    public void Dispose()
    {
        EventFrame?.Dispose();
        LeaderFrame?.Dispose();
    }
}
