using HoiSharp.Core.Events;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;

namespace HoiSharp.Game;

/// <summary>
/// The event popup. Layout matches the event frame sprite: picture area on top (with the title),
/// grey text panel below with the description and one cream button per option.
/// </summary>
public sealed class EventWindow
{
    private readonly Queue<ScriptedEvent> _queue = new();
    public ScriptedEvent? Current { get; private set; }
    public bool Open => Current != null;
    private Rectangle[] _buttons = Array.Empty<Rectangle>();

    public void Show(ScriptedEvent e)
    {
        if (Current == null) Current = e; else _queue.Enqueue(e);
    }

    /// <summary>Returns the chosen option when the player clicked or pressed 1-9, otherwise null.</summary>
    public ScriptedOption? HandleInput(KeyboardState ks, KeyboardState prevKs, MouseState ms, MouseState prevMs)
    {
        if (Current == null) return null;
        int pick = -1;
        for (int i = 0; i < Math.Min(9, Current.Options.Count); i++)
            if (ks.IsKeyDown(Keys.D1 + i) && prevKs.IsKeyUp(Keys.D1 + i)) pick = i;
        if (ms.LeftButton == ButtonState.Pressed && prevMs.LeftButton == ButtonState.Released)
            for (int i = 0; i < _buttons.Length; i++)
                if (_buttons[i].Contains(ms.X, ms.Y)) pick = i;
        if (pick < 0 || pick >= Current.Options.Count) return null;

        var chosen = Current.Options[pick];
        Current = _queue.Count > 0 ? _queue.Dequeue() : null;
        return chosen;
    }

    private static List<string> Wrap(SpriteFont font, string text, float width)
    {
        var lines = new List<string>();
        var line = "";
        foreach (var word in text.Split(' ', StringSplitOptions.RemoveEmptyEntries))
        {
            var test = line.Length == 0 ? word : line + " " + word;
            if (font.MeasureString(test).X > width && line.Length > 0) { lines.Add(line); line = word; }
            else line = test;
        }
        if (line.Length > 0) lines.Add(line);
        return lines;
    }

    public void Draw(SpriteBatch sb, SpriteFont font, Texture2D pixel, Gui gui, int vw, int vh, MouseState ms)
    {
        if (Current == null) return;
        var e = Current;

        sb.Draw(pixel, new Rectangle(0, 0, vw, vh), new Color(0, 0, 0, 120)); // dim the map

        int w = Math.Min(560, vw - 40);
        float lh = font.LineSpacing;
        var lines = Wrap(font, e.Desc, w - 2 * Gui.Border - 28);
        int pictureH = 170;
        int textH = (int)(lines.Count * lh) + 24;
        int buttonsH = e.Options.Count * 40 + 12;
        int h = Math.Min(vh - 20, Gui.Border * 2 + pictureH + textH + buttonsH);
        var frame = new Rectangle((vw - w) / 2, (vh - h) / 2, w, h);
        var inner = Gui.Inner(frame);

        // picture area (placeholder: gradient in the event's picture colour)
        var pic = new Rectangle(inner.X, inner.Y, inner.Width, pictureH);
        var c = new Color(e.PictureColor.r, e.PictureColor.g, e.PictureColor.b);
        for (int i = 0; i < pic.Height; i += 2)
        {
            float t = i / (float)pic.Height;
            sb.Draw(pixel, new Rectangle(pic.X, pic.Y + i, pic.Width, 2), Color.Lerp(Color.Lerp(c, Color.White, 0.35f), c * 0.6f, t));
        }
        // text panel (the grey of the frame sprite)
        var panel = new Rectangle(inner.X, pic.Bottom, inner.Width, inner.Bottom - pic.Bottom);
        sb.Draw(pixel, panel, new Color(180, 180, 180));
        gui.DrawFrame(sb, gui.EventFrame, frame);

        // title on the picture
        var ts = font.MeasureString(e.Title);
        var tp = new Vector2(pic.X + (pic.Width - ts.X) / 2f, pic.Bottom - ts.Y - 12);
        sb.DrawString(font, e.Title, tp + new Vector2(1, 1), Color.Black);
        sb.DrawString(font, e.Title, tp, Color.White);

        // description
        float y = panel.Y + 12;
        foreach (var l in lines)
        {
            sb.DrawString(font, l, new Vector2(panel.X + 14, y), new Color(25, 25, 25));
            y += lh;
        }

        // option buttons
        _buttons = new Rectangle[e.Options.Count];
        float by = panel.Bottom - buttonsH + 6;
        for (int i = 0; i < e.Options.Count; i++)
        {
            var r = new Rectangle(panel.X + 14, (int)by, panel.Width - 28, 34);
            _buttons[i] = r;
            bool hot = r.Contains(ms.X, ms.Y);
            sb.Draw(pixel, r, hot ? new Color(255, 240, 180) : new Color(245, 228, 156));
            sb.Draw(pixel, new Rectangle(r.X, r.Y, r.Width, 1), Color.Black);
            sb.Draw(pixel, new Rectangle(r.X, r.Bottom - 1, r.Width, 1), Color.Black);
            sb.Draw(pixel, new Rectangle(r.X, r.Y, 1, r.Height), Color.Black);
            sb.Draw(pixel, new Rectangle(r.Right - 1, r.Y, 1, r.Height), Color.Black);
            string label = $"{i + 1}.  {e.Options[i].Name}";
            var ls = font.MeasureString(label);
            sb.DrawString(font, label, new Vector2(r.X + 12, r.Y + (r.Height - ls.Y) / 2f), new Color(25, 25, 25));
            by += 40;
        }
    }
}
