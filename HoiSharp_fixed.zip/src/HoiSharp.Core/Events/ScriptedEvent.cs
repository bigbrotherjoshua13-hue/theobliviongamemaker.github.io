using System.Globalization;
using HoiSharp.Core.Modding;
using HoiSharp.Core.Paradox;

namespace HoiSharp.Core.Events;

public sealed class ScriptedEffect
{
    public string Kind = "";     // war, peace, message
    public string Arg = "";
}

public sealed class ScriptedOption
{
    public string Name = "";
    public List<ScriptedEffect> Effects = new();
}

public sealed class ScriptedEvent
{
    public string Id = "";
    public string Title = "";
    public string Desc = "";
    public DateTime? Date;
    public (byte r, byte g, byte b) PictureColor = (40, 60, 90);
    public List<ScriptedOption> Options = new();
    public bool Fired;

    /// <summary>Loads events/*.txt from every loaded mod (a later event with the same id replaces an earlier one).</summary>
    public static List<ScriptedEvent> LoadAll(ModFileSystem fs)
    {
        var byId = new Dictionary<string, ScriptedEvent>(StringComparer.OrdinalIgnoreCase);
        foreach (var file in fs.ListFilesInLoadOrder("events"))
        {
            PNode root;
            try { root = ParadoxParser.ParseFile(file); }
            catch (Exception) { continue; }
            foreach (var n in root.ChildrenNamed("event"))
            {
                var e = new ScriptedEvent
                {
                    Id = n.Str("id") ?? "",
                    Title = n.Str("title") ?? "",
                    Desc = n.Str("desc") ?? "",
                };
                if (e.Id.Length == 0) continue;
                if (n.Str("date") is { } ds) e.Date = ParseDate(ds);
                if (n.Child("picture_color") is { } pc)
                {
                    var v = pc.Ints().ToList();
                    if (v.Count >= 3) e.PictureColor = ((byte)v[0], (byte)v[1], (byte)v[2]);
                }
                foreach (var o in n.ChildrenNamed("option"))
                {
                    var opt = new ScriptedOption { Name = o.Str("name") ?? "OK" };
                    foreach (var c in o.Children)
                    {
                        if (c.Key is "war" or "peace" or "message" && c.Value != null)
                            opt.Effects.Add(new ScriptedEffect { Kind = c.Key, Arg = c.Value });
                    }
                    e.Options.Add(opt);
                }
                if (e.Options.Count == 0) e.Options.Add(new ScriptedOption { Name = "OK" });
                byId[e.Id] = e;
            }
        }
        return byId.Values.ToList();
    }

    private static DateTime? ParseDate(string s)
    {
        var p = s.Split('.', '-');
        if (p.Length == 3 && int.TryParse(p[0], NumberStyles.Integer, CultureInfo.InvariantCulture, out int y)
            && int.TryParse(p[1], out int m) && int.TryParse(p[2], out int d))
        {
            try { return new DateTime(y, m, d); } catch (ArgumentOutOfRangeException) { }
        }
        return null;
    }
}
