using System.Diagnostics;
using System.IO.Compression;
using System.Security.Cryptography;
using System.Text.Json;
using HoiSharp.Core.Diagnostics;

namespace HoiSharp.Core;

/// <summary>Current version, read from version.txt next to data/ (default 0.1.0).</summary>
public static class AppVersion
{
    public static string Current { get; } = Read();

    private static string Read()
    {
        try
        {
            var p = Path.Combine(AppPaths.Root, "version.txt");
            if (File.Exists(p)) return File.ReadAllText(p).Trim();
        }
        catch (Exception) { }
        return "0.1.0";
    }

    /// <summary>True when <paramref name="candidate"/> is a higher version than <paramref name="current"/> (1.2.10 > 1.2.9).</summary>
    public static bool IsNewer(string candidate, string current)
    {
        static int[] Parts(string v) => v.Trim().TrimStart('v', 'V').Split('.', '-', '+')
            .Select(p => int.TryParse(p, out int n) ? n : 0).ToArray();
        var a = Parts(candidate); var b = Parts(current);
        for (int i = 0; i < Math.Max(a.Length, b.Length); i++)
        {
            int x = i < a.Length ? a[i] : 0, y = i < b.Length ? b[i] : 0;
            if (x != y) return x > y;
        }
        return false;
    }
}

/// <summary>Published by the update server as a small JSON file (see README).</summary>
public sealed class UpdateInfo
{
    public string Version { get; set; } = "";
    public string Url { get; set; } = "";
    public string? Sha256 { get; set; }
    public string? Notes { get; set; }
}

/// <summary>Settings in update.json next to version.txt.</summary>
public sealed class UpdateSettings
{
    /// <summary>URL of the manifest JSON: { "version": "0.2.0", "url": "https://.../HoiSharp.zip", "sha256": "...", "notes": "..." }</summary>
    public string ManifestUrl { get; set; } = "";
    public bool AutoCheck { get; set; } = true;

    public static string FilePath => Path.Combine(AppPaths.Root, "update.json");

    public static UpdateSettings Load()
    {
        try
        {
            if (File.Exists(FilePath))
                return JsonSerializer.Deserialize<UpdateSettings>(File.ReadAllText(FilePath), Updater.Json) ?? new UpdateSettings();
        }
        catch (Exception ex) { AppLog.Warn("Could not read update.json: " + ex.Message); }
        return new UpdateSettings();
    }
}

/// <summary>
/// Check, download, verify and apply updates. The update is a zip of the project; it is unpacked into
/// updates/staging and a batch file copies it over the install after the game and launcher have closed
/// (keeping data/user, logs, crashes, update.json and your own mods), then rebuilds with run.bat.
/// </summary>
public static class Updater
{
    internal static readonly JsonSerializerOptions Json = new() { PropertyNameCaseInsensitive = true, ReadCommentHandling = JsonCommentHandling.Skip, WriteIndented = true };
    private static readonly HttpClient Http = new() { Timeout = TimeSpan.FromSeconds(60) };

    /// <summary>Returns the update when a newer one is published, null when up to date or updates are not configured.</summary>
    public static async Task<UpdateInfo?> CheckAsync(UpdateSettings settings, CancellationToken ct = default)
    {
        if (string.IsNullOrWhiteSpace(settings.ManifestUrl)) return null;
        try
        {
            AppLog.Info("Checking for updates: " + settings.ManifestUrl);
            using var req = new HttpRequestMessage(HttpMethod.Get, settings.ManifestUrl);
            req.Headers.UserAgent.ParseAdd("HoiSharp/" + AppVersion.Current);
            using var resp = await Http.SendAsync(req, ct).ConfigureAwait(false);
            resp.EnsureSuccessStatusCode();
            var info = JsonSerializer.Deserialize<UpdateInfo>(await resp.Content.ReadAsStringAsync(ct).ConfigureAwait(false), Json);
            if (info == null || info.Version.Length == 0 || info.Url.Length == 0) { AppLog.Warn("Update manifest is incomplete."); return null; }
            bool newer = AppVersion.IsNewer(info.Version, AppVersion.Current);
            AppLog.Info($"Latest version {info.Version}, installed {AppVersion.Current}: {(newer ? "update available" : "up to date")}");
            return newer ? info : null;
        }
        catch (Exception ex)
        {
            AppLog.Warn("Update check failed: " + ex.Message);
            return null;
        }
    }

    /// <summary>Downloads and unpacks the update; returns the path of the batch file that applies it.</summary>
    public static async Task<string> DownloadAsync(UpdateInfo info, IProgress<double>? progress = null, CancellationToken ct = default)
    {
        Directory.CreateDirectory(AppPaths.UpdatesDir);
        string zipPath = Path.Combine(AppPaths.UpdatesDir, $"HoiSharp_{info.Version}.zip");
        AppLog.Info($"Downloading update {info.Version} from {info.Url}");

        using (var resp = await Http.GetAsync(info.Url, HttpCompletionOption.ResponseHeadersRead, ct).ConfigureAwait(false))
        {
            resp.EnsureSuccessStatusCode();
            long total = resp.Content.Headers.ContentLength ?? -1;
            await using var src = await resp.Content.ReadAsStreamAsync(ct).ConfigureAwait(false);
            await using var dst = File.Create(zipPath);
            var buf = new byte[81920];
            long done = 0;
            int n;
            while ((n = await src.ReadAsync(buf, ct).ConfigureAwait(false)) > 0)
            {
                await dst.WriteAsync(buf.AsMemory(0, n), ct).ConfigureAwait(false);
                done += n;
                if (total > 0) progress?.Report(done / (double)total);
            }
        }

        if (!string.IsNullOrWhiteSpace(info.Sha256))
        {
            string actual;
            await using (var fs = File.OpenRead(zipPath))
                actual = Convert.ToHexString(await SHA256.HashDataAsync(fs, ct).ConfigureAwait(false));
            if (!actual.Equals(info.Sha256.Trim(), StringComparison.OrdinalIgnoreCase))
            {
                File.Delete(zipPath);
                throw new InvalidDataException("The downloaded update does not match its checksum and was deleted.");
            }
        }

        string staging = Path.Combine(AppPaths.UpdatesDir, "staging");
        if (Directory.Exists(staging)) Directory.Delete(staging, true);
        ZipFile.ExtractToDirectory(zipPath, staging);

        // zips made by "zip the HoiSharp folder" have one top level folder
        string source = staging;
        var subs = Directory.GetDirectories(staging);
        if (!Directory.Exists(Path.Combine(staging, "data")) && subs.Length == 1) source = subs[0];
        if (!File.Exists(Path.Combine(source, "run.bat")) && !Directory.Exists(Path.Combine(source, "src")))
            throw new InvalidDataException("The update zip does not look like a HoiSharp project (no run.bat or src folder).");

        File.WriteAllText(Path.Combine(source, "version.txt"), info.Version);
        string bat = Path.Combine(AppPaths.UpdatesDir, "apply_update.bat");
        File.WriteAllText(bat, BuildBatch(source, AppPaths.Root, Environment.ProcessId));
        AppLog.Info("Update unpacked, ready to apply: " + bat);
        return bat;
    }

    private static string BuildBatch(string source, string target, int waitForPid)
    {
        // a trailing backslash would escape the closing quote in robocopy arguments
        source = source.TrimEnd('\\', '/');
        target = target.TrimEnd('\\', '/');
        return BuildLines(source, target, waitForPid);
    }

    private static string BuildLines(string source, string target, int waitForPid) => string.Join("\r\n", new[]
    {
        "@echo off",
        "echo Waiting for HoiSharp to close...",
        $":wait",
        $"tasklist /FI \"PID eq {waitForPid}\" 2>nul | find \"{waitForPid}\" >nul",
        "if not errorlevel 1 ( timeout /t 1 /nobreak >nul & goto wait )",
        "taskkill /F /IM HoiSharp.exe >nul 2>&1",
        "echo Installing update...",
        $"robocopy \"{source}\" \"{target}\" /E /NFL /NDL /NJH /NJS /XD user logs crashes updates .dotnet out obj bin mods /XF update.json",
        "if errorlevel 8 ( echo Copy failed. & pause & exit /b 1 )",
        $"cd /d \"{target}\"",
        "echo Rebuilding...",
        "call run.bat rebuild",
        "",
    });

    /// <summary>Starts the batch file in its own window; the caller should exit right after.</summary>
    public static void StartApply(string batchFile)
    {
        AppLog.Info("Applying update, the application will close.");
        Process.Start(new ProcessStartInfo("cmd.exe", $"/c \"{batchFile}\"") { UseShellExecute = true, WorkingDirectory = AppPaths.UpdatesDir });
    }
}
