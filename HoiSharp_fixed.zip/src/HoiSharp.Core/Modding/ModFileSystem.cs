using HoiSharp.Core.Paradox;

namespace HoiSharp.Core.Modding;

/// <summary>Describes one mod: a folder that mirrors the base data layout plus a descriptor.mod file.</summary>
public sealed class ModInfo
{
    public string Name { get; init; } = "";
    public string Version { get; init; } = "1.0";
    public string Directory { get; init; } = "";
    public List<string> ReplacePaths { get; init; } = new();
    public List<string> Dependencies { get; init; } = new();

    public static ModInfo? Load(string directory)
    {
        var descriptor = Path.Combine(directory, "descriptor.mod");
        if (!File.Exists(descriptor)) return null;

        var root = ParadoxParser.ParseFile(descriptor);
        return new ModInfo
        {
            Name = root.Str("name") ?? Path.GetFileName(directory),
            Version = root.Str("version") ?? "1.0",
            Directory = directory,
            ReplacePaths = root.ChildrenNamed("replace_path")
                               .Select(n => Normalize(n.Value ?? ""))
                               .Where(s => s.Length > 0).ToList(),
            Dependencies = root.Child("dependencies")?.Scalars().ToList() ?? new List<string>(),
        };
    }

    internal static string Normalize(string rel) => rel.Replace('\\', '/').Trim('/').ToLowerInvariant();
}

/// <summary>
/// HOI4-style virtual file system. Mods are layered in load order; for any relative path the LAST mod
/// that contains the file wins (same path = replaces the earlier file, new file name = adds content).
/// A mod can also declare replace_path = "history/states" in its descriptor.mod to drop every file the
/// earlier mods put into that folder.
/// </summary>
public sealed class ModFileSystem
{
    private readonly List<ModInfo> _mods;

    public IReadOnlyList<ModInfo> Mods => _mods;

    public ModFileSystem(IEnumerable<ModInfo> modsInLoadOrder)
    {
        _mods = modsInLoadOrder.ToList();
    }

    /// <summary>Find all mods under dataRoot/mods that have a descriptor.mod.</summary>
    public static List<ModInfo> DiscoverMods(string dataRoot)
    {
        var result = new List<ModInfo>();
        var dir = Path.Combine(dataRoot, "mods");
        if (!Directory.Exists(dir)) return result;
        foreach (var sub in Directory.GetDirectories(dir).OrderBy(d => d, StringComparer.OrdinalIgnoreCase))
        {
            var info = ModInfo.Load(sub);
            if (info != null) result.Add(info);
        }
        return result;
    }

    /// <summary>Base data (dataRoot/mod_base) first, then the named mods in the given order,
    /// with dependencies pulled in ahead of the mods that need them.</summary>
    public static ModFileSystem Create(string dataRoot, IEnumerable<string> modNames)
    {
        var stack = new List<ModInfo>();
        var baseInfo = ModInfo.Load(Path.Combine(dataRoot, "mod_base"))
                       ?? new ModInfo { Name = "base", Directory = Path.Combine(dataRoot, "mod_base") };
        stack.Add(baseInfo);

        var available = DiscoverMods(dataRoot);
        void Add(string name)
        {
            var mod = available.FirstOrDefault(m =>
                string.Equals(m.Name, name, StringComparison.OrdinalIgnoreCase) ||
                string.Equals(Path.GetFileName(m.Directory), name, StringComparison.OrdinalIgnoreCase));
            if (mod == null || stack.Contains(mod)) return;
            foreach (var dep in mod.Dependencies) Add(dep);
            stack.Add(mod);
        }
        foreach (var n in modNames) Add(n);
        return new ModFileSystem(stack);
    }

    /// <summary>Full path of a file, taking the last mod that has it; null if no mod has it.</summary>
    public string? Resolve(string relativePath)
    {
        for (int i = _mods.Count - 1; i >= 0; i--)
        {
            var p = Path.Combine(_mods[i].Directory, relativePath);
            if (File.Exists(p)) return p;
            if (_mods[i].ReplacePaths.Contains(ModInfo.Normalize(Path.GetDirectoryName(relativePath) ?? "")))
                return null; // this mod wiped the folder, earlier files are not visible
        }
        return null;
    }

    /// <summary>Files of a folder merged across mods; same file name = later mod wins. Sorted by name.</summary>
    public List<string> ListFiles(string folder, string pattern = "*.txt")
    {
        var byName = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase);
        var norm = ModInfo.Normalize(folder);
        foreach (var mod in _mods)
        {
            if (mod.ReplacePaths.Contains(norm)) byName.Clear();
            var dir = Path.Combine(mod.Directory, folder);
            if (!Directory.Exists(dir)) continue;
            foreach (var f in Directory.GetFiles(dir, pattern))
                byName[Path.GetFileName(f)] = f;
        }
        return byName.OrderBy(kv => kv.Key, StringComparer.OrdinalIgnoreCase).Select(kv => kv.Value).ToList();
    }

    /// <summary>
    /// Like ListFiles, but ordered by mod load order first (then file name), so that data from a later
    /// mod is applied after, and therefore overrides, data from earlier mods. A file with the same name
    /// in a later mod replaces the earlier file entirely.
    /// </summary>
    public List<string> ListFilesInLoadOrder(string folder, string pattern = "*.txt")
    {
        var norm = ModInfo.Normalize(folder);
        var perMod = new List<Dictionary<string, string>>();
        foreach (var mod in _mods)
        {
            if (mod.ReplacePaths.Contains(norm))
                foreach (var d in perMod) d.Clear();
            var files = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase);
            var dir = Path.Combine(mod.Directory, folder);
            if (Directory.Exists(dir))
                foreach (var f in Directory.GetFiles(dir, pattern))
                    files[Path.GetFileName(f)] = f;
            perMod.Add(files);
        }

        var result = new List<string>();
        for (int i = 0; i < perMod.Count; i++)
        {
            foreach (var kv in perMod[i].OrderBy(k => k.Key, StringComparer.OrdinalIgnoreCase))
            {
                bool shadowed = false;
                for (int j = i + 1; j < perMod.Count && !shadowed; j++)
                    shadowed = perMod[j].ContainsKey(kv.Key);
                if (!shadowed) result.Add(kv.Value);
            }
        }
        return result;
    }

    public string ReadAllText(string relativePath)
    {
        var p = Resolve(relativePath) ?? throw new FileNotFoundException($"'{relativePath}' not found in any mod", relativePath);
        return File.ReadAllText(p);
    }
}
