using System.Net;
using System.Net.Sockets;
using System.Text;

namespace HoiSharp.Core.Multiplayer;

/// <summary>
/// Minimal host-authoritative TCP multiplayer session.
/// - Host runs the simulation and broadcasts chat / turn notifications.
/// - Clients connect and can send chat + simple commands as text lines.
/// This is a foundation for full sync, not a complete lockstep engine.
/// </summary>
public sealed class NetSession : IDisposable
{
    public bool IsHost { get; private set; }
    public bool IsConnected { get; private set; }
    public string LocalName { get; set; } = "Player";

    public event Action<string>? Message;
    public event Action<string>? CommandReceived; // raw command from remote

    private TcpListener? _listener;
    private readonly List<TcpClient> _clients = new();
    private TcpClient? _serverConnection;
    private Thread? _thread;
    private volatile bool _running;
    private readonly object _lock = new();

    public void StartHost(int port = 7777)
    {
        Stop();
        IsHost = true;
        _listener = new TcpListener(IPAddress.Any, port);
        _listener.Start();
        _running = true;
        IsConnected = true;
        _thread = new Thread(HostLoop) { IsBackground = true };
        _thread.Start();
        Message?.Invoke($"Hosting multiplayer on port {port}. Share your IP with friends.");
    }

    public void Join(string host, int port = 7777)
    {
        Stop();
        IsHost = false;
        _serverConnection = new TcpClient();
        _serverConnection.Connect(host, port);
        _running = true;
        IsConnected = true;
        _thread = new Thread(ClientLoop) { IsBackground = true };
        _thread.Start();
        Message?.Invoke($"Connected to {host}:{port}.");
        Send($"JOIN {LocalName}");
    }

    public void SendChat(string text) => Send($"CHAT {LocalName}: {text}");

    public void SendCommand(string cmd) => Send($"CMD {LocalName} {cmd}");

    public void Broadcast(string line)
    {
        if (!IsHost) return;
        SendRawToAll(line);
    }

    private void Send(string line)
    {
        if (IsHost)
            SendRawToAll(line);
        else if (_serverConnection != null)
            WriteLine(_serverConnection, line);
    }

    private void HostLoop()
    {
        try
        {
            while (_running && _listener != null)
            {
                if (_listener.Pending())
                {
                    var c = _listener.AcceptTcpClient();
                    lock (_lock) _clients.Add(c);
                    Message?.Invoke("A player connected.");
                    WriteLine(c, "CHAT Server: Welcome to HoiSharp multiplayer (prototype).");
                }

                lock (_lock)
                {
                    for (int i = _clients.Count - 1; i >= 0; i--)
                    {
                        var c = _clients[i];
                        if (!c.Connected) { _clients.RemoveAt(i); continue; }
                        if (c.Available > 0)
                        {
                            string? line = ReadLine(c);
                            if (line == null) continue;
                            HandleIncoming(line, c);
                        }
                    }
                }
                Thread.Sleep(50);
            }
        }
        catch (Exception ex)
        {
            Message?.Invoke($"Host error: {ex.Message}");
        }
    }

    private void ClientLoop()
    {
        try
        {
            while (_running && _serverConnection != null && _serverConnection.Connected)
            {
                if (_serverConnection.Available > 0)
                {
                    string? line = ReadLine(_serverConnection);
                    if (line != null) HandleIncoming(line, null);
                }
                Thread.Sleep(50);
            }
        }
        catch (Exception ex)
        {
            Message?.Invoke($"Connection error: {ex.Message}");
            IsConnected = false;
        }
    }

    private void HandleIncoming(string line, TcpClient? from)
    {
        if (line.StartsWith("CHAT ", StringComparison.Ordinal))
        {
            Message?.Invoke(line[5..]);
            if (IsHost) SendRawToAll(line, except: from);
        }
        else if (line.StartsWith("CMD ", StringComparison.Ordinal))
        {
            CommandReceived?.Invoke(line[4..]);
            Message?.Invoke($"[cmd] {line[4..]}");
            if (IsHost) SendRawToAll(line, except: from);
        }
        else if (line.StartsWith("JOIN ", StringComparison.Ordinal))
        {
            Message?.Invoke($"{line[5..]} joined the session.");
            if (IsHost) SendRawToAll($"CHAT Server: {line[5..]} joined.", except: from);
        }
    }

    private void SendRawToAll(string line, TcpClient? except = null)
    {
        lock (_lock)
        {
            foreach (var c in _clients)
            {
                if (c == except || !c.Connected) continue;
                try { WriteLine(c, line); } catch { /* drop */ }
            }
        }
    }

    private static void WriteLine(TcpClient c, string line)
    {
        var stream = c.GetStream();
        var data = Encoding.UTF8.GetBytes(line + "\n");
        stream.Write(data, 0, data.Length);
    }

    private static string? ReadLine(TcpClient c)
    {
        var stream = c.GetStream();
        var sb = new StringBuilder();
        while (stream.DataAvailable)
        {
            int b = stream.ReadByte();
            if (b < 0) break;
            if (b == '\n') break;
            if (b != '\r') sb.Append((char)b);
        }
        return sb.Length > 0 ? sb.ToString() : null;
    }

    public void Stop()
    {
        _running = false;
        try { _listener?.Stop(); } catch { }
        lock (_lock)
        {
            foreach (var c in _clients) try { c.Close(); } catch { }
            _clients.Clear();
        }
        try { _serverConnection?.Close(); } catch { }
        _listener = null;
        _serverConnection = null;
        IsConnected = false;
        IsHost = false;
    }

    public void Dispose() => Stop();
}
