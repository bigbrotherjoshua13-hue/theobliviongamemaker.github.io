using HoiSharp.Core.Data;
using HoiSharp.Core.Modding;
using HoiSharp.Core.Paradox;

namespace HoiSharp.Core.Focus;

/// <summary>
/// Loads national focus trees from common/national_focus/*.txt.
/// Falls back to a built-in generic tree when no files exist.
/// </summary>
public static class FocusLibrary
{
    public static Dictionary<string, FocusTree> LoadAll(ModFileSystem fs)
    {
        var trees = new Dictionary<string, FocusTree>(StringComparer.OrdinalIgnoreCase);

        foreach (var file in fs.ListFilesInLoadOrder("common/national_focus", "*.txt"))
        {
            try
            {
                var tree = ParseTree(File.ReadAllText(file), Path.GetFileNameWithoutExtension(file));
                if (tree != null)
                {
                    tree.BuildIndex();
                    trees[tree.Id] = tree;
                }
            }
            catch
            {
                // ignore bad files
            }
        }

        if (!trees.ContainsKey("generic"))
            trees["generic"] = BuildGenericTree();

        return trees;
    }

    private static FocusTree? ParseTree(string text, string fallbackId)
    {
        var root = ParadoxParser.Parse(text);
        var tree = new FocusTree
        {
            Id = root.Str("id") ?? fallbackId,
            Name = root.Str("name") ?? fallbackId,
        };

        foreach (var child in root.ChildrenNamed("focus"))
        {
            var id = child.Str("id");
            if (string.IsNullOrWhiteSpace(id)) continue;

            var n = new FocusNode
            {
                Id = id,
                Name = child.Str("name") ?? id,
                Description = child.Str("desc") ?? child.Str("description") ?? "",
                X = child.Int("x"),
                Y = child.Int("y"),
                CostDays = child.Int("cost", child.Int("cost_days", 70)),
            };

            var prereq = child.Child("prerequisite") ?? child.Child("prerequisites");
            if (prereq != null)
            {
                foreach (var s in prereq.Scalars())
                    if (!string.IsNullOrWhiteSpace(s)) n.Prerequisites.Add(s.Trim());
                foreach (var c in prereq.Children)
                    if (c.Key != null) n.Prerequisites.Add(c.Key);
            }

            var mutex = child.Child("mutually_exclusive");
            if (mutex != null)
            {
                foreach (var s in mutex.Scalars())
                    if (!string.IsNullOrWhiteSpace(s)) n.MutuallyExclusive.Add(s.Trim());
            }

            var reward = child.Child("completion_reward") ?? child.Child("effects");
            if (reward != null)
                ParseEffects(reward, n.Effects);

            tree.Nodes.Add(n);
        }

        return tree.Nodes.Count == 0 ? null : tree;
    }

    private static void ParseEffects(PNode node, List<FocusEffect> outList)
    {
        foreach (var c in node.Children)
        {
            if (c.Key == null) continue;
            var key = c.Key.ToLowerInvariant();
            switch (key)
            {
                case "add_stability":
                    outList.Add(new FocusEffect
                    {
                        Type = FocusEffectType.AddStability,
                        DoubleArg = (c.Value != null && double.TryParse(c.Value, out var s) ? s : 0.05) * 100
                    });
                    break;
                case "add_war_support":
                    outList.Add(new FocusEffect
                    {
                        Type = FocusEffectType.AddWarSupport,
                        DoubleArg = (c.Value != null && double.TryParse(c.Value, out var w) ? w : 0.05) * 100
                    });
                    break;
                case "add_manpower":
                    outList.Add(new FocusEffect
                    {
                        Type = FocusEffectType.AddManpower,
                        IntArg = c.Value != null && int.TryParse(c.Value, out var m) ? m : 10000
                    });
                    break;
                case "add_core":
                case "add_core_of":
                    outList.Add(new FocusEffect { Type = FocusEffectType.AddCore, StringArg = c.Value });
                    break;
                case "declare_war":
                case "create_wargoal":
                    outList.Add(new FocusEffect { Type = FocusEffectType.DeclareWar, StringArg = c.Value });
                    break;
                case "create_unit":
                    outList.Add(new FocusEffect
                    {
                        Type = FocusEffectType.CreateUnit,
                        IntArg = c.Int("count", 1)
                    });
                    break;
                case "set_politics":
                case "set_ideology":
                    outList.Add(new FocusEffect
                    {
                        Type = FocusEffectType.SetIdeology,
                        StringArg = c.Str("ruling_party") ?? c.Value ?? "democratic"
                    });
                    break;
                case "add_ideas":
                case "add_spirit":
                    outList.Add(new FocusEffect { Type = FocusEffectType.AddSpirit, StringArg = c.Value });
                    break;
                case "custom_effect_tooltip":
                case "message":
                    outList.Add(new FocusEffect { Type = FocusEffectType.CustomMessage, StringArg = c.Value ?? "" });
                    break;
            }
        }
    }

    /// <summary>Built-in generic focus tree used when no mod provides one.</summary>
    public static FocusTree BuildGenericTree()
    {
        var t = new FocusTree { Id = "generic", Name = "Generic Focus Tree" };

        void Add(string id, string name, string desc, int x, int y, int cost, string[]? prereq, params FocusEffect[] effects)
        {
            t.Nodes.Add(new FocusNode
            {
                Id = id,
                Name = name,
                Description = desc,
                X = x,
                Y = y,
                CostDays = cost,
                Prerequisites = prereq?.ToList() ?? new(),
                Effects = effects.ToList(),
            });
        }

        // Political branch
        Add("political_effort", "Political Effort",
            "Rally the people around a clear political vision. +5 Stability.",
            0, 0, 35, null,
            new FocusEffect { Type = FocusEffectType.AddStability, DoubleArg = 5 });

        Add("collectivist_ethos", "Collectivist Ethos",
            "Promote unity and the common good. +5 Stability, +5 War Support.",
            -2, 1, 70, new[] { "political_effort" },
            new FocusEffect { Type = FocusEffectType.AddStability, DoubleArg = 5 },
            new FocusEffect { Type = FocusEffectType.AddWarSupport, DoubleArg = 5 });

        Add("liberty_ethos", "Liberty Ethos",
            "Champion individual freedoms. +10 Stability.",
            0, 1, 70, new[] { "political_effort" },
            new FocusEffect { Type = FocusEffectType.AddStability, DoubleArg = 10 });

        Add("nationalism_focus", "Nationalism",
            "Stir patriotic fervour. +10 War Support, set ideology Fascist.",
            2, 1, 70, new[] { "political_effort" },
            new FocusEffect { Type = FocusEffectType.AddWarSupport, DoubleArg = 10 },
            new FocusEffect { Type = FocusEffectType.SetIdeology, StringArg = "fascist" });

        // Army branch
        Add("army_effort", "Army Effort",
            "Expand the officer corps and conscription. +15000 manpower.",
            4, 0, 35, null,
            new FocusEffect { Type = FocusEffectType.AddManpower, IntArg = 15000 });

        Add("equipment_effort", "Equipment Effort",
            "Modernise weapons and logistics. Spawn 2 new armies at the capital.",
            4, 1, 70, new[] { "army_effort" },
            new FocusEffect { Type = FocusEffectType.CreateUnit, IntArg = 2 });

        Add("doctrine_effort", "Doctrine Effort",
            "Refine military doctrine. +5 War Support and another army.",
            4, 2, 70, new[] { "equipment_effort" },
            new FocusEffect { Type = FocusEffectType.AddWarSupport, DoubleArg = 5 },
            new FocusEffect { Type = FocusEffectType.CreateUnit, IntArg = 1 });

        // Industrial / recovery
        Add("industrial_effort", "Industrial Effort",
            "Invest in the home front. +5 Stability, +10000 manpower.",
            -4, 0, 35, null,
            new FocusEffect { Type = FocusEffectType.AddStability, DoubleArg = 5 },
            new FocusEffect { Type = FocusEffectType.AddManpower, IntArg = 10000 });

        Add("construction_effort", "Construction Effort",
            "Build infrastructure and factories. +5 Stability.",
            -4, 1, 70, new[] { "industrial_effort" },
            new FocusEffect { Type = FocusEffectType.AddStability, DoubleArg = 5 });

        Add("infrastructure_effort", "Infrastructure Effort",
            "Connect the nation. +5 War Support, +5 Stability.",
            -4, 2, 70, new[] { "construction_effort" },
            new FocusEffect { Type = FocusEffectType.AddStability, DoubleArg = 5 },
            new FocusEffect { Type = FocusEffectType.AddWarSupport, DoubleArg = 5 });

        // Aggressive branch
        Add("militarism", "Militarism",
            "Embrace a warrior culture. +15 War Support, -5 Stability.",
            2, 2, 70, new[] { "nationalism_focus" },
            new FocusEffect { Type = FocusEffectType.AddWarSupport, DoubleArg = 15 },
            new FocusEffect { Type = FocusEffectType.AddStability, DoubleArg = -5 });

        Add("war_preparation", "Prepare for War",
            "Mobilise the nation. +10 War Support, spawn 3 armies.",
            2, 3, 70, new[] { "militarism" },
            new FocusEffect { Type = FocusEffectType.AddWarSupport, DoubleArg = 10 },
            new FocusEffect { Type = FocusEffectType.CreateUnit, IntArg = 3 });

        t.BuildIndex();

        // mutual exclusives
        if (t.ById.TryGetValue("collectivist_ethos", out var col) && t.ById.TryGetValue("liberty_ethos", out var lib))
        {
            col.MutuallyExclusive.Add("liberty_ethos");
            lib.MutuallyExclusive.Add("collectivist_ethos");
        }
        if (t.ById.TryGetValue("liberty_ethos", out lib) && t.ById.TryGetValue("nationalism_focus", out var nat))
        {
            lib.MutuallyExclusive.Add("nationalism_focus");
            nat.MutuallyExclusive.Add("liberty_ethos");
        }

        return t;
    }
}
