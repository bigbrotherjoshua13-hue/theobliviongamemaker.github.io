using HoiSharp.Core.Data;
using HoiSharp.Core.Focus;
using HoiSharp.Core.Scenarios;

namespace HoiSharp.Core.Sim;

public enum UnitBranch : byte { Land, Naval, Air }

public enum UnitType : byte
{
    Infantry = 0, Armor = 1, Artillery = 2, Mountaineer = 3, Militia = 4,
    Destroyer = 10, Cruiser = 11, Battleship = 12, Submarine = 13,
    Fighter = 20, Bomber = 21, CAS = 22,
}

public static class UnitStats
{
    public static UnitBranch Branch(UnitType t) =>
        t >= UnitType.Fighter ? UnitBranch.Air :
        t >= UnitType.Destroyer ? UnitBranch.Naval : UnitBranch.Land;

    public static string Label(UnitType t) => t switch
    {
        UnitType.Infantry => "Infantry", UnitType.Armor => "Armor",
        UnitType.Artillery => "Artillery", UnitType.Mountaineer => "Mountaineer",
        UnitType.Militia => "Militia", UnitType.Destroyer => "Destroyer",
        UnitType.Cruiser => "Cruiser", UnitType.Battleship => "Battleship",
        UnitType.Submarine => "Submarine", UnitType.Fighter => "Fighter",
        UnitType.Bomber => "Bomber", UnitType.CAS => "CAS", _ => t.ToString(),
    };

    public static int ManpowerCost(UnitType t) => t switch
    {
        UnitType.Militia => 2000, UnitType.Infantry => 5000, UnitType.Mountaineer => 6000,
        UnitType.Artillery => 4000, UnitType.Armor => 8000, UnitType.Destroyer => 3000,
        UnitType.Cruiser => 5000, UnitType.Battleship => 10000, UnitType.Submarine => 2500,
        UnitType.Fighter => 2000, UnitType.Bomber => 3500, UnitType.CAS => 2500, _ => 5000,
    };

    public static int FactoryCost(UnitType t) => t switch
    {
        UnitType.Militia => 1, UnitType.Infantry => 2, UnitType.Mountaineer => 3,
        UnitType.Artillery => 3, UnitType.Armor => 6, UnitType.Destroyer => 4,
        UnitType.Cruiser => 6, UnitType.Battleship => 12, UnitType.Submarine => 3,
        UnitType.Fighter => 3, UnitType.Bomber => 5, UnitType.CAS => 4, _ => 2,
    };

    public static double BaseSpeed(UnitType t) => t switch
    {
        UnitType.Armor => 0.65, UnitType.Militia => 0.35, UnitType.Artillery => 0.30,
        UnitType.Mountaineer => 0.40, UnitType.Destroyer => 0.70, UnitType.Cruiser => 0.55,
        UnitType.Battleship => 0.40, UnitType.Submarine => 0.45, UnitType.Fighter => 1.2,
        UnitType.Bomber => 0.9, UnitType.CAS => 1.0, _ => 0.45,
    };

    public static double SoftAttack(UnitType t) => t switch
    {
        UnitType.Artillery => 1.6, UnitType.Armor => 1.2, UnitType.Militia => 0.6,
        UnitType.Battleship => 2.0, UnitType.Cruiser => 1.3, UnitType.Destroyer => 1.0,
        UnitType.Submarine => 0.8, UnitType.Bomber => 1.5, UnitType.CAS => 1.3,
        UnitType.Fighter => 0.9, _ => 1.0,
    };
}

public sealed class Army
{
    public int Id;
    public string Owner = "";
    public int ProvinceId;
    public double Strength = 100;
    public List<int> Path = new();
    public double Progress;
    public string Name = "";
    public UnitType Type = UnitType.Infantry;
    /// <summary>True for armies spawned by an uprising (they fight the original owner).</summary>
    public bool IsRebel;

    public UnitBranch Branch => UnitStats.Branch(Type);
    public bool IsLand => Branch == UnitBranch.Land;
    public bool IsNaval => Branch == UnitBranch.Naval;
    public bool IsAir => Branch == UnitBranch.Air;
}

/// <summary>
/// The running simulation: date, wars, armies, occupation, national focuses, uprisings and a small AI.
/// Everything is deterministic for a given seed.
/// </summary>
public sealed class GameWorld
{
    public MapData Map { get; }
    public DateTime Date { get; private set; }
    public List<Army> Armies { get; } = new();
    public List<War> Wars { get; } = new();
    public List<Uprising> Uprisings { get; } = new();
    public List<PeaceConference> Conferences { get; } = new();
    public List<Alliance> Alliances { get; } = new();
    public List<SubjectRelation> Subjects { get; } = new();
    public List<TradeDeal> TradeDeals { get; } = new();
    public string? PlayerTag { get; private set; }

    /// <summary>Active conference involving the player (if any). UI should present this.</summary>
    public PeaceConference? ActivePlayerConference =>
        Conferences.FirstOrDefault(c => !c.Resolved && c.InvolvesPlayer);

    /// <summary>Loaded focus trees (key = tree id, e.g. "generic").</summary>
    public Dictionary<string, FocusTree> FocusTrees { get; private set; } = new(StringComparer.OrdinalIgnoreCase);

    /// <summary>Raised for things the player should see (war declared, province captured, focus completed...).</summary>
    public event Action<string>? Message;

    /// <summary>Raised whenever province control or wars change, so the map colours can be refreshed.</summary>
    public event Action? MapChanged;

    /// <summary>Raised when a player-involving peace conference opens.</summary>
    public event Action<PeaceConference>? ConferenceOpened;

    private readonly Random _rng;
    private int _nextArmyId = 1;
    private int _nextUprisingId = 1;
    private int _nextAllianceId = 1;

    public const int ArmyCost = 5000; // legacy default manpower (infantry)

    /// <summary>Tags controlled by human players (hotseat / multiplayer). PlayerTag is the active one.</summary>
    public List<string> HumanTags { get; } = new();
    public UnitType SelectedBuildType { get; set; } = UnitType.Infantry;

    public GameWorld(MapData map, DateTime startDate, int seed = 1936)
    {
        Map = map;
        Date = startDate;
        _rng = new Random(seed);
    }

    /// <summary>Call after construction to inject focus trees loaded from mods.</summary>
    public void SetFocusTrees(Dictionary<string, FocusTree> trees) => FocusTrees = trees;

    // ------------------------------------------------------------------ setup
    public void Initialize(string? playerTag, Scenario? scenario = null)
    {
        PlayerTag = playerTag;
        HumanTags.Clear();
        if (playerTag != null) HumanTags.Add(playerTag);

        foreach (var c in Map.CountryList)
        {
            c.IsPlayer = string.Equals(c.Tag, playerTag, StringComparison.OrdinalIgnoreCase);
            c.ManpowerPool = Map.StatesOf(c.Tag).Sum(s => (double)s.Manpower) * 0.05;
            // starting politics
            c.Stability = 50 + _rng.Next(30);
            c.WarSupport = 30 + _rng.Next(30);
            c.FocusTreeId = "generic";
            c.Ideology = GuessIdeology(c.Tag);
            c.Leader = GenerateLeader(c);
            c.Capitulation = 0;
            c.MilProduction = 0;
            c.CivProduction = 0;
            c.EconomyModifier = 1.0;
            c.EconomyPhase = "Stable";
            c.EconomyPhaseMonths = 0;
            c.TradeBalance = 0;
            // apply leader soft bonuses
            c.Stability = Math.Clamp(c.Stability + c.Leader.StabilityBonus, 0, 100);
            c.WarSupport = Math.Clamp(c.WarSupport + c.Leader.WarSupportBonus, 0, 100);
        }

        // seed factories from manpower / category (sparse industry)
        foreach (var st in Map.States.Values)
        {
            if (st.Provinces.Count == 0) continue;
            int baseCiv = st.Category switch
            {
                "megalopolis" or "metropolis" => 4,
                "large_city" or "city" => 2,
                "large_town" => 1,
                _ => st.Manpower > 1_000_000 ? 2 : st.Manpower > 300_000 ? 1 : 0,
            };
            st.CivilianFactories = Math.Max(st.CivilianFactories, baseCiv);
            st.MilitaryFactories = Math.Max(st.MilitaryFactories, st.Manpower > 800_000 ? 1 + baseCiv / 2 : baseCiv > 0 ? 1 : 0);
        }

        foreach (var c in Map.CountryList)
        {
            int civ = TotalCivFactories(c.Tag);
            int mil = TotalMilFactories(c.Tag);
            double pop = Map.StatesOf(c.Tag).Sum(s => (double)s.Manpower);
            c.Gdp = pop * 0.00001 + civ * 8 + mil * 5;
            c.Treasury = c.Gdp * (8 + _rng.NextDouble() * 6);
        }

        foreach (var p in Map.Provinces)
            p.Controller = p.IsLand ? Map.OwnerOf(p.Id) : null;

        // starting units: mix of infantry + a bit of armor / naval / air for larger countries
        if (scenario == null || !scenario.ClearDefaultArmies)
            foreach (var c in Map.CountryList)
            {
                var land = Map.StatesOf(c.Tag).SelectMany(s => s.Provinces)
                               .Where(id => id > 0 && id < Map.Provinces.Length && Map.Provinces[id].IsLand).ToList();
                if (land.Count == 0) continue;
                int n = Math.Clamp(land.Count / 25, 1, 10);
                for (int i = 0; i < n; i++)
                {
                    int pid = i == 0 && c.Capital > 0 && land.Contains(c.Capital) ? c.Capital : land[_rng.Next(land.Count)];
                    var type = i == 1 && n >= 3 ? UnitType.Armor : i == 2 && n >= 4 ? UnitType.Artillery : UnitType.Infantry;
                    SpawnArmy(c.Tag, pid, type: type);
                }
                // coastal: a destroyer or two
                var coast = land.Where(id => Map.Provinces[id].Coastal).ToList();
                if (coast.Count > 0 && n >= 3)
                {
                    int sea = FindAdjacentSea(coast[_rng.Next(coast.Count)]);
                    if (sea > 0) SpawnArmy(c.Tag, sea, type: UnitType.Destroyer);
                }
                // air wing at capital
                if (n >= 4 && c.Capital > 0)
                    SpawnArmy(c.Tag, c.Capital, type: UnitType.Fighter);
            }
        if (scenario != null)
        {
            foreach (var a in scenario.Armies)
            {
                var owner = Map.CountryOf(a.Tag);
                if (owner == null) continue;
                if (a.Province <= 0 || a.Province >= Map.Provinces.Length || !Map.Provinces[a.Province].IsLand) continue;
                SpawnArmy(owner.Tag, a.Province).Strength = Math.Clamp(a.Strength, 1, 100);
            }
            foreach (var w in scenario.Wars)
            {
                var attacker = Map.CountryOf(w.Attacker);
                var defender = Map.CountryOf(w.Defender);
                if (attacker != null && defender != null)
                    DeclareWar(attacker.Tag, defender.Tag, permanent: true);
            }
        }
        MapChanged?.Invoke();
    }

    private static Ideology GuessIdeology(string tag)
    {
        // very rough historical defaults for common tags
        return tag.ToUpperInvariant() switch
        {
            "GER" or "ITA" or "JAP" or "SPA" or "HUN" or "ROM" => Ideology.Fascist,
            "SOV" or "MON" or "TAN" => Ideology.Communist,
            "USA" or "ENG" or "FRA" or "CAN" or "AST" or "NZL" or "SAF" or "RAJ" => Ideology.Democratic,
            "ENG" or "BEL" or "HOL" or "SWE" or "NOR" or "DEN" => Ideology.Democratic,
            _ => Ideology.Neutral,
        };
    }

    private static readonly string[] FirstNames =
    {
        "Alexander", "Marie", "Viktor", "Elena", "James", "Sofia", "Hiroshi", "Anna",
        "Carlos", "Fatima", "Ivan", "Yuki", "Omar", "Ingrid", "Kwame", "Priya",
        "Hans", "Lucia", "Marcus", "Ngozi", "Erik", "Mei", "Diego", "Amara",
    };
    private static readonly string[] LastNames =
    {
        "Volkov", "Schmidt", "Nakamura", "Silva", "Okonkwo", "Bergström", "Patel", "Dubois",
        "Kowalski", "Al-Rashid", "Moreau", "Tanaka", "García", "Nielsen", "Petrov", "Costa",
    };

    private Leader GenerateLeader(Country c)
    {
        // a few famous-ish defaults; everyone else gets a generated name
        var (name, title) = c.Tag.ToUpperInvariant() switch
        {
            "USA" => ("Franklin D. Roosevelt", "President"),
            "ENG" => ("Winston Churchill", "Prime Minister"),
            "GER" => ("Adolf Hitler", "Führer"),
            "SOV" => ("Joseph Stalin", "General Secretary"),
            "FRA" => ("Édouard Daladier", "Prime Minister"),
            "ITA" => ("Benito Mussolini", "Duce"),
            "JAP" => ("Hirohito", "Emperor"),
            "CHI" => ("Chiang Kai-shek", "Generalissimo"),
            "SPA" => ("Francisco Franco", "Caudillo"),
            "CAN" => ("William Lyon Mackenzie King", "Prime Minister"),
            _ => (
                $"{FirstNames[_rng.Next(FirstNames.Length)]} {LastNames[_rng.Next(LastNames.Length)]}",
                c.Ideology switch
                {
                    Ideology.Democratic => _rng.Next(2) == 0 ? "President" : "Prime Minister",
                    Ideology.Fascist => _rng.Next(2) == 0 ? "Leader" : "Chancellor",
                    Ideology.Communist => "Chairman",
                    Ideology.Monarchist => "Monarch",
                    _ => "Leader",
                }),
        };

        double stab = c.Ideology switch
        {
            Ideology.Democratic => 3 + _rng.NextDouble() * 4,
            Ideology.Communist => 1 + _rng.NextDouble() * 3,
            Ideology.Fascist => -1 + _rng.NextDouble() * 4,
            _ => _rng.NextDouble() * 3,
        };
        double ws = c.Ideology switch
        {
            Ideology.Fascist => 5 + _rng.NextDouble() * 5,
            Ideology.Communist => 3 + _rng.NextDouble() * 4,
            Ideology.Democratic => _rng.NextDouble() * 3,
            _ => 1 + _rng.NextDouble() * 3,
        };

        return new Leader
        {
            Name = name,
            Title = title,
            Ideology = c.Ideology,
            StabilityBonus = Math.Round(stab, 1),
            WarSupportBonus = Math.Round(ws, 1),
            ManpowerBonus = Math.Round((_rng.NextDouble() - 0.3) * 0.1, 3),
        };
    }

    public Army SpawnArmy(string tag, int provinceId, bool rebel = false, UnitType type = UnitType.Infantry)
    {
        var a = new Army
        {
            Id = _nextArmyId++,
            Owner = tag,
            ProvinceId = provinceId,
            IsRebel = rebel,
            Type = rebel ? UnitType.Militia : type,
        };
        string label = UnitStats.Label(a.Type);
        a.Name = rebel ? $"Rebel {label} {a.Id}" : $"{a.Id}{Ordinal(a.Id)} {label}";
        Armies.Add(a);
        return a;
    }

    private int FindAdjacentSea(int landProvinceId)
    {
        if (landProvinceId <= 0 || landProvinceId >= Map.Provinces.Length) return 0;
        foreach (var e in Map.Provinces[landProvinceId].Edges)
        {
            if (e.To > 0 && e.To < Map.Provinces.Length && Map.Provinces[e.To].Type == ProvinceType.Sea)
                return e.To;
        }
        return 0;
    }

    private static string Ordinal(int n) => (n % 100 is >= 11 and <= 13) ? "th" : (n % 10) switch
    {
        1 => "st",
        2 => "nd",
        3 => "rd",
        _ => "th",
    };

    // ------------------------------------------------------------------ diplomacy
    public bool AtWar(string? a, string? b)
    {
        if (a == null || b == null || a == b) return false;
        return Wars.Any(w => w.Is(a, b));
    }

    public IEnumerable<string> EnemiesOf(string tag) =>
        Wars.Where(w => w.Involves(tag)).Select(w => w.A == tag ? w.B : w.A);

    /// <param name="permanent">true = the war lasts until someone makes peace (scenario wars)</param>
    /// <param name="callAllies">if true, call alliance members and subjects into the war</param>
    public bool DeclareWar(string attacker, string defender, bool permanent = false, bool callAllies = true)
    {
        if (attacker == defender || AtWar(attacker, defender)) return false;
        if (Map.CountryOf(attacker) == null || Map.CountryOf(defender) == null) return false;
        // subjects with tight ranks cannot declare independent offensive wars
        var subj = GetSubject(attacker);
        if (subj != null && !subj.CanDeclareIndependentWars && subj.Overlord != defender)
            return false;

        bool player = attacker == PlayerTag || defender == PlayerTag;
        Wars.Add(new War
        {
            A = attacker,
            B = defender,
            Start = Date,
            EndsOn = (player || permanent) ? null : Date.AddDays(180 + _rng.Next(540)),
        });
        Message?.Invoke($"{Map.CountryOf(attacker)!.Name} declared war on {Map.CountryOf(defender)!.Name}!");

        if (callAllies)
            CallToArms(attacker, defender, offensive: true);

        MapChanged?.Invoke();
        return true;
    }

    /// <summary>Bring alliance partners and subjects into a war.</summary>
    private void CallToArms(string sideA, string sideB, bool offensive)
    {
        var toCallA = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
        var toCallB = new HashSet<string>(StringComparer.OrdinalIgnoreCase);

        // alliance members
        foreach (var al in Alliances)
        {
            if (al.Contains(sideA) && (offensive ? al.Offensive : al.Defensive))
                foreach (var m in al.Members)
                    if (m != sideA && m != sideB) toCallA.Add(m);
            if (al.Contains(sideB) && al.Defensive) // always defensive for the attacked side
                foreach (var m in al.Members)
                    if (m != sideB && m != sideA) toCallB.Add(m);
        }

        // subjects of each side
        foreach (var s in Subjects)
        {
            if (s.Overlord == sideA && (offensive ? s.MustJoinOffensiveWars : s.MustJoinDefensiveWars))
                toCallA.Add(s.Subject);
            if (s.Overlord == sideB && s.MustJoinDefensiveWars)
                toCallB.Add(s.Subject);
            // overlord defends subject
            if (s.Subject == sideA) toCallA.Add(s.Overlord);
            if (s.Subject == sideB) toCallB.Add(s.Overlord);
        }

        foreach (var tag in toCallA)
        {
            if (AtWar(tag, sideB) || tag == sideB) continue;
            if (Map.CountryOf(tag) == null) continue;
            Wars.Add(new War
            {
                A = tag, B = sideB, Start = Date,
                EndsOn = (tag == PlayerTag || sideB == PlayerTag) ? null : Date.AddDays(180 + _rng.Next(400)),
            });
            Message?.Invoke($"{Map.CountryOf(tag)!.Name} joins the war alongside {Map.CountryOf(sideA)!.Name}.");
        }
        foreach (var tag in toCallB)
        {
            if (AtWar(tag, sideA) || tag == sideA) continue;
            if (Map.CountryOf(tag) == null) continue;
            Wars.Add(new War
            {
                A = tag, B = sideA, Start = Date,
                EndsOn = (tag == PlayerTag || sideA == PlayerTag) ? null : Date.AddDays(180 + _rng.Next(400)),
            });
            Message?.Invoke($"{Map.CountryOf(tag)!.Name} joins the war alongside {Map.CountryOf(sideB)!.Name}.");
        }
    }

    // -------------------- alliances --------------------
    public Alliance? GetAlliance(int id) => Alliances.FirstOrDefault(a => a.Id == id);

    public IEnumerable<Alliance> AlliancesOf(string tag) =>
        Alliances.Where(a => a.Contains(tag));

    public bool AreAllied(string a, string b) =>
        a != b && Alliances.Any(al => al.Contains(a) && al.Contains(b));

    public Alliance CreateAlliance(string name, string founder, bool defensive = true, bool offensive = true)
    {
        var al = new Alliance
        {
            Id = _nextAllianceId++,
            Name = string.IsNullOrWhiteSpace(name) ? $"Alliance {_nextAllianceId}" : name,
            LeaderTag = founder,
            Formed = Date,
            Defensive = defensive,
            Offensive = offensive,
        };
        al.Members.Add(founder);
        Alliances.Add(al);
        Message?.Invoke($"{Map.CountryOf(founder)?.Name ?? founder} founded {al.Name}.");
        return al;
    }

    public bool JoinAlliance(int allianceId, string tag)
    {
        var al = GetAlliance(allianceId);
        if (al == null || Map.CountryOf(tag) == null) return false;
        if (al.Contains(tag)) return false;
        // cannot join if at war with a member
        if (al.Members.Any(m => AtWar(tag, m))) return false;
        al.Members.Add(tag);
        Message?.Invoke($"{Map.CountryOf(tag)!.Name} joined {al.Name}.");
        return true;
    }

    public bool LeaveAlliance(int allianceId, string tag)
    {
        var al = GetAlliance(allianceId);
        if (al == null || !al.Contains(tag)) return false;
        al.Members.Remove(tag);
        if (string.Equals(al.LeaderTag, tag, StringComparison.OrdinalIgnoreCase))
            al.LeaderTag = al.Members.FirstOrDefault() ?? "";
        if (al.Members.Count < 2)
        {
            Alliances.Remove(al);
            Message?.Invoke($"{al.Name} has dissolved.");
        }
        else
            Message?.Invoke($"{Map.CountryOf(tag)?.Name ?? tag} left {al.Name}.");
        return true;
    }

    /// <summary>Invite another country into a new bilateral alliance with you (creates a 2-member alliance).</summary>
    public bool FormBilateralAlliance(string a, string b, string? name = null)
    {
        if (a == b || Map.CountryOf(a) == null || Map.CountryOf(b) == null) return false;
        if (AtWar(a, b)) return false;
        if (AreAllied(a, b)) return false;
        // subjects with Integrated rank cannot form independent alliances
        var sa = GetSubject(a);
        var sb = GetSubject(b);
        if (sa?.Rank >= PuppetRank.Integrated || sb?.Rank >= PuppetRank.Integrated) return false;

        string n = name ?? $"{Map.CountryOf(a)!.Name}–{Map.CountryOf(b)!.Name} Pact";
        var al = CreateAlliance(n, a);
        al.Members.Add(b);
        Message?.Invoke($"{Map.CountryOf(a)!.Name} and {Map.CountryOf(b)!.Name} formed {al.Name}.");
        return true;
    }

    // -------------------- subjects / puppets --------------------
    public SubjectRelation? GetSubject(string tag) =>
        Subjects.FirstOrDefault(s => string.Equals(s.Subject, tag, StringComparison.OrdinalIgnoreCase));

    public SubjectRelation? GetOverlord(string tag) => GetSubject(tag);

    public IEnumerable<SubjectRelation> SubjectsOf(string overlord) =>
        Subjects.Where(s => string.Equals(s.Overlord, overlord, StringComparison.OrdinalIgnoreCase));

    public bool IsSubjectOf(string subject, string overlord) =>
        Subjects.Any(s => string.Equals(s.Subject, subject, StringComparison.OrdinalIgnoreCase)
                       && string.Equals(s.Overlord, overlord, StringComparison.OrdinalIgnoreCase));

    public bool SetSubject(string overlord, string subject, PuppetRank rank)
    {
        if (overlord == subject) return false;
        if (Map.CountryOf(overlord) == null || Map.CountryOf(subject) == null) return false;

        // remove existing subject link for this subject
        Subjects.RemoveAll(s => string.Equals(s.Subject, subject, StringComparison.OrdinalIgnoreCase));

        Subjects.Add(new SubjectRelation
        {
            Overlord = overlord,
            Subject = subject,
            Rank = rank,
            Established = Date,
        });

        // subjects leave independent alliances (keep multi-alliance for loose ranks only)
        if (rank >= PuppetRank.Satellite)
        {
            foreach (var al in Alliances.Where(a => a.Contains(subject)).ToList())
                LeaveAlliance(al.Id, subject);
        }

        Message?.Invoke($"{Map.CountryOf(subject)!.Name} is now a {rank} of {Map.CountryOf(overlord)!.Name}.");
        return true;
    }

    public bool FreeSubject(string subject)
    {
        int n = Subjects.RemoveAll(s => string.Equals(s.Subject, subject, StringComparison.OrdinalIgnoreCase));
        if (n > 0)
            Message?.Invoke($"{Map.CountryOf(subject)?.Name ?? subject} is independent again.");
        return n > 0;
    }

    public static string RankName(PuppetRank r) => r switch
    {
        PuppetRank.Protectorate => "Protectorate",
        PuppetRank.Dominion => "Dominion",
        PuppetRank.Satellite => "Satellite",
        PuppetRank.Puppet => "Puppet",
        PuppetRank.Integrated => "Integrated Puppet",
        _ => r.ToString(),
    };

    /// <summary>
    /// End a war. If either side occupies enemy territory, opens a peace conference
    /// (interactive for the player, auto-resolved for pure AI wars).
    /// White peace (no occupation) just returns land and ends the war.
    /// </summary>
    public bool MakePeace(string a, string b, bool forcedCapitulation = false)
    {
        var war = Wars.FirstOrDefault(w => w.Is(a, b));
        if (war == null) return false;

        int occA = OccupationScore(a, b);
        int occB = OccupationScore(b, a);
        double wsA = war.ScoreOf(a) + occA * 2;
        double wsB = war.ScoreOf(b) + occB * 2;

        string winner, loser;
        double winnerWs;
        if (wsA <= 0.1 && wsB <= 0.1 && occA == 0 && occB == 0)
        {
            EndWarWhitePeace(a, b);
            return true;
        }
        if (wsA >= wsB) { winner = a; loser = b; winnerWs = wsA; }
        else { winner = b; loser = a; winnerWs = wsB; }

        // conference budget blends war score + occupation
        int budget = Math.Max(1, (int)(winnerWs * 0.6) + Math.Max(occA, occB));
        var conf = BuildConference(winner, loser, budget, winnerWs, forcedCapitulation);
        Conferences.Add(conf);

        if (conf.InvolvesPlayer)
        {
            string reason = forcedCapitulation ? " (capitulation!)" : "";
            Message?.Invoke($"Peace conference: {Map.CountryOf(winner)!.Name} vs {Map.CountryOf(loser)!.Name} — war score {winnerWs:0}, budget {budget}{reason}. Press K.");
            ConferenceOpened?.Invoke(conf);
        }
        else
        {
            AutoResolveConference(conf);
        }
        return true;
    }

    /// <summary>How many "points" of enemy territory does <paramref name="occupier"/> control that belongs to <paramref name="victim"/>?</summary>
    public int OccupationScore(string occupier, string victim)
    {
        int score = 0;
        foreach (var st in Map.States.Values)
        {
            if (st.Owner != victim) continue;
            int land = 0, held = 0;
            foreach (int pid in st.Provinces)
            {
                if (pid <= 0 || pid >= Map.Provinces.Length || !Map.Provinces[pid].IsLand) continue;
                land++;
                if (Map.Provinces[pid].Controller == occupier) held++;
            }
            if (land == 0 || held == 0) continue;
            int basePts = Math.Max(1, st.Manpower / 50000);
            score += held >= land ? basePts * 3 : basePts;
        }
        // cities / capital bonus
        foreach (var city in Map.Cities.Where(c => c.OwnerTag == victim))
        {
            if (city.ProvinceId > 0 && city.ProvinceId < Map.Provinces.Length
                && Map.Provinces[city.ProvinceId].Controller == occupier)
                score += city.IsCapital ? 8 : 2;
        }
        return score;
    }

    /// <summary>Current war score for tag against a specific enemy (0 if not at war).</summary>
    public double WarScoreAgainst(string tag, string enemy)
    {
        var war = Wars.FirstOrDefault(w => w.Is(tag, enemy));
        if (war == null) return 0;
        return war.ScoreOf(tag) + OccupationScore(tag, enemy) * 2;
    }

    private PeaceConference BuildConference(string winner, string loser, int score, double winnerWarScore, bool forcedCapitulation = false)
    {
        var loserCountry = Map.CountryOf(loser);
        var conf = new PeaceConference
        {
            Winner = winner,
            Loser = loser,
            Started = Date,
            Score = Math.Max(1, score),
            WinnerWarScore = winnerWarScore,
            LoserCapitulation = loserCountry?.Capitulation ?? 0,
            InvolvesPlayer = winner == PlayerTag || loser == PlayerTag,
            ForcedByCapitulation = forcedCapitulation,
        };

        foreach (var st in Map.States.Values)
        {
            if (st.Owner != loser) continue;
            // only states that the winner at least partially occupies are demandable
            int land = 0, held = 0;
            string? ctrl = null;
            foreach (int pid in st.Provinces)
            {
                if (pid <= 0 || pid >= Map.Provinces.Length || !Map.Provinces[pid].IsLand) continue;
                land++;
                if (Map.Provinces[pid].Controller == winner) { held++; ctrl = winner; }
            }
            if (held == 0) continue;

            int cost = Math.Max(1, st.Manpower / 40000);
            if (held < land) cost = Math.Max(1, cost / 2); // partial occupation cheaper but weaker claim

            conf.Demands.Add(new PeaceDemand
            {
                StateId = st.Id,
                StateName = st.Name,
                CurrentOwner = st.Owner,
                Controller = ctrl ?? winner,
                Action = PeaceActionKind.Annex,
                ScoreCost = cost,
                Selected = false,
            });
        }
        return conf;
    }

    /// <summary>AI picks the highest-value demands it can afford, then applies them.</summary>
    public void AutoResolveConference(PeaceConference conf)
    {
        if (conf.Resolved) return;
        int budget = conf.Score;
        // if high war score vs capitulation, prefer whole-country puppet over piecemeal annex
        bool preferPuppet = conf.ForcedByCapitulation || conf.LoserCapitulation >= 70 || conf.WinnerWarScore >= 40;
        if (preferPuppet && conf.Demands.Count >= 2)
        {
            // mark all demands as puppet (cheaper than full annex) if budget allows total
            int puppetCost = Math.Max(1, conf.Demands.Sum(d => d.ScoreCost) / 3);
            if (puppetCost <= budget)
            {
                var rank = conf.ForcedByCapitulation ? PuppetRank.Puppet
                    : conf.WinnerWarScore >= 60 ? PuppetRank.Integrated
                    : PuppetRank.Satellite;
                foreach (var d in conf.Demands)
                {
                    d.Selected = true;
                    d.Action = PeaceActionKind.Puppet;
                    d.PuppetRank = rank;
                    d.ScoreCost = Math.Max(1, d.ScoreCost / 3);
                }
                ApplyConference(conf);
                return;
            }
        }

        foreach (var d in conf.Demands.OrderByDescending(d => d.ScoreCost))
        {
            if (d.ScoreCost <= budget)
            {
                d.Selected = true;
                d.Action = PeaceActionKind.Annex;
                budget -= d.ScoreCost;
            }
        }
        ApplyConference(conf);
    }

    /// <summary>Player (or caller) finalises the conference after selecting demands.</summary>
    public void ApplyConference(PeaceConference conf)
    {
        if (conf.Resolved) return;
        conf.Resolved = true;

        // end the war first
        Wars.RemoveAll(w => w.Is(conf.Winner, conf.Loser));

        int annexed = 0;
        bool madePuppet = false;
        PuppetRank puppetRank = PuppetRank.Puppet;
        foreach (var d in conf.Demands.Where(x => x.Selected))
        {
            switch (d.Action)
            {
                case PeaceActionKind.Annex:
                case PeaceActionKind.Occupy:
                    if (SetStateOwner(d.StateId, conf.Winner))
                    {
                        if (d.Action == PeaceActionKind.Annex && Map.States.TryGetValue(d.StateId, out var st))
                            st.Cores.Add(conf.Winner);
                        annexed++;
                    }
                    break;
                case PeaceActionKind.Puppet:
                    // whole-country subject: leave land with loser, establish subject relation
                    madePuppet = true;
                    puppetRank = d.PuppetRank;
                    break;
                case PeaceActionKind.Liberate:
                    break;
            }
        }
        if (madePuppet)
            SetSubject(conf.Winner, conf.Loser, puppetRank);

        // any remaining occupied land of either side goes back to legal owner
        foreach (var p in Map.Provinces)
        {
            if (!p.IsLand) continue;
            var owner = Map.OwnerOf(p.Id);
            if (owner == null) continue;
            if ((p.Controller == conf.Winner || p.Controller == conf.Loser) && p.Controller != owner)
                p.Controller = owner;
        }

        // pull armies home if stuck in former enemy land
        foreach (var army in Armies.Where(x => x.Owner == conf.Winner || x.Owner == conf.Loser).ToList())
        {
            var here = Map.OwnerOf(army.ProvinceId);
            if (here != null && here != army.Owner && !AtWar(army.Owner, here))
                TeleportHome(army);
        }

        // stability / war support swings
        if (Map.CountryOf(conf.Winner) is { } w)
        {
            w.Stability = Math.Clamp(w.Stability + 3, 0, 100);
            w.WarSupport = Math.Clamp(w.WarSupport - 5, 0, 100);
        }
        if (Map.CountryOf(conf.Loser) is { } l)
        {
            l.Stability = Math.Clamp(l.Stability - 8, 0, 100);
            l.WarSupport = Math.Clamp(l.WarSupport - 10, 0, 100);
        }

        var wName = Map.CountryOf(conf.Winner)?.Name ?? conf.Winner;
        var lName = Map.CountryOf(conf.Loser)?.Name ?? conf.Loser;
        string msg;
        if (madePuppet)
            msg = $"Peace: {lName} becomes a {RankName(puppetRank)} of {wName}.";
        else if (annexed > 0)
            msg = $"Peace: {wName} annexes {annexed} state(s) from {lName}.";
        else
            msg = $"White peace between {wName} and {lName}.";
        Message?.Invoke(msg);
        MapChanged?.Invoke();
    }

    /// <summary>True white peace — no territory changes, just end the war and reset controllers.</summary>
    private void EndWarWhitePeace(string a, string b)
    {
        Wars.RemoveAll(w => w.Is(a, b));
        foreach (var army in Armies.Where(x => x.Owner == a || x.Owner == b).ToList())
        {
            var here = Map.OwnerOf(army.ProvinceId);
            if (here != null && here != army.Owner) TeleportHome(army);
        }
        foreach (var p in Map.Provinces)
        {
            if (!p.IsLand) continue;
            var owner = Map.OwnerOf(p.Id);
            if ((p.Controller == a && owner == b) || (p.Controller == b && owner == a))
                p.Controller = owner;
        }
        Message?.Invoke($"White peace between {Map.CountryOf(a)?.Name ?? a} and {Map.CountryOf(b)?.Name ?? b}.");
        MapChanged?.Invoke();
    }

    /// <summary>Toggle a demand in the active player conference. Returns false if over budget.</summary>
    public bool ToggleDemand(PeaceConference conf, int stateId)
    {
        if (conf.Resolved || !conf.InvolvesPlayer) return false;
        var d = conf.Demands.FirstOrDefault(x => x.StateId == stateId);
        if (d == null) return false;
        if (d.Selected) { d.Selected = false; return true; }
        int used = conf.Demands.Where(x => x.Selected).Sum(x => x.ScoreCost);
        if (used + d.ScoreCost > conf.Score) return false;
        d.Selected = true;
        return true;
    }

    private void TeleportHome(Army army)
    {
        var home = Map.StatesOf(army.Owner).SelectMany(s => s.Provinces)
                      .Where(id => id > 0 && id < Map.Provinces.Length && Map.Provinces[id].IsLand).ToList();
        if (home.Count == 0) { Armies.Remove(army); return; }
        army.ProvinceId = home[_rng.Next(home.Count)];
        army.Path.Clear();
        army.Progress = 0;
    }

    // ------------------------------------------------------------------ formables & releasables
    /// <summary>All formable defs (built-in + dynamic dead-tag formables).</summary>
    public List<FormableDef> AllFormables()
    {
        var list = new List<FormableDef>(FormableLibrary.BuiltIn);
        foreach (var d in FormableLibrary.DiscoverFromMap(Map))
            if (!list.Any(x => string.Equals(x.ResultTag, d.ResultTag, StringComparison.OrdinalIgnoreCase)
                               && x.RequiredTags.Count == 1))
                list.Add(d);
        return list;
    }

    public double FormableProgress(string actorTag, FormableDef def)
    {
        var owned = Map.StatesOf(actorTag).Select(s => s.Id).ToHashSet();
        if (def.RequiredStates.Count > 0)
        {
            int need = Math.Max(1, (int)Math.Ceiling(def.RequiredStates.Count * def.RequiredFraction));
            int have = def.RequiredStates.Count(id => owned.Contains(id));
            return Math.Clamp(have / (double)need, 0, 1);
        }

        var coreStates = Map.States.Values
            .Where(s => def.RequiredTags.Any(t => s.Cores.Contains(t)))
            .Select(s => s.Id).Distinct().ToList();
        if (coreStates.Count == 0) return 0;
        int need2 = Math.Max(1, (int)Math.Ceiling(coreStates.Count * def.RequiredFraction));
        int have2 = coreStates.Count(id => owned.Contains(id));
        return Math.Clamp(have2 / (double)need2, 0, 1);
    }

    public bool CanForm(string actorTag, FormableDef def)
    {
        if (Map.CountryOf(actorTag) == null) return false;
        // already are that tag
        if (string.Equals(actorTag, def.ResultTag, StringComparison.OrdinalIgnoreCase)
            && Map.StatesOf(actorTag).Any())
            return false;
        return FormableProgress(actorTag, def) >= 1.0;
    }

    public List<FormableDef> AvailableFormables(string actorTag) =>
        AllFormables().Where(d => CanForm(actorTag, d)).ToList();

    /// <summary>
    /// Form a nation: transfer controlled required cores to ResultTag, switch player if needed,
    /// absorb actor into the formable when tags differ.
    /// </summary>
    public bool FormNation(string actorTag, FormableDef def)
    {
        if (!CanForm(actorTag, def)) return false;
        EnsureCountryExists(def.ResultTag, def.Name);

        var actor = Map.CountryOf(actorTag)!;
        var target = Map.CountryOf(def.ResultTag)!;

        // states to transfer: owned by actor that are required cores / listed states
        var toTransfer = Map.StatesOf(actorTag).Where(s =>
            def.RequiredStates.Contains(s.Id) ||
            def.RequiredTags.Any(t => s.Cores.Contains(t)) ||
            string.Equals(s.Owner, actorTag, StringComparison.OrdinalIgnoreCase)
        ).ToList();

        // if forming into a different tag, move all actor land that matches requirements
        if (!string.Equals(actorTag, def.ResultTag, StringComparison.OrdinalIgnoreCase))
        {
            foreach (var st in toTransfer)
                SetStateOwner(st.Id, def.ResultTag);

            // add cores of formable
            foreach (var st in Map.StatesOf(def.ResultTag))
                st.Cores.Add(def.ResultTag);

            // move armies
            foreach (var a in Armies.Where(a => a.Owner == actorTag).ToList())
                a.Owner = def.ResultTag;

            // player switch
            if (string.Equals(PlayerTag, actorTag, StringComparison.OrdinalIgnoreCase))
                SetPlayer(def.ResultTag);

            // inheritance of some politics
            target.Ideology = actor.Ideology;
            target.Stability = Math.Max(target.Stability, actor.Stability);
            target.WarSupport = Math.Max(target.WarSupport, actor.WarSupport * 0.8);
            target.Treasury += actor.Treasury * 0.5;
            target.ManpowerPool += actor.ManpowerPool * 0.5;
            if (string.IsNullOrEmpty(target.Name) || target.Name == target.Tag)
                target.Name = def.Name;
        }
        else
        {
            foreach (var st in Map.StatesOf(actorTag))
                st.Cores.Add(def.ResultTag);
            if (string.IsNullOrEmpty(target.Name) || target.Name == target.Tag)
                target.Name = def.Name;
        }

        Message?.Invoke($"{actor.Name} formed {def.Name}!");
        MapChanged?.Invoke();
        return true;
    }

    /// <summary>
    /// Nations that can be released from <paramref name="overlord"/>'s land (cores of other tags).
    /// </summary>
    public List<ReleaseOption> GetReleasables(string overlord)
    {
        var result = new List<ReleaseOption>();
        var byTag = new Dictionary<string, ReleaseOption>(StringComparer.OrdinalIgnoreCase);

        foreach (var st in Map.StatesOf(overlord))
        {
            foreach (var core in st.Cores)
            {
                if (string.Equals(core, overlord, StringComparison.OrdinalIgnoreCase)) continue;
                var c = Map.CountryOf(core);
                if (c == null) continue;

                // only release if that nation owns none (or very few) of their cores already under overlord control path
                if (!byTag.TryGetValue(core, out var opt))
                {
                    opt = new ReleaseOption
                    {
                        Tag = core,
                        Name = c.Name,
                        TotalCores = Map.States.Values.Count(s => s.Cores.Contains(core)),
                    };
                    byTag[core] = opt;
                }
                opt.StateIds.Add(st.Id);
            }
        }

        foreach (var opt in byTag.Values)
        {
            if (opt.StateIds.Count == 0) continue;
            // skip if this tag already owns a lot of land (already free)
            int theyOwn = Map.StatesOf(opt.Tag).Count();
            if (theyOwn >= opt.StateIds.Count) continue;
            result.Add(opt);
        }

        return result.OrderByDescending(o => o.StateIds.Count).ToList();
    }

    /// <summary>
    /// Release a nation from overlord's cores. If asPuppet, creates a subject relation.
    /// </summary>
    public bool ReleaseNation(string overlord, string releaseTag, bool asPuppet = true, PuppetRank rank = PuppetRank.Puppet)
    {
        var opts = GetReleasables(overlord);
        var opt = opts.FirstOrDefault(o => string.Equals(o.Tag, releaseTag, StringComparison.OrdinalIgnoreCase));
        if (opt == null || opt.StateIds.Count == 0) return false;

        EnsureCountryExists(releaseTag, opt.Name);
        foreach (int sid in opt.StateIds)
            SetStateOwner(sid, releaseTag);

        // clear wars between them
        foreach (var w in Wars.Where(w => w.Is(overlord, releaseTag)).ToList())
            Wars.Remove(w);

        if (asPuppet)
        {
            Subjects.RemoveAll(s => string.Equals(s.Subject, releaseTag, StringComparison.OrdinalIgnoreCase));
            Subjects.Add(new SubjectRelation
            {
                Overlord = overlord,
                Subject = releaseTag,
                Rank = rank,
                Established = Date,
            });
        }

        var over = Map.CountryOf(overlord);
        Message?.Invoke($"{over?.Name ?? overlord} released {(asPuppet ? RankName(rank) + " " : "")}{opt.Name}.");
        MapChanged?.Invoke();
        return true;
    }

    private void EnsureCountryExists(string tag, string? name = null)
    {
        tag = tag.ToUpperInvariant();
        if (Map.CountryOf(tag) != null) return;
        var c = new Country
        {
            Tag = tag,
            Name = string.IsNullOrEmpty(name) ? tag : name!,
            Index = Map.CountryList.Count + 1,
        };
        var (r, g, b) = HashColor(tag);
        c.R = r; c.G = g; c.B = b;
        c.Leader = GenerateLeader(c);
        c.Stability = 55;
        c.WarSupport = 40;
        Map.Countries[tag] = c;
        Map.CountryList.Add(c);
    }

    private static (byte r, byte g, byte b) HashColor(string tag)
    {
        unchecked
        {
            int h = tag.GetHashCode();
            return ((byte)(40 + (h & 0x7F)), (byte)(40 + ((h >> 8) & 0x7F)), (byte)(40 + ((h >> 16) & 0x7F)));
        }
    }

    // ------------------------------------------------------------------ scenario editing
    public void SetDate(DateTime date) => Date = date;

    public void SetPlayer(string? tag)
    {
        PlayerTag = tag;
        foreach (var c in Map.CountryList)
            c.IsPlayer = string.Equals(c.Tag, tag, StringComparison.OrdinalIgnoreCase);
        MapChanged?.Invoke();
    }

    public bool SetStateOwner(int stateId, string tag)
    {
        if (!Map.States.TryGetValue(stateId, out var state)) return false;
        var country = Map.CountryOf(tag);
        if (country == null) return false;

        state.Owner = country.Tag;
        foreach (int pid in state.Provinces)
            if (pid > 0 && pid < Map.Provinces.Length && Map.Provinces[pid].IsLand)
                Map.Provinces[pid].Controller = country.Tag;
        MapChanged?.Invoke();
        return true;
    }

    /// <summary>
    /// Transfer a single province to <paramref name="tag"/> without giving them the whole state.
    /// Moves the province into an existing state of that country (or takes the whole state if
    /// it only has this one land province / country has no states yet).
    /// </summary>
    public bool SetProvinceOwner(int provinceId, string tag)
    {
        if (provinceId <= 0 || provinceId >= Map.Provinces.Length) return false;
        var p = Map.Provinces[provinceId];
        if (!p.IsLand) return false;
        var country = Map.CountryOf(tag);
        if (country == null) return false;

        // already owned by tag via its state?
        var currentOwner = Map.OwnerOf(provinceId);
        if (string.Equals(currentOwner, tag, StringComparison.OrdinalIgnoreCase))
        {
            p.Controller = tag;
            MapChanged?.Invoke();
            return true;
        }

        int oldStateId = p.StateId;
        if (oldStateId == 0 || !Map.States.TryGetValue(oldStateId, out var oldState))
            return false;

        // if this is the only land province in the state, just transfer the state
        int landCount = oldState.Provinces.Count(id =>
            id > 0 && id < Map.Provinces.Length && Map.Provinces[id].IsLand);
        if (landCount <= 1)
            return SetStateOwner(oldStateId, tag);

        // find a destination state owned by tag
        var dest = Map.StatesOf(tag).OrderByDescending(s => s.Provinces.Count).FirstOrDefault();
        if (dest == null)
        {
            // no state yet — transfer whole state as fallback
            return SetStateOwner(oldStateId, tag);
        }

        oldState.Provinces.Remove(provinceId);
        if (!dest.Provinces.Contains(provinceId))
            dest.Provinces.Add(provinceId);
        p.StateId = dest.Id;
        p.Controller = tag;
        MapChanged?.Invoke();
        return true;
    }

    public Army? AddArmy(string tag, int provinceId, double strength = 100)
    {
        var country = Map.CountryOf(tag);
        if (country == null || provinceId <= 0 || provinceId >= Map.Provinces.Length) return null;
        if (!Map.Provinces[provinceId].IsLand) return null;
        var army = SpawnArmy(country.Tag, provinceId);
        army.Strength = Math.Clamp(strength, 1, 100);
        return army;
    }

    public int RemoveArmiesAt(int provinceId) => Armies.RemoveAll(a => a.ProvinceId == provinceId);

    public List<ArmyDef> SnapshotArmies() =>
        Armies.Select(a => new ArmyDef(a.Owner, a.ProvinceId, Math.Round(a.Strength))).ToList();

    // ------------------------------------------------------------------ orders
    public bool CanEnter(string tag, Province p, UnitType type = UnitType.Infantry)
    {
        var branch = UnitStats.Branch(type);
        if (branch == UnitBranch.Naval)
        {
            // ships: sea always; coastal land only if friendly/at war (port)
            if (p.Type == ProvinceType.Sea) return true;
            if (!p.IsLand || !p.Coastal) return false;
            var ctrl = p.Controller;
            return ctrl == null || ctrl == tag || AtWar(tag, ctrl);
        }
        if (branch == UnitBranch.Air)
        {
            // air can stage on friendly land or fly over anything (simplified)
            if (!p.IsLand) return true;
            var ctrl = p.Controller;
            return ctrl == null || ctrl == tag || AtWar(tag, ctrl);
        }
        // land
        if (!p.IsLand) return false;
        var c = p.Controller;
        return c == null || c == tag || AtWar(tag, c);
    }

    public bool OrderMove(Army army, int targetProvince)
    {
        var path = Pathfinder.FindPath(Map, army.ProvinceId, targetProvince,
            p => CanEnter(army.Owner, p, army.Type));
        if (path == null) return false;
        army.Path = path;
        army.Progress = 0;
        return true;
    }

    public Army? RaiseArmy(string tag, int provinceId, UnitType? type = null)
    {
        var c = Map.CountryOf(tag);
        if (c == null || provinceId <= 0 || provinceId >= Map.Provinces.Length) return null;
        var p = Map.Provinces[provinceId];
        var ut = type ?? SelectedBuildType;
        var branch = UnitStats.Branch(ut);

        if (branch == UnitBranch.Naval)
        {
            // must place on sea or coastal owned land
            if (p.IsLand && !(p.Coastal && p.Controller == tag)) return null;
            if (p.Type == ProvinceType.Sea)
            {
                // ok
            }
            else if (!p.IsLand) return null;
        }
        else
        {
            if (!p.IsLand || p.Controller != tag) return null;
        }

        int mp = UnitStats.ManpowerCost(ut);
        int fc = UnitStats.FactoryCost(ut);
        if (c.ManpowerPool < mp) return null;
        if (c.MilProduction < fc && TotalMilFactories(tag) > 0) return null; // need production stockpile
        // allow raise with just manpower if no industry yet (early game)
        if (TotalMilFactories(tag) > 0)
        {
            if (c.MilProduction < fc) return null;
            c.MilProduction -= fc;
        }
        c.ManpowerPool -= mp;
        return SpawnArmy(tag, provinceId, type: ut);
    }

    public int TotalMilFactories(string tag) =>
        Map.StatesOf(tag).Sum(s => s.MilitaryFactories);
    public int TotalCivFactories(string tag) =>
        Map.StatesOf(tag).Sum(s => s.CivilianFactories);

    /// <summary>Spend civilian production to build a civilian or military factory in a state.</summary>
    public bool BuildFactory(string tag, int stateId, bool military)
    {
        if (!Map.States.TryGetValue(stateId, out var st)) return false;
        if (!string.Equals(st.Owner, tag, StringComparison.OrdinalIgnoreCase)) return false;
        var c = Map.CountryOf(tag);
        if (c == null) return false;
        double cost = military ? 15 : 12;
        double money = military ? 40 : 30;
        if (c.CivProduction < cost) return false;
        if (c.Treasury < money) return false;
        c.CivProduction -= cost;
        c.Treasury -= money;
        if (military) st.MilitaryFactories++;
        else st.CivilianFactories++;
        Message?.Invoke($"{c.Name} built a {(military ? "military" : "civilian")} factory in {st.Name}.");
        MapChanged?.Invoke();
        return true;
    }

    public IEnumerable<Army> ArmiesIn(int provinceId) => Armies.Where(a => a.ProvinceId == provinceId);

    // ------------------------------------------------------------------ National Focuses
    public FocusTree? GetTree(Country c) =>
        FocusTrees.TryGetValue(c.FocusTreeId, out var t) ? t : FocusTrees.GetValueOrDefault("generic");

    public bool CanStartFocus(Country c, string focusId)
    {
        if (c.ActiveFocusId != null) return false;
        var tree = GetTree(c);
        if (tree == null || !tree.ById.TryGetValue(focusId, out var node)) return false;
        if (c.CompletedFocuses.Contains(focusId)) return false;

        foreach (var pre in node.Prerequisites)
            if (!c.CompletedFocuses.Contains(pre)) return false;

        foreach (var mx in node.MutuallyExclusive)
            if (c.CompletedFocuses.Contains(mx)) return false;

        return true;
    }

    public IEnumerable<FocusNode> AvailableFocuses(Country c)
    {
        var tree = GetTree(c);
        if (tree == null) yield break;
        foreach (var n in tree.Nodes)
            if (CanStartFocus(c, n.Id))
                yield return n;
    }

    public bool StartFocus(string tag, string focusId)
    {
        var c = Map.CountryOf(tag);
        if (c == null || !CanStartFocus(c, focusId)) return false;
        var tree = GetTree(c)!;
        var node = tree.ById[focusId];
        c.ActiveFocusId = focusId;
        c.FocusDaysRemaining = node.CostDays;
        if (c.IsPlayer || tag == PlayerTag)
            Message?.Invoke($"{c.Name} began focus: {node.Name} ({node.CostDays} days)");
        return true;
    }

    public void CancelFocus(string tag)
    {
        var c = Map.CountryOf(tag);
        if (c == null || c.ActiveFocusId == null) return;
        c.ActiveFocusId = null;
        c.FocusDaysRemaining = 0;
    }

    private void TickFocuses()
    {
        foreach (var c in Map.CountryList)
        {
            if (c.ActiveFocusId == null) continue;
            c.FocusDaysRemaining--;
            if (c.FocusDaysRemaining > 0) continue;

            // complete
            var tree = GetTree(c);
            if (tree != null && tree.ById.TryGetValue(c.ActiveFocusId, out var node))
            {
                c.CompletedFocuses.Add(c.ActiveFocusId);
                ApplyEffects(c, node.Effects);
                Message?.Invoke($"{c.Name} completed focus: {node.Name}");
            }
            c.ActiveFocusId = null;
            c.FocusDaysRemaining = 0;
        }
    }

    private void ApplyEffects(Country c, List<FocusEffect> effects)
    {
        foreach (var e in effects)
        {
            switch (e.Type)
            {
                case FocusEffectType.AddStability:
                    c.Stability = Math.Clamp(c.Stability + e.DoubleArg, 0, 100);
                    break;
                case FocusEffectType.AddWarSupport:
                    c.WarSupport = Math.Clamp(c.WarSupport + e.DoubleArg, 0, 100);
                    break;
                case FocusEffectType.AddManpower:
                    c.ManpowerPool += e.IntArg;
                    break;
                case FocusEffectType.AddCore:
                    if (e.IntArg > 0 && Map.States.TryGetValue(e.IntArg, out var st))
                        st.Cores.Add(c.Tag);
                    else if (!string.IsNullOrEmpty(e.StringArg) && int.TryParse(e.StringArg, out int sid) && Map.States.TryGetValue(sid, out st))
                        st.Cores.Add(c.Tag);
                    break;
                case FocusEffectType.DeclareWar:
                    if (!string.IsNullOrEmpty(e.StringArg))
                        DeclareWar(c.Tag, e.StringArg);
                    break;
                case FocusEffectType.CreateUnit:
                    {
                        int capital = c.Capital;
                        if (capital <= 0 || capital >= Map.Provinces.Length || !Map.Provinces[capital].IsLand)
                        {
                            var any = Map.StatesOf(c.Tag).SelectMany(s => s.Provinces)
                                .FirstOrDefault(id => id > 0 && id < Map.Provinces.Length && Map.Provinces[id].IsLand);
                            capital = any;
                        }
                        if (capital > 0)
                            for (int i = 0; i < Math.Max(1, e.IntArg); i++)
                                SpawnArmy(c.Tag, capital);
                    }
                    break;
                case FocusEffectType.SetIdeology:
                    c.Ideology = (e.StringArg ?? "").ToLowerInvariant() switch
                    {
                        "democratic" or "democracy" => Ideology.Democratic,
                        "fascist" or "fascism" => Ideology.Fascist,
                        "communist" or "communism" => Ideology.Communist,
                        "monarchist" or "neutrality" => Ideology.Monarchist,
                        _ => Ideology.Neutral,
                    };
                    break;
                case FocusEffectType.AddSpirit:
                    if (!string.IsNullOrEmpty(e.StringArg) && !c.Spirits.Contains(e.StringArg))
                        c.Spirits.Add(e.StringArg);
                    break;
                case FocusEffectType.RemoveSpirit:
                    if (!string.IsNullOrEmpty(e.StringArg))
                        c.Spirits.Remove(e.StringArg);
                    break;
                case FocusEffectType.CustomMessage:
                    if (!string.IsNullOrEmpty(e.StringArg))
                        Message?.Invoke(e.StringArg);
                    break;
                case FocusEffectType.AnnexState:
                    if (e.IntArg > 0)
                        SetStateOwner(e.IntArg, c.Tag);
                    break;
            }
        }
    }

    // ------------------------------------------------------------------ Uprisings
    private void TickUnrestAndUprisings()
    {
        // accumulate unrest in non-core / occupied states
        foreach (var state in Map.States.Values)
        {
            if (state.Provinces.Count == 0) continue;
            var owner = state.Owner;
            if (string.IsNullOrEmpty(owner)) continue;

            bool isCore = state.Cores.Contains(owner);
            bool fullyControlled = state.Provinces.All(pid =>
                pid <= 0 || pid >= Map.Provinces.Length ||
                !Map.Provinces[pid].IsLand ||
                Map.Provinces[pid].Controller == owner);

            double delta = 0;
            if (!isCore) delta += 0.08;                    // non-core territory always a bit restless
            if (!fullyControlled) delta += 0.15;           // occupation by someone else
            if (Map.CountryOf(owner) is { } c)
            {
                if (c.Stability < 40) delta += (40 - c.Stability) * 0.01;
                if (c.WarSupport < 30 && Wars.Any(w => w.Involves(owner))) delta += 0.05;
            }

            // cores of the controller that are owned by someone else also generate pressure the other way,
            // but for simplicity we only track unrest against the current owner.

            if (delta > 0)
                state.Unrest = Math.Min(100, state.Unrest + delta);
            else
                state.Unrest = Math.Max(0, state.Unrest - 0.05); // slow decay when happy
        }

        // chance to fire an uprising
        foreach (var state in Map.States.Values)
        {
            if (state.Unrest < 55) continue;
            if (Uprisings.Any(u => !u.Resolved && u.StateId == state.Id)) continue;
            if (_rng.NextDouble() > 0.015 + (state.Unrest - 55) * 0.002) continue;

            StartUprising(state);
        }

        // resolve finished uprisings (all rebel armies dead or state fully controlled by rebels)
        foreach (var u in Uprisings.Where(x => !x.Resolved).ToList())
        {
            u.ArmyIds.RemoveAll(id => !Armies.Any(a => a.Id == id));
            if (u.ArmyIds.Count == 0)
            {
                u.Resolved = true;
                if (Map.States.TryGetValue(u.StateId, out var st))
                    st.Unrest = Math.Max(0, st.Unrest - 30);
                continue;
            }

            // if rebels control every land province in the state, transfer ownership
            if (Map.States.TryGetValue(u.StateId, out var state))
            {
                bool rebelsWin = state.Provinces
                    .Where(pid => pid > 0 && pid < Map.Provinces.Length && Map.Provinces[pid].IsLand)
                    .All(pid => Map.Provinces[pid].Controller == u.RebelTag);

                if (rebelsWin)
                {
                    state.Owner = u.RebelTag;
                    state.Cores.Add(u.RebelTag);
                    state.Unrest = 10;
                    u.Resolved = true;
                    Message?.Invoke($"Uprising succeeds! {state.Name} is now controlled by {u.RebelTag}.");
                    MapChanged?.Invoke();
                }
            }
        }
    }

    private void StartUprising(State state)
    {
        var against = state.Owner;
        if (string.IsNullOrEmpty(against)) return;

        // create a temporary rebel tag if needed
        string rebelTag = "R" + state.Id.ToString("D3");
        if (!Map.Countries.ContainsKey(rebelTag))
        {
            var rebel = new Country
            {
                Tag = rebelTag,
                Name = $"{state.Name} Rebels",
                R = (byte)_rng.Next(40, 220),
                G = (byte)_rng.Next(40, 220),
                B = (byte)_rng.Next(40, 220),
                Index = Map.CountryList.Count + 1,
                Capital = state.Provinces.FirstOrDefault(id => id > 0 && id < Map.Provinces.Length && Map.Provinces[id].IsLand),
                Ideology = Ideology.Neutral,
                Stability = 40,
                WarSupport = 70,
                ManpowerPool = state.Manpower * 0.1,
                FocusTreeId = "generic",
            };
            Map.Countries[rebelTag] = rebel;
            Map.CountryList.Add(rebel);
        }

        var uprising = new Uprising
        {
            Id = _nextUprisingId++,
            StateId = state.Id,
            RebelTag = rebelTag,
            AgainstTag = against,
            Started = Date,
        };

        // spawn 1-3 rebel armies in the state
        var landProvs = state.Provinces
            .Where(id => id > 0 && id < Map.Provinces.Length && Map.Provinces[id].IsLand).ToList();
        if (landProvs.Count == 0) return;

        int n = Math.Clamp(1 + (int)(state.Unrest / 30), 1, 3);
        for (int i = 0; i < n; i++)
        {
            int pid = landProvs[_rng.Next(landProvs.Count)];
            var army = SpawnArmy(rebelTag, pid, rebel: true);
            army.Strength = 40 + _rng.Next(40);
            uprising.ArmyIds.Add(army.Id);
            // immediately contest the province
            Map.Provinces[pid].Controller = rebelTag;
        }

        // auto-war between rebels and the owner
        if (!AtWar(rebelTag, against))
            DeclareWar(rebelTag, against, permanent: true);

        Uprisings.Add(uprising);
        state.Unrest = Math.Max(20, state.Unrest - 25);

        var ownerName = Map.CountryOf(against)?.Name ?? against;
        Message?.Invoke($"Uprising in {state.Name}! Rebels rise against {ownerName}.");
        MapChanged?.Invoke();
    }

    // ------------------------------------------------------------------ simulation
    public void TickDay()
    {
        Date = Date.AddDays(1);

        if (Date.Day == 1) MonthlyUpdate();

        TickFocuses();

        // unrest / uprisings checked weekly to keep it light
        if (Date.Day % 7 == 0)
            TickUnrestAndUprisings();

        // capitulation every few days
        if (Date.Day % 3 == 0)
            TickCapitulation();

        foreach (var army in Armies.ToList())
        {
            if (!Armies.Contains(army)) continue;
            StepArmy(army);
        }

        if (Date.Day % 5 == 0) RunAi();
        if (Date.Day % 11 == 0) RunFocusAi();
    }

    private void StepArmy(Army army)
    {
        if (army.Path.Count == 0)
        {
            if (army.Strength < 100 && Map.Provinces[army.ProvinceId].Controller == army.Owner)
                army.Strength = Math.Min(100, army.Strength + 0.4);
            return;
        }

        var cur = Map.Provinces[army.ProvinceId];
        var next = Map.Provinces[army.Path[0]];
        if (!CanEnter(army.Owner, next, army.Type))
        {
            army.Path.Clear();
            army.Progress = 0;
            return;
        }

        double speed = UnitStats.BaseSpeed(army.Type);
        if (army.IsLand)
            speed /= Pathfinder.TerrainCost(next.Terrain);
        if (army.Type == UnitType.Mountaineer && next.Terrain is "mountain" or "hills")
            speed *= 1.4;
        if (army.Strength < 30) speed *= 0.6;
        army.Progress += speed;
        if (army.Progress < 1) return;

        // only fight same-branch or air vs ground for bombers
        var defenders = Armies.Where(a => a.ProvinceId == next.Id && AtWar(a.Owner, army.Owner)
            && (a.Branch == army.Branch || army.IsAir || a.IsAir)).ToList();
        if (defenders.Count > 0)
        {
            Fight(army, defenders);
            army.Progress = 1;
            return;
        }

        army.ProvinceId = next.Id;
        army.Path.RemoveAt(0);
        army.Progress = 0;

        // only land units occupy land provinces
        if (army.IsLand && next.IsLand && next.Controller != army.Owner && AtWar(army.Owner, next.Controller))
        {
            var previous = next.Controller;
            next.Controller = army.Owner;
            AwardOccupationScore(army.Owner, previous, next);
            MapChanged?.Invoke();
            if (army.Owner == PlayerTag || previous == PlayerTag)
            {
                var city = Map.CityAt(next.Id);
                string label = city != null
                    ? (city.IsCapital ? $"capital {city.Name}" : city.Name)
                    : (next.StateId != 0 && Map.States.TryGetValue(next.StateId, out var s) ? s.Name : $"province {next.Id}");
                Message?.Invoke($"{Map.CountryOf(army.Owner)!.Name} occupied {label}.");
            }
        }
    }

    private void AwardOccupationScore(string occupier, string? previous, Province prov)
    {
        if (previous == null) return;
        var war = Wars.FirstOrDefault(w => w.Is(occupier, previous));
        if (war == null) return;

        double pts = 0.4;
        var city = Map.CityAt(prov.Id);
        if (city != null)
        {
            pts += city.WarScoreValue * 0.35;
            if (city.IsCapital)
                Message?.Invoke($"{Map.CountryOf(occupier)?.Name} has taken the capital of {Map.CountryOf(previous)?.Name}!");
        }
        war.AddScore(occupier, pts);
    }

    private void Fight(Army attacker, List<Army> defenders)
    {
        var target = Map.Provinces[defenders[0].ProvinceId];
        double defBonus = target.Terrain switch { "mountain" => 1.55, "hills" => 1.3, "forest" => 1.25, "marsh" => 1.2, "jungle" => 1.25, _ => 1.05 };
        // trench / prepared defence: holding your own land digs in hard
        if (target.Controller == defenders[0].Owner) defBonus += 0.35;
        // urban capital last stands
        if (Map.CityAt(target.Id) is { IsCapital: true }) defBonus += 0.2;

        double atkPower = attacker.Strength * UnitStats.SoftAttack(attacker.Type) * (0.75 + _rng.NextDouble() * 0.35);
        double defPower = defenders.Sum(d => d.Strength * UnitStats.SoftAttack(d.Type)) * defBonus * (0.75 + _rng.NextDouble() * 0.35);
        // armor vs infantry bonus, sub vs capital ship, fighter vs bomber, etc.
        if (attacker.Type == UnitType.Armor && defenders.Any(d => d.Type is UnitType.Infantry or UnitType.Militia))
            atkPower *= 1.2;
        if (attacker.Type == UnitType.Artillery)
            atkPower *= 1.15; // artillery chips trenches
        if (attacker.Type == UnitType.Submarine && defenders.Any(d => d.Type is UnitType.Battleship or UnitType.Cruiser))
            atkPower *= 1.4;
        if (attacker.Type == UnitType.Fighter && defenders.Any(d => d.IsAir))
            atkPower *= 1.3;

        // trench warfare: low daily losses, long grinding fronts — breakthroughs are rare
        double atkLoss = 1.2 + defPower * 0.028;
        double defLoss = 1.0 + atkPower * 0.025;
        // stalled attacks against entrenched defenders take extra attrition
        if (defBonus >= 1.3 && atkPower < defPower * 1.1)
            atkLoss *= 1.35;
        attacker.Strength -= atkLoss;
        foreach (var d in defenders)
            d.Strength -= defLoss / defenders.Count + 0.4;

        int killedDef = defenders.Count(x => x.Strength <= 0);
        foreach (var d in defenders.Where(x => x.Strength <= 0).ToList())
            Armies.Remove(d);
        bool atkDead = attacker.Strength <= 0;
        if (atkDead)
            Armies.Remove(attacker);

        // battle war score: reward the side that inflicted more damage / wiped stacks
        var war = Wars.FirstOrDefault(w => w.Is(attacker.Owner, defenders[0].Owner));
        if (war != null)
        {
            if (killedDef > 0) war.AddScore(attacker.Owner, 1.5 * killedDef);
            if (atkDead) war.AddScore(defenders[0].Owner, 2.0);
            else if (atkPower > defPower * 1.2) war.AddScore(attacker.Owner, 0.3);
        }
    }

    private void MonthlyUpdate()
    {
        foreach (var c in Map.CountryList)
        {
            double mp = Map.StatesOf(c.Tag).Sum(s => (double)s.Manpower);
            double stabMod = 0.7 + c.Stability / 200.0;
            double leaderMp = 1.0 + (c.Leader?.ManpowerBonus ?? 0);
            double gain = mp * 0.002 * stabMod * leaderMp;

            // subject tribute: overlord skims a share
            var sub = GetSubject(c.Tag);
            if (sub != null && Map.CountryOf(sub.Overlord) is { } overlord)
            {
                double tribute = gain * sub.TributeRate;
                overlord.ManpowerPool += tribute;
                gain -= tribute;
            }
            c.ManpowerPool += gain;

            // economy phase countdown
            if (c.EconomyPhaseMonths > 0)
            {
                c.EconomyPhaseMonths--;
                if (c.EconomyPhaseMonths <= 0)
                {
                    c.EconomyModifier = 1.0;
                    c.EconomyPhase = "Stable";
                }
            }

            // base GDP from pop + factories
            int mil = TotalMilFactories(c.Tag);
            int civ = TotalCivFactories(c.Tag);
            double pop = Map.StatesOf(c.Tag).Sum(s => (double)s.Manpower);
            c.Gdp = (pop * 0.00001 + civ * 8 + mil * 5) * c.EconomyModifier;

            // war damages economy slightly
            if (Wars.Any(w => w.Involves(c.Tag)))
                c.Gdp *= 0.92;

            // factory output scaled by economy
            c.MilProduction += mil * 1.5 * c.EconomyModifier;
            c.CivProduction += civ * 1.0 * c.EconomyModifier;

            // tax income into treasury
            c.Treasury += c.Gdp * 0.35;
            c.TradeBalance = 0; // reset; filled by trade pass below

            if (c.Stability < 50) c.Stability = Math.Min(50, c.Stability + 0.3);
            else if (c.Stability > 70) c.Stability = Math.Max(70, c.Stability - 0.15);
        }

        // trade income
        TickTrade();

        // random booms / crashes (rare, per country)
        TickEconomicCycles();

        // AI trade
        AiConsiderTrade();

        // timed AI wars → peace conference
        foreach (var w in Wars.Where(w => w.EndsOn.HasValue && w.EndsOn.Value <= Date).ToList())
            MakePeace(w.A, w.B);

        // also end wars early if one side is clearly winning
        foreach (var w in Wars.Where(w => !w.EndsOn.HasValue || w.EndsOn.Value > Date).ToList())
        {
            if (w.Involves(PlayerTag ?? "")) continue;
            int days = (Date - w.Start).Days;
            if (days < 45) continue;
            double sa = w.ScoreA + OccupationScore(w.A, w.B) * 2;
            double sb = w.ScoreB + OccupationScore(w.B, w.A) * 2;
            if (sa >= 25 && sa > sb * 2) MakePeace(w.A, w.B);
            else if (sb >= 25 && sb > sa * 2) MakePeace(w.A, w.B);
        }

        AiConsiderWars();
        AiRaiseArmies();
        AiConsiderAlliances();
    }

    // -------------------- economy & trade --------------------
    private void TickTrade()
    {
        // cancel trade between countries at war
        foreach (var t in TradeDeals.Where(t => t.Active && AtWar(t.A, t.B)).ToList())
        {
            t.Active = false;
            Message?.Invoke($"Trade between {Map.CountryOf(t.A)?.Name} and {Map.CountryOf(t.B)?.Name} suspended (war).");
        }

        foreach (var t in TradeDeals.Where(t => t.Active))
        {
            var ca = Map.CountryOf(t.A);
            var cb = Map.CountryOf(t.B);
            if (ca == null || cb == null) continue;

            // volume scales with both economies and their modifiers
            double vol = t.Volume * (0.5 + 0.25 * ca.EconomyModifier + 0.25 * cb.EconomyModifier);
            // both gain; slightly more to the larger GDP partner
            double shareA = ca.Gdp >= cb.Gdp ? 0.55 : 0.45;
            double shareB = 1.0 - shareA;
            ca.Treasury += vol * shareA;
            cb.Treasury += vol * shareB;
            ca.TradeBalance += vol * shareA;
            cb.TradeBalance += vol * shareB;
            // small civ production bonus from open trade
            ca.CivProduction += vol * 0.02;
            cb.CivProduction += vol * 0.02;
        }
    }

    private void TickEconomicCycles()
    {
        foreach (var c in Map.CountryList)
        {
            if (c.EconomyPhaseMonths > 0) continue; // already in a phase
            double roll = _rng.NextDouble();

            // ~1.5% chance of boom, ~1.2% crash, ~2% mild recession per month when stable
            if (roll < 0.015)
            {
                StartEconomyPhase(c, "Boom", 1.25 + _rng.NextDouble() * 0.25, 4 + _rng.Next(8));
            }
            else if (roll < 0.027)
            {
                StartEconomyPhase(c, "Crash", 0.45 + _rng.NextDouble() * 0.15, 3 + _rng.Next(6));
            }
            else if (roll < 0.047)
            {
                StartEconomyPhase(c, "Recession", 0.75 + _rng.NextDouble() * 0.1, 3 + _rng.Next(5));
            }
        }
    }

    private void StartEconomyPhase(Country c, string phase, double modifier, int months)
    {
        c.EconomyPhase = phase;
        c.EconomyModifier = modifier;
        c.EconomyPhaseMonths = months;

        if (phase == "Boom")
        {
            c.Stability = Math.Clamp(c.Stability + 3, 0, 100);
            c.Treasury += c.Gdp * 2;
            if (c.IsPlayer || c.Tag == PlayerTag)
                Message?.Invoke($"Economic boom in {c.Name}! Growth x{modifier:0.00} for {months} months.");
            else if (_rng.NextDouble() < 0.15)
                Message?.Invoke($"Boom times in {c.Name}.");
        }
        else if (phase == "Crash")
        {
            c.Stability = Math.Clamp(c.Stability - 8, 0, 100);
            c.Treasury = Math.Max(0, c.Treasury - c.Gdp * 3);
            // chance to lose a factory
            var states = Map.StatesOf(c.Tag).Where(s => s.CivilianFactories > 0 || s.MilitaryFactories > 0).ToList();
            if (states.Count > 0 && _rng.NextDouble() < 0.35)
            {
                var st = states[_rng.Next(states.Count)];
                if (st.MilitaryFactories > 0 && _rng.NextDouble() < 0.5) st.MilitaryFactories--;
                else if (st.CivilianFactories > 0) st.CivilianFactories--;
            }
            Message?.Invoke($"Economic crash in {c.Name}! Output x{modifier:0.00} for {months} months.");
        }
        else // Recession
        {
            c.Stability = Math.Clamp(c.Stability - 3, 0, 100);
            if (c.IsPlayer || c.Tag == PlayerTag)
                Message?.Invoke($"Recession in {c.Name}. Growth x{modifier:0.00} for {months} months.");
        }
    }

    public bool HasTrade(string a, string b) =>
        TradeDeals.Any(t => t.Active && t.Is(a, b));

    public bool FormTrade(string a, string b)
    {
        if (a == b || Map.CountryOf(a) == null || Map.CountryOf(b) == null) return false;
        if (AtWar(a, b)) return false;
        if (HasTrade(a, b)) return false;

        var ca = Map.CountryOf(a)!;
        var cb = Map.CountryOf(b)!;
        double volume = Math.Min(ca.Gdp, cb.Gdp) * 0.15 + 5;
        volume *= 0.8 + _rng.NextDouble() * 0.4;

        TradeDeals.Add(new TradeDeal
        {
            A = a,
            B = b,
            Start = Date,
            Volume = volume,
            Active = true,
        });
        Message?.Invoke($"Trade deal: {ca.Name} ↔ {cb.Name} (volume {volume:0}).");
        return true;
    }

    public bool CancelTrade(string a, string b)
    {
        var t = TradeDeals.FirstOrDefault(x => x.Active && x.Is(a, b));
        if (t == null) return false;
        t.Active = false;
        Message?.Invoke($"Trade cancelled between {Map.CountryOf(a)?.Name} and {Map.CountryOf(b)?.Name}.");
        return true;
    }

    private void AiConsiderTrade()
    {
        foreach (var c in Map.CountryList)
        {
            if (c.IsPlayer) continue;
            if (_rng.NextDouble() > 0.025) continue;
            if (TradeDeals.Count(t => t.Active && t.Involves(c.Tag)) >= 4) continue;

            foreach (var n in LandNeighbours(c.Tag))
            {
                if (HasTrade(c.Tag, n) || AtWar(c.Tag, n)) continue;
                var nc = Map.CountryOf(n);
                if (nc == null) continue;
                // prefer same ideology or allies
                bool friendly = AreAllied(c.Tag, n)
                    || (c.Ideology != Ideology.Neutral && c.Ideology == nc.Ideology);
                if (friendly || _rng.NextDouble() < 0.2)
                {
                    FormTrade(c.Tag, n);
                    break;
                }
            }
        }
    }

    /// <summary>AI forms bilateral alliances with friendly neighbours (same ideology, not subjects).</summary>
    private void AiConsiderAlliances()
    {
        foreach (var c in Map.CountryList)
        {
            if (c.IsPlayer) continue;
            if (_rng.NextDouble() > 0.02) continue;
            if (GetSubject(c.Tag)?.Rank >= PuppetRank.Satellite) continue;
            if (AlliancesOf(c.Tag).Count() >= 3) continue; // multi-alliance cap for AI

            foreach (var n in LandNeighbours(c.Tag))
            {
                if (AreAllied(c.Tag, n) || AtWar(c.Tag, n)) continue;
                var nc = Map.CountryOf(n);
                if (nc == null || nc.IsPlayer) continue;
                if (GetSubject(n)?.Rank >= PuppetRank.Satellite) continue;
                // prefer same ideology
                if (c.Ideology != Ideology.Neutral && c.Ideology == nc.Ideology)
                {
                    FormBilateralAlliance(c.Tag, n);
                    break;
                }
                if (c.Ideology == Ideology.Neutral && _rng.NextDouble() < 0.15)
                {
                    FormBilateralAlliance(c.Tag, n);
                    break;
                }
            }
        }
    }

    /// <summary>
    /// Update capitulation % for every country at war.
    /// Factors: % of home land occupied, capital lost, enemy war score, low war support.
    /// At 100 → forced peace conference as the loser.
    /// </summary>
    private void TickCapitulation()
    {
        var atWarTags = Wars.SelectMany(w => new[] { w.A, w.B }).ToHashSet(StringComparer.OrdinalIgnoreCase);
        foreach (var c in Map.CountryList)
        {
            if (!atWarTags.Contains(c.Tag))
            {
                c.Capitulation = Math.Max(0, c.Capitulation - 2); // recover while at peace
                continue;
            }

            var states = Map.StatesOf(c.Tag).ToList();
            if (states.Count == 0) { c.Capitulation = 0; continue; }

            int totalLand = 0, lostLand = 0;
            foreach (var st in states)
            foreach (int pid in st.Provinces)
            {
                if (pid <= 0 || pid >= Map.Provinces.Length || !Map.Provinces[pid].IsLand) continue;
                totalLand++;
                if (Map.Provinces[pid].Controller != c.Tag) lostLand++;
            }

            double lostPct = totalLand > 0 ? 100.0 * lostLand / totalLand : 0;
            bool capitalLost = c.Capital > 0 && c.Capital < Map.Provinces.Length
                               && Map.Provinces[c.Capital].Controller != c.Tag;

            // enemy war score pressure
            double enemyWs = 0;
            foreach (var w in Wars.Where(w => w.Involves(c.Tag)))
            {
                string enemy = w.A == c.Tag ? w.B : w.A;
                enemyWs = Math.Max(enemyWs, w.ScoreOf(enemy) + OccupationScore(enemy, c.Tag) * 2);
            }

            double target = lostPct * 0.55
                            + (capitalLost ? 25 : 0)
                            + Math.Min(30, enemyWs * 0.25)
                            + (c.WarSupport < 30 ? (30 - c.WarSupport) * 0.3 : 0)
                            + (c.Stability < 35 ? (35 - c.Stability) * 0.2 : 0);

            // smooth toward target
            if (target > c.Capitulation) c.Capitulation = Math.Min(100, c.Capitulation + Math.Max(0.5, (target - c.Capitulation) * 0.15));
            else c.Capitulation = Math.Max(0, c.Capitulation - 0.8);

            if (c.Capitulation >= 100)
            {
                // force peace with the strongest enemy
                string? bestEnemy = null;
                double best = -1;
                foreach (var w in Wars.Where(w => w.Involves(c.Tag)).ToList())
                {
                    string enemy = w.A == c.Tag ? w.B : w.A;
                    double s = w.ScoreOf(enemy) + OccupationScore(enemy, c.Tag) * 2;
                    if (s > best) { best = s; bestEnemy = enemy; }
                }
                if (bestEnemy != null)
                {
                    Message?.Invoke($"{c.Name} has capitulated!");
                    MakePeace(c.Tag, bestEnemy, forcedCapitulation: true);
                    c.Capitulation = 0;
                }
            }
        }
    }

    /// <summary>Smarter war declaration: only attack weaker / isolated neighbours when ready.</summary>
    private void AiConsiderWars()
    {
        foreach (var c in Map.CountryList)
        {
            if (c.IsPlayer) continue;
            if (_rng.NextDouble() > 0.012) continue; // still rare
            if (Wars.Count(w => w.Involves(c.Tag)) >= 2) continue;

            int myArmies = Armies.Count(a => a.Owner == c.Tag);
            if (myArmies < 2) continue;
            if (c.WarSupport < 35) continue;
            if (c.Stability < 30) continue;

            var target = PickWarTarget(c.Tag, myArmies);
            if (target != null)
                DeclareWar(c.Tag, target);
        }
    }

    private string? PickWarTarget(string tag, int myArmies)
    {
        var candidates = new List<(string tag, double score)>();
        var neighbours = LandNeighbours(tag);
        foreach (var n in neighbours)
        {
            if (AtWar(tag, n)) continue;
            if (AreAllied(tag, n)) continue;
            if (IsSubjectOf(n, tag) || IsSubjectOf(tag, n)) continue;
            var nc = Map.CountryOf(n);
            if (nc == null) continue;
            // don't dogpile the player too hard early
            if (n == PlayerTag && (Date - new DateTime(1936, 1, 1)).Days < 180) continue;

            int theirArmies = Armies.Count(a => a.Owner == n);
            int theirWars = Wars.Count(w => w.Involves(n));
            double strengthRatio = (double)myArmies / Math.Max(1, theirArmies);
            if (strengthRatio < 0.9 && theirWars == 0) continue; // only attack if stronger or they're busy

            double score = strengthRatio * 10;
            score += theirWars * 5;                         // prefer distracted targets
            score += nc.Stability < 40 ? 3 : 0;
            score -= nc.IsPlayer ? 4 : 0;                   // slight reluctance vs player
            // ideology tension
            var me = Map.CountryOf(tag);
            if (me != null && me.Ideology != Ideology.Neutral && nc.Ideology != Ideology.Neutral && me.Ideology != nc.Ideology)
                score += 2;
            candidates.Add((n, score));
        }
        if (candidates.Count == 0) return null;
        candidates.Sort((a, b) => b.score.CompareTo(a.score));
        // pick among top 3 with some randomness
        int take = Math.Min(3, candidates.Count);
        return candidates[_rng.Next(take)].tag;
    }

    private HashSet<string> LandNeighbours(string tag)
    {
        var set = new HashSet<string>();
        foreach (var s in Map.StatesOf(tag))
            foreach (var pid in s.Provinces)
            {
                if (pid <= 0 || pid >= Map.Provinces.Length) continue;
                foreach (var e in Map.Provinces[pid].Edges)
                {
                    if (e.Kind != EdgeKind.Land) continue;
                    var o = Map.OwnerOf(e.To);
                    if (o != null && o != tag) set.Add(o);
                }
            }
        return set;
    }

    /// <summary>AI raises armies when it has spare manpower and is at war or preparing.</summary>
    private void AiRaiseArmies()
    {
        foreach (var c in Map.CountryList)
        {
            if (c.IsPlayer) continue;
            if (c.ManpowerPool < ArmyCost * 1.5) continue;
            bool atWar = Wars.Any(w => w.Involves(c.Tag));
            int current = Armies.Count(a => a.Owner == c.Tag);
            int desired = atWar ? Math.Min(20, 4 + current) : Math.Min(12, 2 + current / 2);
            if (current >= desired) continue;

            // spawn near capital or a border province
            int spawn = c.Capital;
            if (spawn <= 0 || spawn >= Map.Provinces.Length || Map.Provinces[spawn].Controller != c.Tag)
            {
                spawn = Map.StatesOf(c.Tag).SelectMany(s => s.Provinces)
                    .FirstOrDefault(id => id > 0 && id < Map.Provinces.Length
                                          && Map.Provinces[id].IsLand
                                          && Map.Provinces[id].Controller == c.Tag);
            }
            if (spawn > 0)
                RaiseArmy(c.Tag, spawn);
        }
    }

    /// <summary>
    /// Smarter operational AI:
    /// - prioritise enemy capitals and high-manpower states
    /// - reinforce battles / push weak fronts
    /// - rest low-strength armies
    /// - hunt rebel stacks on home territory
    /// </summary>
    private void RunAi()
    {
        // group idle AI armies by owner
        var byOwner = Armies
            .Where(a => a.Owner != PlayerTag && a.Path.Count == 0)
            .GroupBy(a => a.Owner);

        foreach (var group in byOwner)
        {
            string tag = group.Key;
            var enemies = EnemiesOf(tag).ToHashSet();
            if (enemies.Count == 0)
            {
                // peacetime: suppress rebels on owned land (land units only)
                foreach (var army in group.Where(a => a.Strength >= 40 && a.IsLand))
                {
                    var path = Pathfinder.FindNearest(
                        Map, army.ProvinceId,
                        p => CanEnter(tag, p, army.Type),
                        p => p.Controller != tag && Map.OwnerOf(p.Id) == tag);
                    if (path != null && path.Count > 0) army.Path = path;
                }
                continue;
            }

            // build a priority list of enemy provinces: capital > high manpower > any occupied-by-us push
            var targets = new List<(int pid, double priority)>();
            foreach (var enemy in enemies)
            {
                var ec = Map.CountryOf(enemy);
                if (ec == null) continue;
                if (ec.Capital > 0 && ec.Capital < Map.Provinces.Length)
                {
                    var cap = Map.Provinces[ec.Capital];
                    if (cap.Controller != tag)
                        targets.Add((ec.Capital, 100 + (ec.Population > 0 ? 20 : 0)));
                }
                foreach (var st in Map.StatesOf(enemy))
                {
                    double val = 10 + st.Manpower / 100000.0;
                    foreach (int pid in st.Provinces)
                    {
                        if (pid <= 0 || pid >= Map.Provinces.Length) continue;
                        var p = Map.Provinces[pid];
                        if (!p.IsLand || p.Controller == tag) continue;
                        double prio = val;
                        if (p.Controller == enemy) prio += 5;
                        // prefer provinces adjacent to us
                        bool border = p.Edges.Any(e => e.Kind == EdgeKind.Land
                            && e.To > 0 && e.To < Map.Provinces.Length
                            && Map.Provinces[e.To].Controller == tag);
                        if (border) prio += 15;
                        targets.Add((pid, prio));
                    }
                }
            }
            if (targets.Count == 0) continue;
            targets.Sort((a, b) => b.priority.CompareTo(a.priority));

            // assign armies to top targets, spreading out
            var claimed = new HashSet<int>();
            foreach (var army in group.OrderByDescending(a => a.Strength))
            {
                if (army.IsNaval) continue; // naval AI kept simple for now
                if (army.Strength < 35)
                {
                    if (army.IsLand && Map.Provinces[army.ProvinceId].Controller != tag)
                    {
                        var home = Pathfinder.FindNearest(
                            Map, army.ProvinceId,
                            p => CanEnter(tag, p, army.Type),
                            p => p.Controller == tag);
                        if (home != null && home.Count > 0) army.Path = home;
                    }
                    continue;
                }

                foreach (var (pid, _) in targets)
                {
                    if (claimed.Contains(pid)) continue;
                    var path = Pathfinder.FindPath(Map, army.ProvinceId, pid, p => CanEnter(tag, p, army.Type));
                    if (path == null || path.Count == 0) continue;
                    army.Path = path;
                    claimed.Add(pid);
                    break;
                }
            }
        }
    }

    // -------------------- multiplayer / hotseat --------------------
    public void AddHumanPlayer(string tag)
    {
        if (Map.CountryOf(tag) == null) return;
        if (!HumanTags.Contains(tag, StringComparer.OrdinalIgnoreCase))
            HumanTags.Add(tag);
        Map.CountryOf(tag)!.IsPlayer = true;
    }

    public void CycleHumanPlayer()
    {
        if (HumanTags.Count == 0) return;
        int idx = HumanTags.FindIndex(t => string.Equals(t, PlayerTag, StringComparison.OrdinalIgnoreCase));
        idx = (idx + 1) % HumanTags.Count;
        SetPlayer(HumanTags[idx]);
        Message?.Invoke($"Active player: {Map.CountryOf(PlayerTag!)?.Name ?? PlayerTag}");
    }

    private void RunFocusAi()
    {
        foreach (var c in Map.CountryList)
        {
            if (c.IsPlayer || c.ActiveFocusId != null) continue;
            var available = AvailableFocuses(c).ToList();
            if (available.Count == 0) continue;

            bool atWar = Wars.Any(w => w.Involves(c.Tag));
            bool lowStab = c.Stability < 45;
            FocusNode? pick = null;

            if (lowStab)
                pick = available.FirstOrDefault(n => n.Effects.Any(e => e.Type == FocusEffectType.AddStability));
            if (atWar)
                pick ??= available.FirstOrDefault(n => n.Effects.Any(e =>
                    e.Type is FocusEffectType.CreateUnit or FocusEffectType.AddWarSupport or FocusEffectType.AddManpower));
            pick ??= available.FirstOrDefault(n => n.Effects.Any(e =>
                e.Type is FocusEffectType.AddStability or FocusEffectType.AddManpower or FocusEffectType.AddWarSupport));
            pick ??= available[_rng.Next(available.Count)];
            StartFocus(c.Tag, pick.Id);
        }
    }
}
