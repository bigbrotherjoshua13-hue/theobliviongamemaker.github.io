using HoiSharp.Core.Data;

namespace HoiSharp.Core.Sim;

/// <summary>A* over the province adjacency graph (land and strait edges only).</summary>
public static class Pathfinder
{
    public static double TerrainCost(string terrain) => terrain switch
    {
        "mountain" => 2.2,
        "marsh" => 2.0,
        "jungle" => 1.8,
        "hills" => 1.5,
        "forest" => 1.4,
        "desert" => 1.3,
        _ => 1.0,
    };

    /// <summary>
    /// Returns the provinces to walk through, excluding the start and including the target.
    /// Returns null when the target cannot be reached. canEnter decides which provinces are allowed.
    /// </summary>
    public static List<int>? FindPath(MapData map, int from, int to, Func<Province, bool> canEnter)
    {
        if (from == to) return new List<int>();
        var provinces = map.Provinces;
        if (from <= 0 || to <= 0 || from >= provinces.Length || to >= provinces.Length) return null;
        if (!provinces[to].IsLand || !canEnter(provinces[to])) return null;

        var gScore = new Dictionary<int, double> { [from] = 0 };
        var cameFrom = new Dictionary<int, int>();
        var open = new PriorityQueue<int, double>();
        open.Enqueue(from, 0);
        var closed = new HashSet<int>();

        var target = provinces[to];
        double Heuristic(Province p)
        {
            double dx = p.CenterX - target.CenterX, dy = p.CenterY - target.CenterY;
            return Math.Sqrt(dx * dx + dy * dy) / 200.0; // never over-estimates for typical province sizes
        }

        while (open.TryDequeue(out int current, out _))
        {
            if (current == to) return Reconstruct(cameFrom, current, from);
            if (!closed.Add(current)) continue;

            foreach (var e in provinces[current].Edges)
            {
                if (e.Kind != EdgeKind.Land && e.Kind != EdgeKind.Strait) continue;
                var next = provinces[e.To];
                if (!next.IsLand || closed.Contains(next.Id)) continue;
                if (next.Id != to && !canEnter(next)) continue;

                double step = TerrainCost(next.Terrain) + (e.Kind == EdgeKind.Strait ? 2.5 : 0.0);
                double tentative = gScore[current] + step;
                if (gScore.TryGetValue(next.Id, out double old) && tentative >= old) continue;

                gScore[next.Id] = tentative;
                cameFrom[next.Id] = current;
                open.Enqueue(next.Id, tentative + Heuristic(next));
            }
        }
        return null;
    }

    /// <summary>Breadth-first search for the nearest province that satisfies goal. Returns the path or null.</summary>
    public static List<int>? FindNearest(MapData map, int from, Func<Province, bool> canEnter, Func<Province, bool> goal, int maxDepth = 80)
    {
        var provinces = map.Provinces;
        var cameFrom = new Dictionary<int, int>();
        var queue = new Queue<(int id, int depth)>();
        queue.Enqueue((from, 0));
        cameFrom[from] = -1;

        while (queue.Count > 0)
        {
            var (cur, depth) = queue.Dequeue();
            if (depth >= maxDepth) continue;
            foreach (var e in provinces[cur].Edges)
            {
                if (e.Kind != EdgeKind.Land && e.Kind != EdgeKind.Strait) continue;
                if (cameFrom.ContainsKey(e.To)) continue;
                var p = provinces[e.To];
                if (!p.IsLand || !canEnter(p)) continue;
                cameFrom[e.To] = cur;
                if (goal(p)) return Reconstruct(cameFrom, e.To, from);
                queue.Enqueue((e.To, depth + 1));
            }
        }
        return null;
    }

    private static List<int> Reconstruct(Dictionary<int, int> cameFrom, int end, int start)
    {
        var path = new List<int>();
        int cur = end;
        while (cur != start && cameFrom.TryGetValue(cur, out int prev))
        {
            path.Add(cur);
            cur = prev;
        }
        path.Reverse();
        return path;
    }
}
