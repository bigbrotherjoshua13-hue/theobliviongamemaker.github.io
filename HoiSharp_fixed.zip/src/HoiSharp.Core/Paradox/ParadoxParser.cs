using System.Globalization;

namespace HoiSharp.Core.Paradox;

/// <summary>
/// One node of a Paradox-style script tree (the format HOI4 uses for states, countries,
/// descriptor.mod, ...). Three shapes exist:
///   key = value          -> Key + Value
///   key = { ... }        -> Key + Children (IsBlock)
///   value                -> bare scalar inside a block (Key == null), e.g. the ids in provinces = { 1 2 3 }
/// </summary>
public sealed class PNode
{
    public string? Key { get; }
    public string? Value { get; }
    public bool IsBlock { get; }
    public List<PNode> Children { get; } = new();

    public PNode(string? key, string? value, bool isBlock)
    {
        Key = key;
        Value = value;
        IsBlock = isBlock;
    }

    public PNode? Child(string key) =>
        Children.FirstOrDefault(c => string.Equals(c.Key, key, StringComparison.OrdinalIgnoreCase));

    public IEnumerable<PNode> ChildrenNamed(string key) =>
        Children.Where(c => string.Equals(c.Key, key, StringComparison.OrdinalIgnoreCase));

    public string? Str(string key) => Child(key)?.Value;

    public int Int(string key, int fallback = 0) =>
        int.TryParse(Str(key), NumberStyles.Integer, CultureInfo.InvariantCulture, out var v) ? v : fallback;

    public long Long(string key, long fallback = 0) =>
        long.TryParse(Str(key), NumberStyles.Integer, CultureInfo.InvariantCulture, out var v) ? v : fallback;

    public double Double(string key, double fallback = 0) =>
        double.TryParse(Str(key), NumberStyles.Float, CultureInfo.InvariantCulture, out var v) ? v : fallback;

    /// <summary>All bare scalar values of this block, in order.</summary>
    public IEnumerable<string> Scalars() =>
        Children.Where(c => c.Key == null && !c.IsBlock && c.Value != null).Select(c => c.Value!);

    public IEnumerable<int> Ints() =>
        Scalars().Select(s => int.TryParse(s, NumberStyles.Integer, CultureInfo.InvariantCulture, out var v) ? v : int.MinValue)
                 .Where(v => v != int.MinValue);
}

/// <summary>Small tolerant parser for the Paradox script format (comments with #, quoted strings, braces).</summary>
public static class ParadoxParser
{
    private enum TokType { Word, Str, Open, Close, Eq }

    private readonly record struct Tok(TokType Type, string Text);

    public static PNode ParseFile(string path) => Parse(File.ReadAllText(path));

    public static PNode Parse(string text)
    {
        var toks = Tokenize(text);
        int i = 0;
        var root = new PNode(null, null, true);
        ParseBlock(toks, ref i, root, topLevel: true);
        return root;
    }

    private static void ParseBlock(List<Tok> toks, ref int i, PNode into, bool topLevel)
    {
        while (i < toks.Count)
        {
            var t = toks[i];

            if (t.Type == TokType.Close)
            {
                i++;
                if (!topLevel) return;
                continue; // stray '}' at top level is ignored
            }

            if (t.Type == TokType.Eq)
            {
                i++;
                continue;
            }

            if (t.Type == TokType.Open)
            {
                i++;
                var anon = new PNode(null, null, true);
                ParseBlock(toks, ref i, anon, topLevel: false);
                into.Children.Add(anon);
                continue;
            }

            // word or quoted string
            i++;
            if (i < toks.Count && toks[i].Type == TokType.Eq)
            {
                i++;
                if (i < toks.Count && toks[i].Type == TokType.Open)
                {
                    i++;
                    var block = new PNode(t.Text, null, true);
                    ParseBlock(toks, ref i, block, topLevel: false);
                    into.Children.Add(block);
                }
                else if (i < toks.Count && (toks[i].Type == TokType.Word || toks[i].Type == TokType.Str))
                {
                    into.Children.Add(new PNode(t.Text, toks[i].Text, false));
                    i++;
                }
                else
                {
                    into.Children.Add(new PNode(t.Text, "", false));
                }
            }
            else
            {
                into.Children.Add(new PNode(null, t.Text, false));
            }
        }
    }

    private static List<Tok> Tokenize(string s)
    {
        var toks = new List<Tok>();
        int i = 0;
        while (i < s.Length)
        {
            char c = s[i];
            if (char.IsWhiteSpace(c) || c == '﻿')
            {
                i++;
            }
            else if (c == '#')
            {
                while (i < s.Length && s[i] != '\n') i++;
            }
            else if (c == '{')
            {
                toks.Add(new Tok(TokType.Open, "{"));
                i++;
            }
            else if (c == '}')
            {
                toks.Add(new Tok(TokType.Close, "}"));
                i++;
            }
            else if (c == '=')
            {
                toks.Add(new Tok(TokType.Eq, "="));
                i++;
            }
            else if (c == '"')
            {
                int start = ++i;
                while (i < s.Length && s[i] != '"') i++;
                toks.Add(new Tok(TokType.Str, s.Substring(start, i - start)));
                if (i < s.Length) i++; // closing quote
            }
            else
            {
                int start = i;
                while (i < s.Length && !char.IsWhiteSpace(s[i]) && s[i] != '{' && s[i] != '}' && s[i] != '=' && s[i] != '#' && s[i] != '"')
                    i++;
                toks.Add(new Tok(TokType.Word, s.Substring(start, i - start)));
            }
        }
        return toks;
    }
}
