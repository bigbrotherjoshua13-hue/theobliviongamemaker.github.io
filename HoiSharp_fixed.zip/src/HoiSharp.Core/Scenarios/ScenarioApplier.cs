using HoiSharp.Core.Data;

namespace HoiSharp.Core.Scenarios;

/// <summary>Applies the map-level parts of a scenario (countries, state owners) to freshly loaded data.</summary>
public static class ScenarioApplier
{
    /// <summary>Returns human-readable warnings for entries that could not be applied.</summary>
    public static List<string> Apply(MapData map, Scenario? scenario)
    {
        var warnings = new List<string>();
        if (scenario == null) return warnings;

        foreach (var def in scenario.Countries.Values)
        {
            var c = map.CountryOf(def.Tag);
            if (c == null)
            {
                if (map.CountryList.Count >= 255)
                {
                    warnings.Add($"Scenario: too many countries, '{def.Tag}' was not added.");
                    continue;
                }
                c = map.AddCountry(def.Tag, def.Name ?? def.Tag, DefaultColor(def.Tag));
            }
            if (def.Name != null) c.Name = def.Name;
            if (def.HasColor) { c.R = def.R; c.G = def.G; c.B = def.B; }
        }

        foreach (var (stateId, tag) in scenario.StateOwners)
        {
            if (!map.States.TryGetValue(stateId, out var state))
            {
                warnings.Add($"Scenario: unknown state {stateId}.");
                continue;
            }
            var owner = map.CountryOf(tag);
            if (owner == null)
            {
                warnings.Add($"Scenario: state {stateId} given to unknown country '{tag}'.");
                continue;
            }
            state.Owner = owner.Tag;
        }
        return warnings;
    }

    /// <summary>Stable colour for a tag (does not depend on string.GetHashCode, which changes per run).</summary>
    public static (byte r, byte g, byte b) DefaultColor(string tag)
    {
        uint h = 2166136261;
        foreach (char ch in tag.ToUpperInvariant())
        {
            h ^= ch;
            h *= 16777619;
        }
        double hue = (h % 360) / 360.0;
        double sat = 0.45 + ((h >> 9) % 30) / 100.0;
        double val = 0.55 + ((h >> 17) % 30) / 100.0;
        return HsvToRgb(hue, sat, val);
    }

    private static (byte r, byte g, byte b) HsvToRgb(double h, double s, double v)
    {
        double hh = (h % 1.0) * 6.0;
        int i = (int)hh;
        double f = hh - i;
        double p = v * (1 - s), q = v * (1 - f * s), t = v * (1 - (1 - f) * s);
        (double r, double g, double b) = i switch
        {
            0 => (v, t, p),
            1 => (q, v, p),
            2 => (p, v, t),
            3 => (p, q, v),
            4 => (t, p, v),
            _ => (v, p, q),
        };
        return ((byte)(r * 255), (byte)(g * 255), (byte)(b * 255));
    }
}
