using HoiSharp.Core.Modding;
using HoiSharp.Core.Paradox;

namespace HoiSharp.Core.Scenarios;

public sealed record ScenarioFile(string Id, string Name, string Path, bool IsUser);

/// <summary>Finds and saves scenario files.</summary>
public static class ScenarioLibrary
{
    /// <summary>Scenarios made in the builder go here, so they show up whatever mods are loaded.</summary>
    public static string UserScenarioDir(string dataRoot) => Path.Combine(dataRoot, "user", "scenarios");

    /// <summary>
    /// All scenarios visible with the given mod stack: scenarios/*.txt of every loaded mod (a later mod's
    /// file with the same name replaces an earlier one), then data/user/scenarios (these win on equal ids).
    /// </summary>
    public static List<ScenarioFile> Discover(ModFileSystem fs, string dataRoot)
    {
        var byId = new Dictionary<string, ScenarioFile>(StringComparer.OrdinalIgnoreCase);
        foreach (var f in fs.ListFilesInLoadOrder("scenarios"))
            Add(byId, f, isUser: false);

        var userDir = UserScenarioDir(dataRoot);
        if (Directory.Exists(userDir))
            foreach (var f in Directory.GetFiles(userDir, "*.txt").OrderBy(p => p, StringComparer.OrdinalIgnoreCase))
                Add(byId, f, isUser: true);

        return byId.Values.OrderBy(s => s.Name, StringComparer.OrdinalIgnoreCase).ToList();
    }

    private static void Add(Dictionary<string, ScenarioFile> byId, string path, bool isUser)
    {
        var id = Path.GetFileNameWithoutExtension(path);
        var name = id;
        try
        {
            name = ParadoxParser.ParseFile(path).Child("scenario")?.Str("name") ?? id;
        }
        catch (IOException) { }
        byId[id] = new ScenarioFile(id, name, path, isUser);
    }

    public static ScenarioFile? Find(ModFileSystem fs, string dataRoot, string idOrName) =>
        Discover(fs, dataRoot).FirstOrDefault(s =>
            string.Equals(s.Id, idOrName, StringComparison.OrdinalIgnoreCase) ||
            string.Equals(s.Name, idOrName, StringComparison.OrdinalIgnoreCase));

    /// <summary>"Eastern Front '39!" -> "eastern_front_39"</summary>
    public static string MakeId(string name)
    {
        var chars = new List<char>();
        foreach (char ch in name.Trim().ToLowerInvariant())
        {
            if (ch is >= 'a' and <= 'z' or >= '0' and <= '9') chars.Add(ch);
            else if (chars.Count > 0 && chars[^1] != '_') chars.Add('_');
        }
        var id = new string(chars.ToArray()).Trim('_');
        if (id.Length > 40) id = id[..40].Trim('_');
        return id.Length == 0 ? "scenario" : id;
    }

    /// <summary>Writes the scenario to data/user/scenarios/&lt;id&gt;.txt and returns the path.</summary>
    public static string Save(Scenario scenario, string dataRoot)
    {
        if (string.IsNullOrEmpty(scenario.Id)) scenario.Id = MakeId(scenario.Name);
        var path = Path.Combine(UserScenarioDir(dataRoot), scenario.Id + ".txt");
        scenario.Save(path);
        return path;
    }
}
