using System.Globalization;
using System.Text;
using HoiSharp.Core.Paradox;

namespace HoiSharp.Core.Scenarios;

/// <summary>A country that a scenario adds or changes (name and/or colour).</summary>
public sealed class CountryDef
{
    public string Tag = "";
    public string? Name;
    public bool HasColor;
    public byte R, G, B;
}

public sealed record ArmyDef(string Tag, int Province, double Strength);

public sealed record WarDef(string Attacker, string Defender);

/// <summary>
/// A starting situation: date, player, who owns which states, new or renamed countries, wars and armies.
/// Only the differences from the base data are stored. Files live in scenarios/*.txt of any loaded mod
/// (or data/user/scenarios for scenarios made in the builder) and look like this:
///
///   scenario = {
///       name = "Eastern Front 1939"
///       description = "..."
///       start_date = 1939.9.1
///       player = DEU
///       clear_default_armies = no
///       country = { tag = XYZ name = "Xyzland" color = { 10 120 200 } }
///       owner   = { state = 12 tag = DEU }
///       war     = { attacker = DEU defender = POL }
///       army    = { tag = DEU province = 123 strength = 100 }
///   }
/// </summary>
public sealed class Scenario
{
    public string Id = "";
    public string Name = "Unnamed scenario";
    public string Description = "";
    public DateTime? StartDate;
    public string? Player;

    /// <summary>When true only the armies listed here exist at the start (no automatic armies).</summary>
    public bool ClearDefaultArmies;

    public Dictionary<string, CountryDef> Countries { get; } = new(StringComparer.OrdinalIgnoreCase);
    public Dictionary<int, string> StateOwners { get; } = new();
    public List<WarDef> Wars { get; } = new();
    public List<ArmyDef> Armies { get; } = new();

    // ------------------------------------------------------------------ load
    public static Scenario Load(string path)
    {
        var root = ParadoxParser.ParseFile(path);
        var n = root.Child("scenario")
                ?? throw new InvalidDataException($"{Path.GetFileName(path)}: expected a 'scenario = {{ ... }}' block");

        var id = Path.GetFileNameWithoutExtension(path);
        var s = new Scenario
        {
            Id = id,
            Name = n.Str("name") ?? id,
            Description = n.Str("description") ?? "",
            Player = n.Str("player")?.ToUpperInvariant(),
            ClearDefaultArmies = IsYes(n.Str("clear_default_armies")),
        };
        if (n.Str("start_date") is { } sd) s.StartDate = ParseDate(sd);

        foreach (var c in n.ChildrenNamed("country"))
        {
            var tag = c.Str("tag")?.ToUpperInvariant();
            if (string.IsNullOrEmpty(tag)) continue;
            var def = new CountryDef { Tag = tag, Name = c.Str("name") };
            if (c.Child("color") is { } col)
            {
                var v = col.Ints().ToList();
                if (v.Count >= 3)
                {
                    def.HasColor = true;
                    def.R = (byte)Math.Clamp(v[0], 0, 255);
                    def.G = (byte)Math.Clamp(v[1], 0, 255);
                    def.B = (byte)Math.Clamp(v[2], 0, 255);
                }
            }
            s.Countries[tag] = def;
        }

        foreach (var o in n.ChildrenNamed("owner"))
        {
            int state = o.Int("state");
            var tag = o.Str("tag")?.ToUpperInvariant();
            if (state > 0 && !string.IsNullOrEmpty(tag)) s.StateOwners[state] = tag;
        }

        foreach (var w in n.ChildrenNamed("war"))
        {
            var a = w.Str("attacker")?.ToUpperInvariant();
            var d = w.Str("defender")?.ToUpperInvariant();
            if (!string.IsNullOrEmpty(a) && !string.IsNullOrEmpty(d)) s.Wars.Add(new WarDef(a, d));
        }

        foreach (var a in n.ChildrenNamed("army"))
        {
            var tag = a.Str("tag")?.ToUpperInvariant();
            int province = a.Int("province");
            if (string.IsNullOrEmpty(tag) || province <= 0) continue;
            s.Armies.Add(new ArmyDef(tag, province, a.Double("strength", 100)));
        }
        return s;
    }

    private static bool IsYes(string? v) =>
        v != null && (v.Equals("yes", StringComparison.OrdinalIgnoreCase) || v.Equals("true", StringComparison.OrdinalIgnoreCase));

    /// <summary>Accepts 1936.1.1, 1936-01-01 and 1936/1/1.</summary>
    public static DateTime? ParseDate(string text)
    {
        var parts = text.Split('.', '-', '/');
        if (parts.Length != 3) return null;
        if (!int.TryParse(parts[0], NumberStyles.Integer, CultureInfo.InvariantCulture, out int y)) return null;
        if (!int.TryParse(parts[1], NumberStyles.Integer, CultureInfo.InvariantCulture, out int m)) return null;
        if (!int.TryParse(parts[2], NumberStyles.Integer, CultureInfo.InvariantCulture, out int d)) return null;
        try { return new DateTime(y, m, d); }
        catch (ArgumentOutOfRangeException) { return null; }
    }

    // ------------------------------------------------------------------ save
    public void Save(string path)
    {
        var inv = CultureInfo.InvariantCulture;
        var sb = new StringBuilder();
        sb.Append("scenario = {\n");
        sb.Append("\tname = \"").Append(Clean(Name)).Append("\"\n");
        sb.Append("\tdescription = \"").Append(Clean(Description)).Append("\"\n");
        if (StartDate is { } d)
            sb.Append("\tstart_date = ").Append(d.Year.ToString(inv)).Append('.').Append(d.Month.ToString(inv)).Append('.').Append(d.Day.ToString(inv)).Append('\n');
        if (!string.IsNullOrEmpty(Player)) sb.Append("\tplayer = ").Append(Player).Append('\n');
        sb.Append("\tclear_default_armies = ").Append(ClearDefaultArmies ? "yes" : "no").Append('\n');

        foreach (var c in Countries.Values.OrderBy(c => c.Tag, StringComparer.Ordinal))
        {
            sb.Append("\tcountry = { tag = ").Append(c.Tag);
            if (c.Name != null) sb.Append(" name = \"").Append(Clean(c.Name)).Append('"');
            if (c.HasColor) sb.Append(" color = { ").Append(c.R.ToString(inv)).Append(' ').Append(c.G.ToString(inv)).Append(' ').Append(c.B.ToString(inv)).Append(" }");
            sb.Append(" }\n");
        }
        foreach (var kv in StateOwners.OrderBy(k => k.Key))
            sb.Append("\towner = { state = ").Append(kv.Key.ToString(inv)).Append(" tag = ").Append(kv.Value).Append(" }\n");
        foreach (var w in Wars)
            sb.Append("\twar = { attacker = ").Append(w.Attacker).Append(" defender = ").Append(w.Defender).Append(" }\n");
        foreach (var a in Armies)
            sb.Append("\tarmy = { tag = ").Append(a.Tag).Append(" province = ").Append(a.Province.ToString(inv))
              .Append(" strength = ").Append(a.Strength.ToString("0.#", inv)).Append(" }\n");
        sb.Append("}\n");

        Directory.CreateDirectory(Path.GetDirectoryName(Path.GetFullPath(path))!);
        File.WriteAllText(path, sb.ToString(), new UTF8Encoding(false));
    }

    // the script format has no escape sequences, so quotes and line breaks are replaced
    private static string Clean(string s) => s.Replace('"', '\'').Replace('\r', ' ').Replace('\n', ' ');
}
