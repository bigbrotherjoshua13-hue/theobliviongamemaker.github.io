namespace HoiSharp.Core;

/// <summary>
/// Cross-process gate: the launcher holds a named mutex for its lifetime.
/// The game requires that mutex to exist (launcher still open) or it will refuse to run / exit.
/// </summary>
public static class LauncherGate
{
    public const string MutexName = "HoiSharp.Launcher.Alive.v1";
    public const string BypassEnv = "HOISHARP_ALLOW_NO_LAUNCHER";

    /// <summary>Call from the launcher process; keeps the mutex until Dispose / process exit.</summary>
    public static IDisposable Acquire()
    {
        var m = new Mutex(initiallyOwned: false, MutexName);
        m.WaitOne();
        return new Holder(m);
    }

    /// <summary>True if a launcher instance is currently holding the gate.</summary>
    public static bool IsLauncherAlive()
    {
        try
        {
            // If we can open the named mutex, the launcher (or its process) still has it registered.
            if (Mutex.TryOpenExisting(MutexName, out var m))
            {
                m.Dispose();
                return true;
            }
        }
        catch (AbandonedMutexException)
        {
            return false;
        }
        catch (WaitHandleCannotBeOpenedException)
        {
            return false;
        }
        catch
        {
            return false;
        }
        return false;
    }

    /// <summary>Env var bypass for CI / packaging tools: HOISHARP_ALLOW_NO_LAUNCHER=1</summary>
    public static bool AllowBypass()
    {
        string? v = Environment.GetEnvironmentVariable(BypassEnv);
        return string.Equals(v, "1", StringComparison.OrdinalIgnoreCase)
            || string.Equals(v, "true", StringComparison.OrdinalIgnoreCase);
    }

    private sealed class Holder : IDisposable
    {
        private Mutex? _m;
        public Holder(Mutex m) => _m = m;
        public void Dispose()
        {
            try { _m?.ReleaseMutex(); } catch { }
            try { _m?.Dispose(); } catch { }
            _m = null;
        }
    }
}
