using System.Globalization;
using System.Text;
using System.Text.RegularExpressions;
using HoiSharp.Core.Paradox;

namespace HoiSharp.Core.Import;

/// <summary>
/// Full import of a Hearts of Iron IV map folder (or whole game install) into a HoiSharp mod.
/// Produces: map/definition.csv, provinces.bmp, adjacency_graph.csv, default.map,
/// history/states, common/countries, localisation snippets.
/// </summary>
public static class Hoi4Importer
{
    public const string DefaultModId = "hoi4_import";

    public sealed class Result
    {
        public string ModPath = "";
        public int Provinces;
        public int States;
        public int Countries;
        public int Edges;
        public int Width;
        public int Height;
        public string Message = "";
    }

    /// <summary>
    /// Resolve either a HOI4 game root or a path that points at the map/ folder.
    /// Returns (gameRoot, mapDir).
    /// </summary>
    public static (string gameRoot, string mapDir) ResolveRoots(string path)
    {
        path = Path.GetFullPath(path.Trim().Trim('"'));
        if (!Directory.Exists(path))
            throw new DirectoryNotFoundException("Path not found: " + path);

        // User selected the map folder itself
        if (File.Exists(Path.Combine(path, "definition.csv")) ||
            File.Exists(Path.Combine(path, "provinces.bmp")) ||
            File.Exists(Path.Combine(path, "provinces.png")))
        {
            string parent = Directory.GetParent(path)?.FullName ?? path;
            return (parent, path);
        }

        // User selected game root
        string map = Path.Combine(path, "map");
        if (Directory.Exists(map))
            return (path, map);

        throw new DirectoryNotFoundException(
            "Could not find HOI4 map data. Point at the game folder or its map/ subfolder.");
    }

    public static Result Import(string hoi4Path, string dataRoot, string modId = DefaultModId, Action<string>? progress = null)
    {
        var (gameRoot, mapDir) = ResolveRoots(hoi4Path);
        progress?.Invoke($"Source map: {mapDir}");
        progress?.Invoke($"Game root:  {gameRoot}");

        string defSrc = Path.Combine(mapDir, "definition.csv");
        if (!File.Exists(defSrc))
            throw new FileNotFoundException("map/definition.csv not found.", defSrc);

        string modPath = Path.Combine(dataRoot, "mods", modId);
        progress?.Invoke("Preparing mod folder...");
        if (Directory.Exists(modPath))
            Directory.Delete(modPath, recursive: true);
        Directory.CreateDirectory(modPath);

        File.WriteAllText(Path.Combine(modPath, "descriptor.mod"),
            "name = \"HOI4 Import\"\n" +
            $"path = \"mod/{modId}\"\n" +
            "supported_version = \"*\"\n" +
            "replace_path = \"map\"\n" +
            "replace_path = \"history/states\"\n" +
            "replace_path = \"common/countries\"\n");

        string mapOut = Path.Combine(modPath, "map");
        Directory.CreateDirectory(mapOut);

        // ---------- definition.csv ----------
        progress?.Invoke("Reading definition.csv...");
        var colorToId = new Dictionary<int, int>();
        int maxId = 0;
        var landIds = new HashSet<int>();
        var seaIds = new HashSet<int>();
        var lakeIds = new HashSet<int>();
        var defLines = new List<string>();

        foreach (var raw in File.ReadLines(defSrc))
        {
            var line = raw.Trim();
            if (line.Length == 0) continue;
            var parts = line.Split(';');
            if (parts.Length < 5) continue;
            if (!int.TryParse(parts[0].Trim(), NumberStyles.Integer, CultureInfo.InvariantCulture, out int id))
                continue;

            // Normalize: id;r;g;b;type;coastal;terrain;continent
            byte r = ParseByte(parts, 1);
            byte g = ParseByte(parts, 2);
            byte b = ParseByte(parts, 3);
            string type = parts[4].Trim().ToLowerInvariant();
            if (type is not ("land" or "sea" or "lake")) type = "land";
            string coastal = parts.Length > 5 ? parts[5].Trim().ToLowerInvariant() : "false";
            if (coastal is not ("true" or "false")) coastal = "false";
            string terrain = parts.Length > 6 ? parts[6].Trim() : "plains";
            string continent = parts.Length > 7 ? parts[7].Trim() : "0";

            defLines.Add(string.Join(';', id, r, g, b, type, coastal, terrain, continent));
            if (id == 0) continue;

            colorToId[(r << 16) | (g << 8) | b] = id;
            maxId = Math.Max(maxId, id);
            if (type == "sea") seaIds.Add(id);
            else if (type == "lake") lakeIds.Add(id);
            else landIds.Add(id);
        }

        // ensure province 0 row exists
        if (defLines.Count == 0 || !defLines[0].StartsWith("0;"))
            defLines.Insert(0, "0;0;0;0;land;false;unknown;0");

        File.WriteAllLines(Path.Combine(mapOut, "definition.csv"), defLines);
        progress?.Invoke($"Provinces defined: {maxId} (land {landIds.Count}, sea {seaIds.Count}, lake {lakeIds.Count})");

        // ---------- provinces bitmap ----------
        progress?.Invoke("Loading province bitmap...");
        int width, height;
        byte[] rgb;
        string bmpPath = Path.Combine(mapDir, "provinces.bmp");
        string pngPath = Path.Combine(mapDir, "provinces.png");

        if (File.Exists(bmpPath))
        {
            var img = BmpReader.Load(bmpPath);
            width = img.Width;
            height = img.Height;
            rgb = img.Rgb;
            progress?.Invoke($"Loaded provinces.bmp ({width}x{height})");
        }
        else if (File.Exists(pngPath))
        {
            // Copy PNG for the game; adjacency requires decode — try via temporary note
            File.Copy(pngPath, Path.Combine(mapOut, "provinces.png"), overwrite: true);
            width = 5632;
            height = 2048;
            rgb = Array.Empty<byte>();
            progress?.Invoke("Found provinces.png only — adjacency graph will be empty until a .bmp is available.");
            progress?.Invoke("Tip: HOI4 ships provinces.bmp in map/. Point the importer at the full game folder.");
        }
        else
            throw new FileNotFoundException("Neither provinces.bmp nor provinces.png found in map/.");

        if (rgb.Length > 0)
        {
            progress?.Invoke("Writing provinces.bmp for HoiSharp...");
            BmpReader.SaveBmp24(Path.Combine(mapOut, "provinces.bmp"), width, height, rgb);
        }
        else if (File.Exists(bmpPath))
        {
            File.Copy(bmpPath, Path.Combine(mapOut, "provinces.bmp"), overwrite: true);
        }

        // ---------- default.map ----------
        File.WriteAllText(Path.Combine(mapOut, "default.map"),
            $"width = {width}\nheight = {height}\nlat_max = 83.0\nlat_min = -57.0\n" +
            $"max_provinces = {maxId}\nland_provinces = {landIds.Count}\nsea_provinces = {seaIds.Count}\n");

        // ---------- adjacency from bitmap ----------
        int edgeCount = 0;
        var edgeMap = new Dictionary<long, (int pixels, string kind)>();
        if (rgb.Length > 0)
        {
            progress?.Invoke("Building adjacency graph (full scan)...");
            edgeCount = BuildAdjacency(rgb, width, height, colorToId, landIds, seaIds, lakeIds, edgeMap, progress);
        }

        // Merge HOI4 special adjacencies (straits, impassable, etc.)
        string adjCsv = Path.Combine(mapDir, "adjacencies.csv");
        if (File.Exists(adjCsv))
        {
            progress?.Invoke("Merging map/adjacencies.csv (straits)...");
            edgeCount += MergeHoi4Adjacencies(adjCsv, edgeMap, maxId);
        }

        WriteAdjacencyCsv(Path.Combine(mapOut, "adjacency_graph.csv"), edgeMap);
        progress?.Invoke($"Adjacency edges: {edgeMap.Count}");

        // ---------- continent.txt (optional) ----------
        string contSrc = Path.Combine(mapDir, "continent.txt");
        if (File.Exists(contSrc))
            File.Copy(contSrc, Path.Combine(mapOut, "continent.txt"), overwrite: true);
        else
            File.WriteAllText(Path.Combine(mapOut, "continent.txt"),
                "continents = {\n\t\"Europe\"\n\t\"Asia\"\n\t\"Africa\"\n\t\"North America\"\n\t\"South America\"\n\t\"Oceania\"\n\t\"Australia\"\n}\n");

        // heightmap if present
        TryCopy(Path.Combine(mapDir, "heightmap.bmp"), Path.Combine(mapOut, "heightmap.bmp"));
        TryCopy(Path.Combine(mapDir, "heightmap.png"), Path.Combine(mapOut, "heightmap.png"));
        TryCopy(Path.Combine(mapDir, "terrain.bmp"), Path.Combine(mapOut, "terrain.bmp"));

        // ---------- states ----------
        progress?.Invoke("Importing history/states...");
        int stateCount = ImportStates(gameRoot, modPath, progress);

        // ---------- countries ----------
        progress?.Invoke("Importing countries...");
        int countryCount = ImportCountries(gameRoot, modPath, progress);

        // ---------- localisation ----------
        progress?.Invoke("Copying localisation...");
        CopyLocalisation(gameRoot, modPath);

        // remember path for next time
        try
        {
            string userDir = Path.Combine(dataRoot, "user");
            Directory.CreateDirectory(userDir);
            File.WriteAllText(Path.Combine(userDir, "hoi4_path.txt"), gameRoot);
        }
        catch { /* ignore */ }

        var result = new Result
        {
            ModPath = modPath,
            Provinces = maxId,
            States = stateCount,
            Countries = countryCount,
            Edges = edgeMap.Count,
            Width = width,
            Height = height,
            Message =
                $"HOI4 import complete → mod '{modId}'\n" +
                $"  {maxId} provinces, {stateCount} states, {countryCount} countries\n" +
                $"  {edgeMap.Count} adjacencies, map {width}x{height}\n" +
                "Enable \"HOI4 Import\" in the launcher mods list, then Play.",
        };
        File.WriteAllText(Path.Combine(modPath, "IMPORT_README.txt"),
            result.Message + "\n\nSource map: " + mapDir + "\nGame root: " + gameRoot + "\n");
        progress?.Invoke(result.Message);
        return result;
    }

    private static byte ParseByte(string[] parts, int i)
    {
        if (i >= parts.Length) return 0;
        return byte.TryParse(parts[i].Trim(), NumberStyles.Integer, CultureInfo.InvariantCulture, out var v) ? v : (byte)0;
    }

    private static void TryCopy(string src, string dst)
    {
        if (!File.Exists(src)) return;
        Directory.CreateDirectory(Path.GetDirectoryName(dst)!);
        File.Copy(src, dst, overwrite: true);
    }

    // ------------------------------------------------------------------ adjacency
    private static int BuildAdjacency(
        byte[] rgb, int w, int h,
        Dictionary<int, int> colorToId,
        HashSet<int> landIds, HashSet<int> seaIds, HashSet<int> lakeIds,
        Dictionary<long, (int pixels, string kind)> edges,
        Action<string>? progress)
    {
        int IdAt(int x, int y)
        {
            int i = (y * w + x) * 3;
            int key = (rgb[i] << 16) | (rgb[i + 1] << 8) | rgb[i + 2];
            return colorToId.TryGetValue(key, out int id) ? id : 0;
        }

        void Touch(int a, int b)
        {
            if (a <= 0 || b <= 0 || a == b) return;
            int lo = Math.Min(a, b), hi = Math.Max(a, b);
            long key = ((long)lo << 32) | (uint)hi;
            bool aLand = landIds.Contains(a);
            bool bLand = landIds.Contains(b);
            // lakes treated like sea for movement
            if (!aLand) aLand = false;
            if (!bLand) bLand = false;
            string kind = aLand && bLand ? "land" : (!aLand && !bLand ? "sea" : "coast");
            if (edges.TryGetValue(key, out var cur))
                edges[key] = (cur.pixels + 1, cur.kind);
            else
                edges[key] = (1, kind);
        }

        for (int y = 0; y < h; y++)
        {
            if (y % 200 == 0) progress?.Invoke($"Adjacency scan {y * 100 / h}%...");
            for (int x = 0; x < w; x++)
            {
                int id = IdAt(x, y);
                if (id == 0) continue;
                if (x + 1 < w) Touch(id, IdAt(x + 1, y));
                if (y + 1 < h) Touch(id, IdAt(x, y + 1));
            }
        }
        return edges.Count;
    }

    /// <summary>
    /// HOI4 adjacencies.csv columns (semicolon):
    /// From;To;Type;Through;start_x;start_y;stop_x;stop_y;adjacency_rule_name;Comment
    /// Type: sea, river, large_river, impassable, ...
    /// </summary>
    private static int MergeHoi4Adjacencies(string path, Dictionary<long, (int pixels, string kind)> edges, int maxId)
    {
        int added = 0;
        bool header = true;
        foreach (var raw in File.ReadLines(path))
        {
            var line = raw.Trim();
            if (line.Length == 0 || line.StartsWith('#')) continue;
            if (header) { header = false; continue; }
            var parts = line.Split(';');
            if (parts.Length < 3) continue;
            if (!int.TryParse(parts[0].Trim(), out int a)) continue;
            if (!int.TryParse(parts[1].Trim(), out int b)) continue;
            if (a <= 0 || b <= 0 || a > maxId || b > maxId || a == b) continue;

            string type = parts[2].Trim().ToLowerInvariant();
            // skip impassable
            if (type.Contains("impassable")) continue;

            string kind = type switch
            {
                "sea" => "strait",
                "river" or "large_river" => "land",
                _ => "strait",
            };

            int lo = Math.Min(a, b), hi = Math.Max(a, b);
            long key = ((long)lo << 32) | (uint)hi;
            if (!edges.ContainsKey(key))
            {
                edges[key] = (1, kind);
                added++;
            }
        }
        return added;
    }

    private static void WriteAdjacencyCsv(string path, Dictionary<long, (int pixels, string kind)> edges)
    {
        var sb = new StringBuilder(edges.Count * 24);
        sb.AppendLine("from;to;pixels;kind");
        foreach (var kv in edges)
        {
            int lo = (int)(kv.Key >> 32);
            int hi = (int)(kv.Key & 0xFFFFFFFF);
            sb.Append(lo).Append(';').Append(hi).Append(';')
              .Append(kv.Value.pixels).Append(';').Append(kv.Value.kind).Append('\n');
        }
        File.WriteAllText(path, sb.ToString());
    }

    // ------------------------------------------------------------------ states
    private static int ImportStates(string gameRoot, string modPath, Action<string>? progress)
    {
        string srcDir = Path.Combine(gameRoot, "history", "states");
        string dstDir = Path.Combine(modPath, "history", "states");
        Directory.CreateDirectory(dstDir);

        if (!Directory.Exists(srcDir))
        {
            progress?.Invoke("Warning: history/states not found — map will load but states may be empty.");
            return 0;
        }

        int n = 0;
        foreach (var file in Directory.GetFiles(srcDir, "*.txt"))
        {
            try
            {
                string text = File.ReadAllText(file);
                // Normalize: ensure owner is on history root if only present in date blocks
                text = NormalizeStateOwner(text);
                // Extract buildings into a simple comment our loader can also use
                string name = Path.GetFileName(file);
                File.WriteAllText(Path.Combine(dstDir, name), text);
                n++;
            }
            catch
            {
                // still copy raw
                try { File.Copy(file, Path.Combine(dstDir, Path.GetFileName(file)), true); n++; } catch { }
            }
        }
        progress?.Invoke($"States copied: {n}");
        return n;
    }

    /// <summary>
    /// HOI4 often puts the starting owner only as owner = X under history={}.
    /// If missing, pull the earliest date-block owner so MapData can read it.
    /// </summary>
    private static string NormalizeStateOwner(string text)
    {
        // Fast path: already has owner under history
        if (Regex.IsMatch(text, @"history\s*=\s*\{[^}]*\bowner\s*=", RegexOptions.IgnoreCase | RegexOptions.Singleline))
            return text;

        var m = Regex.Match(text, @"\bowner\s*=\s*([A-Za-z0-9_]{1,4})", RegexOptions.IgnoreCase);
        if (!m.Success) return text;

        string owner = m.Groups[1].Value.ToUpperInvariant();
        // inject owner into history block
        return Regex.Replace(text, @"history\s*=\s*\{",
            "history = {\n\t\towner = " + owner,
            RegexOptions.IgnoreCase, TimeSpan.FromSeconds(1));
    }

    // ------------------------------------------------------------------ countries
    private static int ImportCountries(string gameRoot, string modPath, Action<string>? progress)
    {
        var tags = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase);

        // common/country_tags/*.txt
        string tagsDir = Path.Combine(gameRoot, "common", "country_tags");
        if (Directory.Exists(tagsDir))
        {
            var rx = new Regex(@"^\s*([A-Z0-9]{1,4})\s*=\s*""([^""]+)""", RegexOptions.IgnoreCase);
            foreach (var file in Directory.GetFiles(tagsDir, "*.txt"))
            {
                foreach (var line in File.ReadLines(file))
                {
                    var m = rx.Match(line);
                    if (m.Success)
                        tags[m.Groups[1].Value.ToUpperInvariant()] =
                            m.Groups[2].Value.Replace('/', Path.DirectorySeparatorChar);
                }
            }
        }

        // colours
        var colors = new Dictionary<string, (byte r, byte g, byte b)>(StringComparer.OrdinalIgnoreCase);
        string colorsPath = Path.Combine(gameRoot, "common", "countries", "colors.txt");
        if (File.Exists(colorsPath))
        {
            try
            {
                // Regex fallback — colours.txt is huge and sometimes odd for the full parser
                var rx = new Regex(
                    @"([A-Z0-9]{1,4})\s*=\s*\{\s*(?:color\s*=\s*\{)?\s*(\d+)\s+(\d+)\s+(\d+)",
                    RegexOptions.IgnoreCase);
                foreach (var line in File.ReadLines(colorsPath))
                {
                    var m = rx.Match(line);
                    if (m.Success)
                    {
                        colors[m.Groups[1].Value.ToUpperInvariant()] = (
                            (byte)Math.Clamp(int.Parse(m.Groups[2].Value), 0, 255),
                            (byte)Math.Clamp(int.Parse(m.Groups[3].Value), 0, 255),
                            (byte)Math.Clamp(int.Parse(m.Groups[4].Value), 0, 255));
                    }
                }
            }
            catch { /* ignore */ }
        }

        // capitals from history/countries
        var capitals = new Dictionary<string, int>(StringComparer.OrdinalIgnoreCase);
        string histDir = Path.Combine(gameRoot, "history", "countries");
        if (Directory.Exists(histDir))
        {
            foreach (var file in Directory.GetFiles(histDir, "*.txt"))
            {
                string fname = Path.GetFileName(file);
                // "TAG - Name.txt" or "TAG.txt"
                string tag = fname.Length >= 3 ? fname[..3].ToUpperInvariant() : "";
                if (tag.Length != 3 || !char.IsLetter(tag[0])) continue;
                try
                {
                    foreach (var line in File.ReadLines(file))
                    {
                        var t = line.Trim();
                        if (t.StartsWith("capital", StringComparison.OrdinalIgnoreCase))
                        {
                            var parts = t.Split('=');
                            if (parts.Length >= 2 && int.TryParse(parts[1].Trim().Split('#')[0].Trim(), out int cap))
                            {
                                capitals[tag] = cap;
                                break;
                            }
                        }
                    }
                }
                catch { }
            }
        }

        // harvest owners from imported states if tags empty
        if (tags.Count == 0)
        {
            string statesDir = Path.Combine(modPath, "history", "states");
            if (Directory.Exists(statesDir))
            {
                var rx = new Regex(@"\bowner\s*=\s*([A-Za-z0-9_]{1,4})", RegexOptions.IgnoreCase);
                foreach (var file in Directory.GetFiles(statesDir, "*.txt"))
                {
                    try
                    {
                        var m = rx.Match(File.ReadAllText(file));
                        if (m.Success) tags[m.Groups[1].Value.ToUpperInvariant()] = "";
                    }
                    catch { }
                }
            }
        }

        // also pick up any tags that have colours but weren't in country_tags
        foreach (var t in colors.Keys)
            if (!tags.ContainsKey(t)) tags[t] = "";

        var outDir = Path.Combine(modPath, "common", "countries");
        Directory.CreateDirectory(outDir);
        var sb = new StringBuilder();
        int n = 0;
        foreach (var tag in tags.Keys.OrderBy(t => t, StringComparer.Ordinal))
        {
            var (r, g, b) = colors.TryGetValue(tag, out var col) ? col : HashColor(tag);
            int capital = capitals.TryGetValue(tag, out int c) ? c : 0;
            sb.Append(tag).Append(" = {\n");
            sb.Append("\tname = \"").Append(tag).Append("\"\n");
            sb.Append("\tcolor = { ").Append(r).Append(' ').Append(g).Append(' ').Append(b).Append(" }\n");
            if (capital > 0) sb.Append("\tcapital = ").Append(capital).Append('\n');
            sb.Append("}\n");
            n++;
        }
        File.WriteAllText(Path.Combine(outDir, "countries.txt"), sb.ToString());
        progress?.Invoke($"Countries: {n}");
        return n;
    }

    private static (byte r, byte g, byte b) HashColor(string tag)
    {
        unchecked
        {
            int h = tag.GetHashCode();
            return ((byte)(40 + (h & 0x7F)), (byte)(40 + ((h >> 8) & 0x7F)), (byte)(40 + ((h >> 16) & 0x7F)));
        }
    }

    private static void CopyLocalisation(string gameRoot, string modPath)
    {
        string[] candidates =
        {
            Path.Combine(gameRoot, "localisation", "english"),
            Path.Combine(gameRoot, "localisation"),
        };
        string outDir = Path.Combine(modPath, "localisation", "english");
        Directory.CreateDirectory(outDir);

        string[] patterns = { "*state*", "*province*", "*country*", "*countries*", "*victory*", "*strategic*" };
        foreach (var dir in candidates)
        {
            if (!Directory.Exists(dir)) continue;
            foreach (var pattern in patterns)
            {
                foreach (var file in Directory.GetFiles(dir, pattern + "*.yml"))
                {
                    try { File.Copy(file, Path.Combine(outDir, Path.GetFileName(file)), overwrite: true); }
                    catch { }
                }
            }
            break;
        }
    }
}
