namespace HoiSharp.Core.Import;

/// <summary>
/// Minimal Windows BMP reader (24-bit and 32-bit uncompressed, bottom-up or top-down).
/// Used to load HOI4 map/provinces.bmp without extra image libraries.
/// </summary>
public static class BmpReader
{
    public sealed class BmpImage
    {
        public int Width;
        public int Height;
        /// <summary>Row-major top-to-bottom, R/G/B (alpha ignored).</summary>
        public byte[] Rgb = Array.Empty<byte>(); // length = W*H*3
    }

    public static BmpImage Load(string path)
    {
        using var fs = File.OpenRead(path);
        using var br = new BinaryReader(fs);

        // BITMAPFILEHEADER
        ushort magic = br.ReadUInt16();
        if (magic != 0x4D42) throw new InvalidDataException("Not a BMP file: " + path);
        br.ReadUInt32(); // size
        br.ReadUInt16(); br.ReadUInt16(); // reserved
        uint pixelOffset = br.ReadUInt32();

        // BITMAPINFOHEADER (or larger)
        uint headerSize = br.ReadUInt32();
        int width = br.ReadInt32();
        int height = br.ReadInt32();
        br.ReadUInt16(); // planes
        ushort bpp = br.ReadUInt16();
        uint compression = br.ReadUInt32();
        if (compression != 0)
            throw new InvalidDataException($"Compressed BMP not supported ({compression}): {path}");
        if (bpp is not (24 or 32))
            throw new InvalidDataException($"Only 24/32-bit BMP supported, got {bpp}: {path}");

        bool topDown = height < 0;
        height = Math.Abs(height);
        int absW = Math.Abs(width);

        fs.Seek(pixelOffset, SeekOrigin.Begin);

        int bytesPerPixel = bpp / 8;
        int rowSize = ((absW * bytesPerPixel + 3) / 4) * 4; // padded to 4 bytes
        var row = new byte[rowSize];
        var rgb = new byte[absW * height * 3];

        for (int y = 0; y < height; y++)
        {
            int n = fs.Read(row, 0, rowSize);
            if (n < rowSize) throw new EndOfStreamException("Truncated BMP: " + path);
            int destY = topDown ? y : (height - 1 - y);
            int destOff = destY * absW * 3;
            for (int x = 0; x < absW; x++)
            {
                int src = x * bytesPerPixel;
                // BMP is BGR(A)
                byte b = row[src];
                byte g = row[src + 1];
                byte r = row[src + 2];
                rgb[destOff + x * 3] = r;
                rgb[destOff + x * 3 + 1] = g;
                rgb[destOff + x * 3 + 2] = b;
            }
        }

        return new BmpImage { Width = absW, Height = height, Rgb = rgb };
    }

    /// <summary>
    /// Write a very simple uncompressed 24-bit BMP (so MonoGame / other tools can also open it).
    /// Prefer calling this only when PNG is unavailable.
    /// </summary>
    public static void SaveBmp24(string path, int width, int height, byte[] rgbTopDown)
    {
        int rowSize = ((width * 3 + 3) / 4) * 4;
        int pixelBytes = rowSize * height;
        int fileSize = 14 + 40 + pixelBytes;

        using var fs = File.Create(path);
        using var bw = new BinaryWriter(fs);
        bw.Write((ushort)0x4D42);
        bw.Write(fileSize);
        bw.Write((ushort)0);
        bw.Write((ushort)0);
        bw.Write(14 + 40);
        bw.Write(40);
        bw.Write(width);
        bw.Write(height); // bottom-up
        bw.Write((ushort)1);
        bw.Write((ushort)24);
        bw.Write(0);
        bw.Write(pixelBytes);
        bw.Write(0); bw.Write(0); bw.Write(0); bw.Write(0);

        var row = new byte[rowSize];
        for (int y = height - 1; y >= 0; y--)
        {
            Array.Clear(row);
            int srcOff = y * width * 3;
            for (int x = 0; x < width; x++)
            {
                row[x * 3] = rgbTopDown[srcOff + x * 3 + 2];     // B
                row[x * 3 + 1] = rgbTopDown[srcOff + x * 3 + 1]; // G
                row[x * 3 + 2] = rgbTopDown[srcOff + x * 3];     // R
            }
            bw.Write(row);
        }
    }
}
