namespace HoiSharp.Core.Import;

/// <summary>
/// Locates a Hearts of Iron IV install (Steam or manual path).
/// </summary>
public static class SteamLocator
{
    public const string GameFolderName = "Hearts of Iron IV";

    /// <summary>True if path is a HOI4 game root or its map/ folder.</summary>
    public static bool LooksLikeHoi4(string? path)
    {
        if (string.IsNullOrWhiteSpace(path) || !Directory.Exists(path)) return false;
        if (File.Exists(Path.Combine(path, "map", "definition.csv"))
            || File.Exists(Path.Combine(path, "map", "provinces.bmp"))
            || File.Exists(Path.Combine(path, "map", "provinces.png")))
            return true;
        if (File.Exists(Path.Combine(path, "definition.csv"))
            || File.Exists(Path.Combine(path, "provinces.bmp"))
            || File.Exists(Path.Combine(path, "provinces.png")))
            return true;
        return false;
    }

    /// <summary>Last imported path saved under data/user/hoi4_path.txt.</summary>
    public static string? LoadSavedPath(string dataRoot)
    {
        try
        {
            var p = Path.Combine(dataRoot, "user", "hoi4_path.txt");
            if (!File.Exists(p)) return null;
            var line = File.ReadAllText(p).Trim();
            return LooksLikeHoi4(line) ? line : null;
        }
        catch { return null; }
    }

    /// <summary>Try common Steam library locations on Windows / Linux / macOS.</summary>
    public static string? FindHoi4Install()
    {
        foreach (var root in CandidateSteamRoots())
        {
            var direct = Path.Combine(root, "steamapps", "common", GameFolderName);
            if (LooksLikeHoi4(direct)) return direct;

            var vdf = Path.Combine(root, "steamapps", "libraryfolders.vdf");
            if (!File.Exists(vdf)) continue;
            foreach (var lib in ParseLibraryFolders(vdf))
            {
                var p = Path.Combine(lib, "steamapps", "common", GameFolderName);
                if (LooksLikeHoi4(p)) return p;
            }
        }
        return null;
    }

    private static IEnumerable<string> CandidateSteamRoots()
    {
        // Windows
        string? pf = Environment.GetFolderPath(Environment.SpecialFolder.ProgramFilesX86);
        if (!string.IsNullOrEmpty(pf))
            yield return Path.Combine(pf, "Steam");
        string? pf64 = Environment.GetFolderPath(Environment.SpecialFolder.ProgramFiles);
        if (!string.IsNullOrEmpty(pf64))
            yield return Path.Combine(pf64, "Steam");

        // User-level Windows
        string? local = Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData);
        if (!string.IsNullOrEmpty(local))
            yield return Path.Combine(local, "Steam");

        // Linux
        string home = Environment.GetFolderPath(Environment.SpecialFolder.UserProfile);
        if (!string.IsNullOrEmpty(home))
        {
            yield return Path.Combine(home, ".steam", "steam");
            yield return Path.Combine(home, ".steam", "root");
            yield return Path.Combine(home, ".local", "share", "Steam");
            yield return Path.Combine(home, ".var", "app", "com.valvesoftware.Steam", "data", "Steam");
        }

        // macOS
        if (!string.IsNullOrEmpty(home))
            yield return Path.Combine(home, "Library", "Application Support", "Steam");

        // Env override
        string? env = Environment.GetEnvironmentVariable("STEAM_DIR")
                   ?? Environment.GetEnvironmentVariable("SteamPath");
        if (!string.IsNullOrEmpty(env))
            yield return env;
    }

    /// <summary>Very small VDF scan for path "..." entries under libraryfolders.</summary>
    private static IEnumerable<string> ParseLibraryFolders(string vdfPath)
    {
        foreach (var line in File.ReadLines(vdfPath))
        {
            var t = line.Trim();
            // "path"		"D:\\SteamLibrary"
            if (!t.Contains("path", StringComparison.OrdinalIgnoreCase)) continue;
            int first = t.IndexOf('"');
            if (first < 0) continue;
            int second = t.IndexOf('"', first + 1);
            if (second < 0) continue;
            int third = t.IndexOf('"', second + 1);
            if (third < 0) continue;
            int fourth = t.IndexOf('"', third + 1);
            if (fourth < 0) continue;
            string key = t.Substring(first + 1, second - first - 1);
            if (!key.Equals("path", StringComparison.OrdinalIgnoreCase)) continue;
            string val = t.Substring(third + 1, fourth - third - 1);
            val = val.Replace("\\\\", "\\");
            if (Directory.Exists(val)) yield return val;
        }
    }
}
