using System.Diagnostics;
using System.Runtime.InteropServices;
using System.Text;

namespace HoiSharp.Core.Diagnostics;

/// <summary>Where the application lives and where logs / crash reports / updates go.</summary>
public static class AppPaths
{
    /// <summary>Folder that contains data/mod_base (walks up from the executable), else the executable folder.</summary>
    public static string Root { get; } = FindRoot();
    public static string LogsDir => Path.Combine(Root, "logs");
    public static string CrashesDir => Path.Combine(Root, "crashes");
    public static string UpdatesDir => Path.Combine(Root, "updates");

    private static string FindRoot()
    {
        var dir = new DirectoryInfo(AppContext.BaseDirectory);
        while (dir != null)
        {
            if (Directory.Exists(Path.Combine(dir.FullName, "data", "mod_base"))) return dir.FullName;
            dir = dir.Parent;
        }
        return AppContext.BaseDirectory;
    }
}

/// <summary>
/// File logging into logs/ (one file per run, the newest 20 are kept) and crash reports into crashes/.
/// Never throws: logging must not be the thing that crashes the game.
/// </summary>
public static class AppLog
{
    private const int KeepLogFiles = 20;
    private const int KeepCrashFiles = 50;
    private const int TailLines = 200;

    private static readonly object Gate = new();
    private static readonly Queue<string> Tail = new();
    private static string _app = "app";
    private static string? _file;
    private static bool _hooked;

    public static string? CurrentLogFile => _file;

    private static string MarkerPath => Path.Combine(AppPaths.LogsDir, _app + ".running");

    /// <summary>
    /// Call on every normal exit. If it is never called (hard crash, killed process, driver crash) the next start
    /// finds the marker and writes a crash report from the previous run's log.
    /// </summary>
    public static void MarkCleanExit()
    {
        try { File.Delete(MarkerPath); } catch (Exception) { }
    }

    private static void CheckPreviousRun()
    {
        try
        {
            var marker = MarkerPath;
            if (File.Exists(marker))
            {
                var lines = File.ReadAllLines(marker);
                int pid = lines.Length > 0 && int.TryParse(lines[0], out int p) ? p : 0;
                string prevLog = lines.Length > 1 ? lines[1] : "";
                bool alive = false;
                if (pid > 0 && pid != Environment.ProcessId)
                {
                    try { alive = !Process.GetProcessById(pid).HasExited; } catch (Exception) { }
                }
                if (!alive)
                {
                    var tail = new StringBuilder();
                    try
                    {
                        if (File.Exists(prevLog))
                            foreach (var l in File.ReadLines(prevLog).TakeLast(TailLines)) tail.AppendLine(l);
                    }
                    catch (Exception) { }
                    string path = Path.Combine(AppPaths.CrashesDir, $"crash_{_app}_{DateTime.Now:yyyyMMdd_HHmmss}_previous_run.txt");
                    File.WriteAllText(path,
                        $"HoiSharp: the previous {_app} run (pid {pid}) never exited cleanly.\r\n" +
                        "It was killed or crashed hard (native/driver crash, power loss, task manager) before it could write its own report.\r\n" +
                        $"Previous log: {prevLog}\r\n\r\n---- last log lines of that run ----\r\n{tail}");
                    Write("WARN ", "Previous run did not exit cleanly, report: " + path);
                    PreviousRunCrashReport = path;
                }
            }
            File.WriteAllText(marker, Environment.ProcessId + Environment.NewLine + _file);
        }
        catch (Exception) { }
    }

    /// <summary>Set at startup when the previous run of this program died without a clean exit.</summary>
    public static string? PreviousRunCrashReport { get; private set; }

    public static void Init(string appName)
    {
        lock (Gate)
        {
            _app = appName;
            try
            {
                Directory.CreateDirectory(AppPaths.LogsDir);
                Directory.CreateDirectory(AppPaths.CrashesDir);
                _file = Path.Combine(AppPaths.LogsDir, $"{appName}_{DateTime.Now:yyyyMMdd_HHmmss}.log");
                Prune(AppPaths.LogsDir, appName + "_*.log", KeepLogFiles);
                Prune(AppPaths.CrashesDir, "crash_*.txt", KeepCrashFiles);
            }
            catch (Exception) { _file = null; }

            CheckPreviousRun();

            if (!_hooked)
            {
                _hooked = true;
                AppDomain.CurrentDomain.UnhandledException += (_, e) =>
                {
                    WriteCrash(e.ExceptionObject as Exception ?? new Exception(e.ExceptionObject?.ToString()), "Unhandled exception" + (e.IsTerminating ? " (fatal)" : ""));
                    if (e.IsTerminating) MarkCleanExit(); // the report above is the record of this death
                };
                TaskScheduler.UnobservedTaskException += (_, e) =>
                {
                    Error("Unobserved task exception: " + e.Exception);
                    e.SetObserved();
                };
            }
        }

        Info($"{appName} {AppVersion.Current} started (pid {Environment.ProcessId}). {Environment.OSVersion}, .NET {Environment.Version}, root {AppPaths.Root}");
    }

    public static void Info(string message) => Write("INFO ", message);
    public static void Warn(string message) => Write("WARN ", message);
    public static void Error(string message) => Write("ERROR", message);

    public static void Write(string level, string message)
    {
        string line = $"{DateTime.Now:HH:mm:ss.fff} [{level}] {message}";
        lock (Gate)
        {
            Tail.Enqueue(line);
            while (Tail.Count > TailLines) Tail.Dequeue();
            if (_file == null) return;
            try { File.AppendAllText(_file, line + Environment.NewLine); }
            catch (Exception) { /* disk full / locked: ignore */ }
        }
    }

    /// <summary>Writes crashes/crash_&lt;app&gt;_&lt;time&gt;.txt and returns its path (null if it could not be written).</summary>
    public static string? WriteCrash(Exception ex, string context = "Crash")
    {
        Error($"{context}: {ex}");
        try
        {
            Directory.CreateDirectory(AppPaths.CrashesDir);
            string path = Path.Combine(AppPaths.CrashesDir, $"crash_{_app}_{DateTime.Now:yyyyMMdd_HHmmss}.txt");
            var sb = new StringBuilder();
            sb.AppendLine($"HoiSharp crash report - {context}");
            sb.AppendLine($"Time:      {DateTime.Now:yyyy-MM-dd HH:mm:ss zzz}");
            sb.AppendLine($"Program:   {_app}  version {AppVersion.Current}");
            sb.AppendLine($"OS:        {RuntimeInformation.OSDescription} ({RuntimeInformation.OSArchitecture})");
            sb.AppendLine($"Runtime:   {RuntimeInformation.FrameworkDescription}");
            sb.AppendLine($"Memory:    {Process.GetCurrentProcess().WorkingSet64 / (1024 * 1024)} MB working set");
            sb.AppendLine($"Command:   {Environment.CommandLine}");
            sb.AppendLine($"Log file:  {_file}");
            sb.AppendLine();
            sb.AppendLine("---- exception ----");
            sb.AppendLine(ex.ToString());
            sb.AppendLine();
            sb.AppendLine($"---- last {TailLines} log lines ----");
            lock (Gate) foreach (var l in Tail) sb.AppendLine(l);
            File.WriteAllText(path, sb.ToString());
            return path;
        }
        catch (Exception) { return null; }
    }

    private static void Prune(string dir, string pattern, int keep)
    {
        try
        {
            foreach (var f in new DirectoryInfo(dir).GetFiles(pattern).OrderByDescending(f => f.LastWriteTimeUtc).Skip(keep))
                f.Delete();
        }
        catch (Exception) { }
    }
}
