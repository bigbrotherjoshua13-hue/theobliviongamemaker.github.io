namespace HoiSharp.Core.Data;

/// <summary>
/// Built-in formable nations + helpers to discover dynamic formables from map cores.
/// HOI4 decision files are not parsed; this is a practical equivalent.
/// </summary>
public static class FormableLibrary
{
    public static IReadOnlyList<FormableDef> BuiltIn { get; } = BuildDefault();

    private static List<FormableDef> BuildDefault()
    {
        return new List<FormableDef>
        {
            F("form_germany", "Germany", "GER", new[] { "GER", "PRE", "BAV", "SAX", "WUR", "HAN" }, 0.65),
            F("form_italy", "Italy", "ITA", new[] { "ITA", "PIE", "TUS", "SIC", "PAP", "NAP" }, 0.65),
            F("form_scandinavia", "Scandinavia", "SCA", new[] { "SWE", "NOR", "DEN", "FIN", "ICE" }, 0.75),
            F("form_yugoslavia", "Yugoslavia", "YUG", new[] { "YUG", "SER", "CRO", "SLV", "BOS", "MAC", "MNT" }, 0.7),
            F("form_romania_great", "Greater Romania", "ROM", new[] { "ROM", "TRA", "MOL" }, 0.7),
            F("form_poland", "Poland", "POL", new[] { "POL", "GAL", "WPR" }, 0.7),
            F("form_hungary", "Hungary", "HUN", new[] { "HUN", "SLO", "TRA" }, 0.7),
            F("form_austria_hungary", "Austria-Hungary", "AUH", new[] { "AUS", "HUN", "CZE", "SLO", "CRO" }, 0.7),
            F("form_netherlands_belux", "Benelux", "BEN", new[] { "HOL", "BEL", "LUX" }, 0.9),
            F("form_iberia", "Iberia", "IBE", new[] { "SPR", "POR", "CAT", "NAV" }, 0.75),
            F("form_britain", "United Kingdom", "ENG", new[] { "ENG", "SCO", "WAL", "NIR", "IRE" }, 0.7),
            F("form_china", "China", "CHI", new[] { "CHI", "PRC", "GXC", "YUN", "XSM", "SHX", "SIK" }, 0.55),
            F("form_india", "India", "RAJ", new[] { "RAJ", "PAK", "BAN", "BUR" }, 0.6),
            F("form_arabia", "Arabia", "ARA", new[] { "SAU", "YEM", "OMA", "QAT", "KUW", "UAE", "IRQ", "JOR", "SYR" }, 0.55),
            F("form_gran_colombia", "Gran Colombia", "GCO", new[] { "COL", "VEN", "ECU", "PAN" }, 0.75),
            F("form_peru_bolivia", "Peru-Bolivia", "PBC", new[] { "PRU", "BOL" }, 0.85),
            F("form_eu", "European Union", "EUU", new[] { "FRA", "GER", "ITA", "HOL", "BEL", "LUX", "SPA", "POR", "AUS" }, 0.85),
            F("form_usa", "United States", "USA", new[] { "USA", "CSA", "TEX", "CAL" }, 0.7),
            F("form_russia", "Russia", "SOV", new[] { "SOV", "RUS", "UKR", "BLR", "KAZ", "GEO", "AZR", "ARM" }, 0.55),
            F("form_turan", "Turan", "TRN", new[] { "TUR", "AZR", "KAZ", "UZB", "TMS", "KYR", "TAJ" }, 0.6),
        };
    }

    private static FormableDef F(string id, string name, string tag, string[] required, double frac) =>
        new()
        {
            Id = id,
            Name = name,
            ResultTag = tag,
            RequiredTags = required.ToList(),
            RequiredFraction = frac,
        };

    /// <summary>
    /// Dynamic formables: any country tag that currently owns 0 states but still has cores on the map.
    /// Forming requires owning RequiredFraction of those core states.
    /// </summary>
    public static List<FormableDef> DiscoverFromMap(MapData map)
    {
        var list = new List<FormableDef>();
        foreach (var c in map.CountryList)
        {
            int ownedStates = map.StatesOf(c.Tag).Count();
            if (ownedStates > 0) continue;

            var coreStates = map.States.Values.Where(s => s.Cores.Contains(c.Tag)).Select(s => s.Id).ToList();
            if (coreStates.Count < 2) continue;

            list.Add(new FormableDef
            {
                Id = "form_" + c.Tag.ToLowerInvariant(),
                Name = c.Name,
                ResultTag = c.Tag,
                RequiredTags = new List<string> { c.Tag },
                RequiredStates = coreStates,
                RequiredFraction = 0.7,
            });
        }
        return list;
    }
}
