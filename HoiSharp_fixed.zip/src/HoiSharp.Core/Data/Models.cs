namespace HoiSharp.Core.Data;

public enum ProvinceType : byte { Land, Sea, Lake }

public enum EdgeKind : byte { Land, Sea, Coast, Strait }

/// <summary>A connection between two provinces. BorderPx is the shared border length in map pixels.</summary>
public readonly record struct Edge(int To, int BorderPx, EdgeKind Kind);

public sealed class Province
{
    public int Id;
    public byte R, G, B;
    public ProvinceType Type;
    public bool Coastal;
    public string Terrain = "plains";
    public int Continent;

    /// <summary>Display name from localisation (key PROV&lt;id&gt;), e.g. "Bavaria". Empty for sea provinces.</summary>
    public string Name = "";

    /// <summary>0 when the province belongs to no state (sea).</summary>
    public int StateId;

    /// <summary>Tag of the country that currently occupies the province (changes during war).</summary>
    public string? Controller;

    // Geometry, filled in by the renderer after it has read provinces.png
    public float CenterX, CenterY;
    public int PixelCount;
    public int MinX, MinY, MaxX, MaxY;

    public List<Edge> Edges = new();

    public bool IsLand => Type == ProvinceType.Land;
    public int ColorKey => (R << 16) | (G << 8) | B;
}

public sealed class State
{
    public int Id;
    public string Key = "";          // STATE_12 (localisation key)
    public string Name = "";         // resolved display name
    public int Manpower;
    public string Category = "rural";
    public string Owner = "";

    /// <summary>Owner as defined by the loaded mods, before any scenario changed it.</summary>
    public string BaseOwner = "";
    public HashSet<string> Cores = new();
    public List<int> Provinces = new();

    /// <summary>Civilian factories — expand industry / build more factories.</summary>
    public int CivilianFactories;
    /// <summary>Military factories — produce land/naval/air units.</summary>
    public int MilitaryFactories;

    // --- uprising / occupation support ---
    /// <summary>0-100. Accumulates while the state is occupied by a non-core country or under low stability.</summary>
    public double Unrest;
}

public enum Ideology : byte
{
    Neutral,
    Democratic,
    Fascist,
    Communist,
    Monarchist,
}

/// <summary>Political leader of a country (simplified HOI-style portrait-less leader).</summary>
public sealed class Leader
{
    public string Name = "";
    public string Title = "Leader";       // President, Chancellor, Chairman, King...
    public Ideology Ideology = Ideology.Neutral;
    /// <summary>Soft bonuses applied while in power (stability, war support, manpower recovery).</summary>
    public double StabilityBonus;
    public double WarSupportBonus;
    public double ManpowerBonus;          // multiplier on monthly recovery, e.g. 0.05 = +5%
}

/// <summary>A named settlement on the map. Capitals are always cities; a few extra majors per large country.</summary>
public sealed class City
{
    public int Id;
    public string Name = "";
    public int ProvinceId;
    public int StateId;
    public string OwnerTag = "";
    public bool IsCapital;
    /// <summary>Relative importance 1-10 (capital usually 8-10).</summary>
    public int Rank = 3;
    /// <summary>War-score value when captured (capitals worth more).</summary>
    public int WarScoreValue => IsCapital ? 25 + Rank : 5 + Rank;
}

public sealed class Country
{
    /// <summary>1-based index used by the shader to detect country borders (0 = none/sea).</summary>
    public int Index;
    public string Tag = "";
    public string Name = "";
    public byte R = 128, G = 128, B = 128;
    public int Capital;
    public string Continent = "";
    public long Population;

    // runtime state
    public double ManpowerPool;
    public bool IsPlayer;
    /// <summary>Military production points accumulated from mil factories.</summary>
    public double MilProduction;
    /// <summary>Civilian production points (build factories).</summary>
    public double CivProduction;

    // --- economy ---
    /// <summary>National treasury (abstract currency).</summary>
    public double Treasury;
    /// <summary>Monthly GDP-like output before modifiers.</summary>
    public double Gdp;
    /// <summary>Multiplier on production &amp; income. 1.0 = normal. Booms &gt;1, crashes &lt;1.</summary>
    public double EconomyModifier = 1.0;
    /// <summary>Short label for current cycle: "Boom", "Stable", "Recession", "Crash".</summary>
    public string EconomyPhase = "Stable";
    /// <summary>Months remaining on the current boom/crash (0 = none).</summary>
    public int EconomyPhaseMonths;
    /// <summary>Running trade balance this month (exports - imports).</summary>
    public double TradeBalance;

    // --- politics ---
    public Ideology Ideology = Ideology.Neutral;
    /// <summary>0-100. Low stability raises uprising chance and lowers manpower recovery.</summary>
    public double Stability = 60;
    /// <summary>0-100. Affects willingness to fight and some focus availability.</summary>
    public double WarSupport = 40;
    /// <summary>National spirits currently active (ids).</summary>
    public List<string> Spirits = new();
    public Leader? Leader;

    /// <summary>
    /// 0-100. How close this country is to capitulating in its current wars.
    /// Driven by lost territory, lost capital, and enemy war score.
    /// At 100 the country is forced into a peace conference as the loser.
    /// </summary>
    public double Capitulation;

    // --- focus tree runtime ---
    public string? ActiveFocusId;
    public int FocusDaysRemaining;
    public HashSet<string> CompletedFocuses = new(StringComparer.OrdinalIgnoreCase);
    /// <summary>Focus tree id assigned to this country (e.g. "generic", "GER", "USA").</summary>
    public string FocusTreeId = "generic";
}

/// <summary>A war between two countries, tracking war score for each side.</summary>
public sealed class War
{
    public string A = "";
    public string B = "";
    public DateTime Start;
    /// <summary>AI-only wars end on their own; wars involving the player last until peace is made.</summary>
    public DateTime? EndsOn;

    /// <summary>Accumulated war score for side A (from battles, occupations, cities taken).</summary>
    public double ScoreA;
    /// <summary>Accumulated war score for side B.</summary>
    public double ScoreB;

    public bool Involves(string tag) => A == tag || B == tag;
    public bool Is(string x, string y) => (A == x && B == y) || (A == y && B == x);

    public double ScoreOf(string tag) => tag == A ? ScoreA : tag == B ? ScoreB : 0;
    public void AddScore(string tag, double amount)
    {
        if (tag == A) ScoreA += amount;
        else if (tag == B) ScoreB += amount;
    }
}

/// <summary>Bilateral trade agreement. Both sides gain income scaled by the weaker partner's industry.</summary>
public sealed class TradeDeal
{
    public string A = "";
    public string B = "";
    public DateTime Start;
    /// <summary>Monthly trade volume (abstract). Split as income to both, slightly more to the larger economy.</summary>
    public double Volume;
    public bool Active = true;

    public bool Involves(string tag) =>
        string.Equals(A, tag, StringComparison.OrdinalIgnoreCase)
        || string.Equals(B, tag, StringComparison.OrdinalIgnoreCase);
    public bool Is(string x, string y) =>
        (string.Equals(A, x, StringComparison.OrdinalIgnoreCase) && string.Equals(B, y, StringComparison.OrdinalIgnoreCase))
        || (string.Equals(A, y, StringComparison.OrdinalIgnoreCase) && string.Equals(B, x, StringComparison.OrdinalIgnoreCase));
}

// ---------------------------------------------------------------------------
// Peace conferences
// ---------------------------------------------------------------------------

public enum PeaceActionKind : byte
{
    /// <summary>Return the state to its pre-war owner (white peace for that state).</summary>
    Liberate,
    /// <summary>Winner takes the state as core territory.</summary>
    Annex,
    /// <summary>Winner takes the state but does not add a core (occupation).</summary>
    Occupy,
    /// <summary>Make the loser's state owner a subject (rank chosen separately).</summary>
    Puppet,
}

// ---------------------------------------------------------------------------
// Alliances & puppets
// ---------------------------------------------------------------------------

/// <summary>
/// Rank of a subject relationship. Higher rank = tighter control by the overlord.
/// </summary>
public enum PuppetRank : byte
{
    /// <summary>Loose protectorate — keeps most autonomy, may refuse some calls.</summary>
    Protectorate = 0,
    /// <summary>Dominion — own armies, auto-joins defensive wars.</summary>
    Dominion = 1,
    /// <summary>Satellite — limited diplomacy, joins most wars, pays light tribute.</summary>
    Satellite = 2,
    /// <summary>Puppet — heavy control, joins all wars, significant tribute.</summary>
    Puppet = 3,
    /// <summary>Integrated puppet — almost annexed; max tribute, no independent diplomacy.</summary>
    Integrated = 4,
}

/// <summary>One overlord → subject relationship.</summary>
public sealed class SubjectRelation
{
    public string Overlord = "";
    public string Subject = "";
    public PuppetRank Rank = PuppetRank.Puppet;
    public DateTime Established;

    /// <summary>Fraction of subject manpower growth skimmed by overlord (0-1).</summary>
    public double TributeRate => Rank switch
    {
        PuppetRank.Protectorate => 0.05,
        PuppetRank.Dominion => 0.10,
        PuppetRank.Satellite => 0.18,
        PuppetRank.Puppet => 0.28,
        PuppetRank.Integrated => 0.40,
        _ => 0.15,
    };

    public bool MustJoinOffensiveWars => Rank >= PuppetRank.Satellite;
    public bool MustJoinDefensiveWars => Rank >= PuppetRank.Dominion;
    public bool CanDeclareIndependentWars => Rank <= PuppetRank.Dominion;
}

/// <summary>
/// A named alliance / faction. Countries may belong to multiple alliances (multi-alliance).
/// </summary>
public sealed class Alliance
{
    public int Id;
    public string Name = "";
    public string LeaderTag = "";                 // optional "senior" member
    public HashSet<string> Members { get; } = new(StringComparer.OrdinalIgnoreCase);
    public DateTime Formed;
    /// <summary>If true, members are called into any war another member starts or is attacked in.</summary>
    public bool Defensive = true;
    public bool Offensive = true;

    public bool Contains(string tag) => Members.Contains(tag);
}

/// <summary>One demand the winner can make on a state during a peace conference.</summary>
public sealed class PeaceDemand
{
    public int StateId;
    public string StateName = "";
    public string CurrentOwner = "";
    public string Controller = "";   // who occupies it at conference time
    public PeaceActionKind Action = PeaceActionKind.Annex;
    /// <summary>When Action is Puppet, which subject rank to apply to the loser (whole-country) or state owner.</summary>
    public PuppetRank PuppetRank = PuppetRank.Puppet;
    public int ScoreCost;            // how much conference score this demand costs
    public bool Selected;
}

/// <summary>
/// A peace conference between winner(s) and loser.
/// Budget comes from war score + occupation of territory and cities.
/// </summary>
public sealed class PeaceConference
{
    public string Winner = "";
    public string Loser = "";
    public DateTime Started;
    /// <summary>Points the winner can spend on demands (from war score + occupation).</summary>
    public int Score;
    /// <summary>Raw accumulated war score of the winner at conference open.</summary>
    public double WinnerWarScore;
    /// <summary>Loser capitulation % at conference open (0-100).</summary>
    public double LoserCapitulation;
    public List<PeaceDemand> Demands = new();
    public bool Resolved;
    public bool InvolvesPlayer;
    public bool ForcedByCapitulation;
}

// ---------------------------------------------------------------------------
// National Focus system
// ---------------------------------------------------------------------------

/// <summary>One node in a national focus tree.</summary>
public sealed class FocusNode
{
    public string Id = "";
    public string Name = "";
    public string Description = "";
    public int X, Y;                         // layout position in the tree UI
    public int CostDays = 70;
    public List<string> Prerequisites = new(); // all of these must be completed
    public List<string> MutuallyExclusive = new();
    public List<FocusEffect> Effects = new();
    public bool AiWillDo = true;             // simple AI weight later
}

public sealed class FocusTree
{
    public string Id = "";
    public string Name = "";
    public List<FocusNode> Nodes = new();
    public Dictionary<string, FocusNode> ById { get; } = new(StringComparer.OrdinalIgnoreCase);

    public void BuildIndex()
    {
        ById.Clear();
        foreach (var n in Nodes)
            ById[n.Id] = n;
    }
}

public enum FocusEffectType
{
    AddStability,
    AddWarSupport,
    AddManpower,
    AddCore,
    AddClaim,           // claim on a state (stored as spirit for now)
    DeclareWar,
    CreateUnit,         // spawn armies in capital / specified state
    AnnexState,         // transfer ownership of a state
    SetIdeology,
    AddSpirit,
    RemoveSpirit,
    CustomMessage,
}

public sealed class FocusEffect
{
    public FocusEffectType Type;
    public string? StringArg;   // tag, state key, spirit id, message...
    public int IntArg;          // amount, province, count...
    public double DoubleArg;    // stability %, etc.
}

// ---------------------------------------------------------------------------
// Uprisings
// ---------------------------------------------------------------------------

public sealed class Uprising
{
    public int Id;
    public int StateId;
    public string RebelTag = "";          // temporary or existing rebel country
    public string AgainstTag = "";        // the country being rebelled against
    public DateTime Started;
    public List<int> ArmyIds = new();     // rebel armies belonging to this uprising
    public bool Resolved;
}

// ---------------------------------------------------------------------------
// Simple event / decision stubs (extensible later)
// ---------------------------------------------------------------------------

public sealed class GameEvent
{
    public string Id = "";
    public string Title = "";
    public string Description = "";
    public string? ForTag;                // null = any
    public List<EventOption> Options = new();
    public bool Fired;
}

public sealed class EventOption
{
    public string Text = "";
    public List<FocusEffect> Effects = new();
}
