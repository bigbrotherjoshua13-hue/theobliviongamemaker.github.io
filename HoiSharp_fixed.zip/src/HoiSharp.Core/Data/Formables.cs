namespace HoiSharp.Core.Data;

/// <summary>Definition of a formable nation (control required states / tags → become this country).</summary>
public sealed class FormableDef
{
    public string Id = "";
    public string Name = "";
    /// <summary>Resulting country tag after forming (may already exist as a shell).</summary>
    public string ResultTag = "";
    /// <summary>Tags whose cores/states count toward the requirement.</summary>
    public List<string> RequiredTags = new();
    /// <summary>Fraction of required-tag cores you must own (0-1).</summary>
    public double RequiredFraction = 0.7;
    /// <summary>Optional explicit state ids that must be owned.</summary>
    public List<int> RequiredStates = new();
    public string IdeologyHint = "";
}

/// <summary>A releasable nation opportunity for a given overlord.</summary>
public sealed class ReleaseOption
{
    public string Tag = "";
    public string Name = "";
    public List<int> StateIds = new();
    public int TotalCores;
    public bool AsPuppet = true;
}
