using System.Globalization;
using System.Text.RegularExpressions;
using HoiSharp.Core.Modding;
using HoiSharp.Core.Paradox;

namespace HoiSharp.Core.Data;

/// <summary>
/// Static world data loaded through the mod file system:
/// map/default.map, map/definition.csv, map/adjacency_graph.csv,
/// history/states/*.txt, common/countries/*.txt, localisation/english/*.yml
/// </summary>
public sealed class MapData
{
    public ModFileSystem Fs { get; }
    public int Width { get; private set; }
    public int Height { get; private set; }
    public double LatMax { get; private set; } = 83.0;
    public double LatMin { get; private set; } = -57.0;

    /// <summary>Indexed by province id. Index 0 is the "unknown" province.</summary>
    public Province[] Provinces { get; private set; } = Array.Empty<Province>();
    public Dictionary<int, int> ColorToId { get; } = new();
    public Dictionary<int, State> States { get; } = new();
    public Dictionary<string, Country> Countries { get; } = new(StringComparer.OrdinalIgnoreCase);
    public List<Country> CountryList { get; } = new();
    public Dictionary<string, string> Localisation { get; } = new(StringComparer.OrdinalIgnoreCase);
    /// <summary>Sparse set of named cities (capitals + a few majors). Not every province is a city.</summary>
    public List<City> Cities { get; } = new();
    public Dictionary<int, City> CitiesByProvince { get; } = new();

    private MapData(ModFileSystem fs) { Fs = fs; }

    public static MapData Load(ModFileSystem fs)
    {
        var d = new MapData(fs);
        d.LoadDefaultMap();
        d.LoadLocalisation();
        d.LoadDefinitions();
        d.LoadAdjacency();
        d.LoadCountries();
        d.LoadStates();
        d.FinalizeData();
        return d;
    }

    // ------------------------------------------------------------------ loading
    private void LoadDefaultMap()
    {
        var root = ParadoxParser.Parse(Fs.ReadAllText("map/default.map"));
        Width = root.Int("width", 4096);
        Height = root.Int("height", 1600);
        LatMax = root.Double("lat_max", 83.0);
        LatMin = root.Double("lat_min", -57.0);
    }

    private void LoadLocalisation()
    {
        var rx = new Regex("^\\s*([A-Za-z0-9_\\.\\-]+):\\d*\\s+\"(.*)\"\\s*$");
        foreach (var file in Fs.ListFilesInLoadOrder("localisation/english", "*.yml"))
        {
            foreach (var line in File.ReadLines(file))
            {
                var m = rx.Match(line);
                if (m.Success) Localisation[m.Groups[1].Value] = m.Groups[2].Value;
            }
        }
    }

    private void LoadDefinitions()
    {
        var lines = Fs.ReadAllText("map/definition.csv").Split('\n', StringSplitOptions.RemoveEmptyEntries);
        var list = new List<Province>();
        int maxId = 0;
        foreach (var raw in lines)
        {
            var parts = raw.Trim().Split(';');
            if (parts.Length < 5) continue;
            if (!int.TryParse(parts[0], out int id)) continue;

            var p = new Province
            {
                Id = id,
                R = byte.Parse(parts[1], CultureInfo.InvariantCulture),
                G = byte.Parse(parts[2], CultureInfo.InvariantCulture),
                B = byte.Parse(parts[3], CultureInfo.InvariantCulture),
                Type = parts[4].Trim().ToLowerInvariant() switch
                {
                    "sea" => ProvinceType.Sea,
                    "lake" => ProvinceType.Lake,
                    _ => ProvinceType.Land,
                },
                Coastal = parts.Length > 5 && parts[5].Trim().Equals("true", StringComparison.OrdinalIgnoreCase),
                Terrain = parts.Length > 6 ? parts[6].Trim() : "plains",
                Continent = parts.Length > 7 && int.TryParse(parts[7], out int c) ? c : 0,
                Name = Localisation.TryGetValue("PROV" + id.ToString(CultureInfo.InvariantCulture), out var provName) ? provName : "",
            };
            list.Add(p);
            maxId = Math.Max(maxId, id);
        }

        Provinces = new Province[maxId + 1];
        foreach (var p in list)
        {
            Provinces[p.Id] = p;
            if (p.Id != 0) ColorToId[p.ColorKey] = p.Id;
        }
        for (int i = 0; i < Provinces.Length; i++)
            Provinces[i] ??= new Province { Id = i, Type = ProvinceType.Sea };
    }

    private void LoadAdjacency()
    {
        var path = Fs.Resolve("map/adjacency_graph.csv");
        if (path == null) return;
        bool header = true;
        foreach (var raw in File.ReadLines(path))
        {
            if (header) { header = false; continue; }
            var parts = raw.Trim().Split(';');
            if (parts.Length < 4) continue;
            if (!int.TryParse(parts[0], out int a) || !int.TryParse(parts[1], out int b)) continue;
            if (a <= 0 || b <= 0 || a >= Provinces.Length || b >= Provinces.Length) continue;
            int px = int.TryParse(parts[2], out int n) ? n : 1;
            var kind = parts[3].Trim() switch
            {
                "sea" => EdgeKind.Sea,
                "coast" => EdgeKind.Coast,
                "strait" => EdgeKind.Strait,
                _ => EdgeKind.Land,
            };
            Provinces[a].Edges.Add(new Edge(b, px, kind));
            Provinces[b].Edges.Add(new Edge(a, px, kind));
        }
    }

    private void LoadCountries()
    {
        foreach (var file in Fs.ListFilesInLoadOrder("common/countries"))
        {
            var root = ParadoxParser.ParseFile(file);
            foreach (var node in root.Children)
            {
                if (node.Key == null || !node.IsBlock) continue;
                // A later file (mod) can redefine a tag; only the fields it provides are changed.
                if (!Countries.TryGetValue(node.Key, out var c))
                {
                    c = new Country { Tag = node.Key.ToUpperInvariant(), Name = node.Key };
                    Countries[c.Tag] = c;
                }
                if (node.Str("name") is { } name) c.Name = name;
                if (node.Child("color") is { } col)
                {
                    var v = col.Ints().ToList();
                    if (v.Count >= 3) { c.R = (byte)v[0]; c.G = (byte)v[1]; c.B = (byte)v[2]; }
                }
                if (node.Child("capital") != null) c.Capital = node.Int("capital");
                if (node.Str("continent") is { } cont) c.Continent = cont;
                if (node.Child("population") != null) c.Population = node.Long("population");
            }
        }
    }

    private void LoadStates()
    {
        foreach (var file in Fs.ListFilesInLoadOrder("history/states"))
        {
            var root = ParadoxParser.ParseFile(file);
            var st = root.Child("state");
            if (st == null) continue;

            var s = new State
            {
                Id = st.Int("id"),
                Key = st.Str("name") ?? "",
                Manpower = st.Int("manpower"),
                Category = st.Str("state_category") ?? "rural",
            };
            if (s.Id <= 0) continue;

            var hist = st.Child("history");
            if (hist != null)
            {
                s.Owner = hist.Str("owner") ?? "";
                // HOI4 date blocks may hold owner if root history has none
                if (string.IsNullOrEmpty(s.Owner))
                {
                    foreach (var child in hist.Children)
                    {
                        if (!child.IsBlock) continue;
                        var o = child.Str("owner");
                        if (!string.IsNullOrEmpty(o)) { s.Owner = o; break; }
                    }
                }
                foreach (var core in hist.ChildrenNamed("add_core_of"))
                    if (core.Value != null) s.Cores.Add(core.Value);

                // buildings = { infrastructure / industrial_complex / arms_factory }
                var buildings = hist.Child("buildings");
                if (buildings != null)
                {
                    int infra = buildings.Int("infrastructure");
                    int civ = buildings.Int("industrial_complex");
                    int mil = buildings.Int("arms_factory");
                    if (civ == 0) civ = buildings.Int("civilian_factory");
                    if (mil == 0) mil = buildings.Int("military_factory");
                    s.CivilianFactories = Math.Max(s.CivilianFactories, civ + infra / 3);
                    s.MilitaryFactories = Math.Max(s.MilitaryFactories, mil);
                }
            }
            s.BaseOwner = s.Owner;
            if (st.Child("provinces") is { } provs) s.Provinces = provs.Ints().ToList();
            s.Name = Localisation.TryGetValue(s.Key, out var loc) ? loc : s.Key;
            States[s.Id] = s; // later mod file with same state id replaces it
        }
    }

    private void FinalizeData()
    {
        // province -> state link; drop provinces that were assigned to a replaced state
        foreach (var s in States.Values)
            foreach (var pid in s.Provinces)
                if (pid > 0 && pid < Provinces.Length) Provinces[pid].StateId = s.Id;

        int idx = 1;
        foreach (var c in Countries.Values.OrderBy(c => c.Tag, StringComparer.Ordinal))
        {
            c.Index = idx++;
            CountryList.Add(c);
        }

        GenerateCities();
    }

    /// <summary>
    /// Capitals for every country + a small number of extra major cities for large countries.
    /// Roughly: 1 capital always, +1 city per ~3-4 states (capped), so the map stays readable.
    /// </summary>
    private void GenerateCities()
    {
        Cities.Clear();
        CitiesByProvince.Clear();
        int nextId = 1;
        var usedProvinces = new HashSet<int>();

        foreach (var c in CountryList)
        {
            var states = StatesOf(c.Tag).OrderByDescending(s => s.Manpower).ToList();
            if (states.Count == 0) continue;

            // capital city
            int capPid = c.Capital;
            if (capPid <= 0 || capPid >= Provinces.Length || !Provinces[capPid].IsLand
                || OwnerOf(capPid) != c.Tag)
            {
                // fall back to highest-manpower state's first land province
                capPid = states.SelectMany(s => s.Provinces)
                    .FirstOrDefault(id => id > 0 && id < Provinces.Length && Provinces[id].IsLand);
                if (capPid > 0) c.Capital = capPid;
            }

            if (capPid > 0 && usedProvinces.Add(capPid))
            {
                var prov = Provinces[capPid];
                string name = !string.IsNullOrEmpty(prov.Name) ? prov.Name : $"{c.Name} Capital";
                var city = new City
                {
                    Id = nextId++,
                    Name = name,
                    ProvinceId = capPid,
                    StateId = prov.StateId,
                    OwnerTag = c.Tag,
                    IsCapital = true,
                    Rank = 9,
                };
                Cities.Add(city);
                CitiesByProvince[capPid] = city;
            }

            // extra majors: about 1 per 4 states, max 4 extras
            int extras = Math.Clamp(states.Count / 4, 0, 4);
            int added = 0;
            foreach (var st in states)
            {
                if (added >= extras) break;
                int pid = st.Provinces.FirstOrDefault(id =>
                    id > 0 && id < Provinces.Length && Provinces[id].IsLand && !usedProvinces.Contains(id));
                if (pid <= 0) continue;
                usedProvinces.Add(pid);
                var prov = Provinces[pid];
                string name = !string.IsNullOrEmpty(prov.Name) ? prov.Name
                    : (!string.IsNullOrEmpty(st.Name) ? st.Name : $"City {nextId}");
                var city = new City
                {
                    Id = nextId++,
                    Name = name,
                    ProvinceId = pid,
                    StateId = st.Id,
                    OwnerTag = c.Tag,
                    IsCapital = false,
                    Rank = 4 + Math.Min(3, st.Manpower / 500000),
                };
                Cities.Add(city);
                CitiesByProvince[pid] = city;
                added++;
            }
        }
    }

    public City? CityAt(int provinceId) =>
        CitiesByProvince.TryGetValue(provinceId, out var c) ? c : null;

    /// <summary>Adds a country at runtime (scenarios and the scenario builder use this).</summary>
    public Country AddCountry(string tag, string name, (byte r, byte g, byte b) color)
    {
        tag = tag.ToUpperInvariant();
        var c = new Country { Tag = tag, Name = name, R = color.r, G = color.g, B = color.b };
        Countries[tag] = c;
        c.Index = CountryList.Count + 1;
        CountryList.Add(c);
        return c;
    }

    // ------------------------------------------------------------------ queries
    public string? OwnerOf(int provinceId)
    {
        if (provinceId <= 0 || provinceId >= Provinces.Length) return null;
        int sid = Provinces[provinceId].StateId;
        return sid != 0 && States.TryGetValue(sid, out var s) && s.Owner.Length > 0 ? s.Owner : null;
    }

    public Country? CountryOf(string? tag) =>
        tag != null && Countries.TryGetValue(tag, out var c) ? c : null;

    public IEnumerable<State> StatesOf(string tag) =>
        States.Values.Where(s => string.Equals(s.Owner, tag, StringComparison.OrdinalIgnoreCase));

    /// <summary>Longitude / latitude of a map pixel.</summary>
    public (double lon, double lat) PixelToGeo(double x, double y) =>
        (x / Width * 360.0 - 180.0, LatMax - y / Height * (LatMax - LatMin));
}
