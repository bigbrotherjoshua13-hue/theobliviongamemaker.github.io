using System.Diagnostics;
using System.Windows.Forms;
using HoiSharp.Core;
using HoiSharp.Core.Diagnostics;

namespace HoiSharp.Launcher;

internal static class Program
{
    [STAThread]
    private static void Main()
    {
        AppLog.Init("launcher");
        ApplicationConfiguration.Initialize();

        // log and report UI exceptions instead of silently dying
        Application.SetUnhandledExceptionMode(UnhandledExceptionMode.CatchException);
        Application.ThreadException += (_, e) =>
        {
            var report = AppLog.WriteCrash(e.Exception, "Launcher error");
            var r = MessageBox.Show(
                "The launcher hit an error:\n\n" + e.Exception.Message + "\n\nA crash report was saved" +
                (report != null ? ":\n" + report : ".") + "\n\nOpen the crashes folder?",
                "HoiSharp Launcher", MessageBoxButtons.YesNo, MessageBoxIcon.Error);
            if (r == DialogResult.Yes) OpenFolder(AppPaths.CrashesDir);
        };

        // Hold the gate for the lifetime of the launcher - the game requires this.
        using var gate = LauncherGate.Acquire();

        Application.Run(new LauncherForm());
        AppLog.Info("Launcher closed.");
        AppLog.MarkCleanExit();
    }

    internal static void OpenFolder(string dir)
    {
        try
        {
            Directory.CreateDirectory(dir);
            Process.Start(new ProcessStartInfo("explorer.exe", "\"" + dir + "\"") { UseShellExecute = true });
        }
        catch (Exception ex) { AppLog.Warn("Could not open " + dir + ": " + ex.Message); }
    }
}
