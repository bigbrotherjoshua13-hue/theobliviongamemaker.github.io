using System.Diagnostics;
using HoiSharp.Core;
using HoiSharp.Core.Data;
using HoiSharp.Core.Diagnostics;
using HoiSharp.Core.Import;
using HoiSharp.Core.Modding;
using HoiSharp.Core.Scenarios;

namespace HoiSharp.Launcher;

/// <summary>
/// Launcher window: pick mods (load order = list order, use Up/Down), pick a country,
/// resolution and start date, then start the game with the matching command line.
/// </summary>
public sealed class LauncherForm : Form
{
    private readonly string _dataRoot;
    private readonly CheckedListBox _mods = new() { CheckOnClick = true, IntegralHeight = false };
    private readonly ComboBox _country = new() { DropDownStyle = ComboBoxStyle.DropDownList };
    private readonly ComboBox _resolution = new() { DropDownStyle = ComboBoxStyle.DropDownList };
    private readonly ComboBox _scenario = new() { DropDownStyle = ComboBoxStyle.DropDownList };
    private readonly CheckBox _fullscreen = new() { Text = "Fullscreen" };
    private readonly CheckBox _view3d = new() { Text = "Start in 2.5D view (F3 switches in game)", AutoSize = true };
    private readonly Button _builder = new() { Text = "Scenario Builder", Height = 32 };
    private readonly Button _importHoi4 = new() { Text = "Import HOI4 map (Steam)…", Height = 32 };
    private bool _syncing;
    private readonly DateTimePicker _date = new() { Format = DateTimePickerFormat.Short, Value = new DateTime(1936, 1, 1) };
    private readonly Label _status = new() { AutoSize = false, Height = 36 };
    private readonly Button _play = new() { Text = "Play", Height = 40 };
    private readonly List<ModInfo> _available = new();

    private static readonly (int w, int h)[] Resolutions =
    {
        (1280, 720), (1600, 900), (1920, 1080), (2560, 1440),
    };

    public LauncherForm()
    {
        Text = "HoiSharp Launcher (keep open while playing)";
        StartPosition = FormStartPosition.CenterScreen;
        ClientSize = new Size(580, 640);
        MinimumSize = new Size(540, 600);

        _dataRoot = FindDataRoot();

        var layout = new TableLayoutPanel
        {
            Dock = DockStyle.Fill,
            ColumnCount = 2,
            Padding = new Padding(14),
        };
        layout.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 110));
        layout.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100));

        int row = 0;
        void AddRow(string label, Control c, SizeType type = SizeType.AutoSize, float height = 0)
        {
            layout.RowStyles.Add(type == SizeType.Percent ? new RowStyle(SizeType.Percent, height) : new RowStyle(SizeType.AutoSize));
            layout.Controls.Add(new Label { Text = label, AutoSize = true, Anchor = AnchorStyles.Left | AnchorStyles.Top, Padding = new Padding(0, 6, 0, 0) }, 0, row);
            c.Dock = DockStyle.Fill;
            c.Margin = new Padding(3, 3, 3, 8);
            layout.Controls.Add(c, 1, row);
            row++;
        }

        var title = new Label
        {
            Text = "HoiSharp",
            Font = new Font(Font.FontFamily, 20f, FontStyle.Bold),
            AutoSize = true,
            Margin = new Padding(3, 0, 3, 10),
        };
        layout.Controls.Add(title, 0, row);
        layout.SetColumnSpan(title, 2);
        layout.RowStyles.Add(new RowStyle(SizeType.AutoSize));
        row++;

        AddRow("Scenario", _scenario);
        AddRow("Country", _country);
        AddRow("Start date", _date);
        AddRow("Resolution", _resolution);
        AddRow("", _fullscreen);
        AddRow("", _view3d);

        // mods list with move up / down buttons
        var modPanel = new TableLayoutPanel { ColumnCount = 2, RowCount = 1 };
        modPanel.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100));
        modPanel.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 80));
        _mods.Dock = DockStyle.Fill;
        var buttons = new FlowLayoutPanel { FlowDirection = FlowDirection.TopDown, Dock = DockStyle.Fill };
        var up = new Button { Text = "Up", Width = 70 };
        var down = new Button { Text = "Down", Width = 70 };
        var refresh = new Button { Text = "Refresh", Width = 70 };
        up.Click += (_, _) => MoveMod(-1);
        down.Click += (_, _) => MoveMod(1);
        refresh.Click += (_, _) => LoadLists();
        buttons.Controls.AddRange(new Control[] { up, down, refresh });
        modPanel.Controls.Add(_mods, 0, 0);
        modPanel.Controls.Add(buttons, 1, 0);
        AddRow("Mods", modPanel, SizeType.Percent, 100);

        layout.Controls.Add(_status, 0, row);
        layout.SetColumnSpan(_status, 2);
        layout.RowStyles.Add(new RowStyle(SizeType.AutoSize));
        row++;

        _play.Dock = DockStyle.Fill;
        _play.Click += (_, _) => Launch(false);
        layout.Controls.Add(_play, 0, row);
        layout.SetColumnSpan(_play, 2);
        layout.RowStyles.Add(new RowStyle(SizeType.AutoSize));
        row++;

        _builder.Dock = DockStyle.Fill;
        _builder.Click += (_, _) => Launch(true);
        layout.Controls.Add(_builder, 0, row);
        layout.SetColumnSpan(_builder, 2);
        layout.RowStyles.Add(new RowStyle(SizeType.AutoSize));
        row++;

        _importHoi4.Dock = DockStyle.Fill;
        _importHoi4.Click += (_, _) => ImportHoi4();
        layout.Controls.Add(_importHoi4, 0, row);
        layout.SetColumnSpan(_importHoi4, 2);
        layout.RowStyles.Add(new RowStyle(SizeType.AutoSize));

        row++;
        var tools = new FlowLayoutPanel { Dock = DockStyle.Fill, AutoSize = true, FlowDirection = FlowDirection.LeftToRight };
        var updateBtn = new Button { Text = "Check for updates", AutoSize = true };
        var logsBtn = new Button { Text = "Open logs", AutoSize = true };
        var crashBtn = new Button { Text = "Open crash reports", AutoSize = true };
        updateBtn.Click += async (_, _) => await CheckForUpdates(manual: true);
        logsBtn.Click += (_, _) => Program.OpenFolder(AppPaths.LogsDir);
        crashBtn.Click += (_, _) => Program.OpenFolder(AppPaths.CrashesDir);
        tools.Controls.AddRange(new Control[] { updateBtn, logsBtn, crashBtn });
        layout.Controls.Add(tools, 0, row);
        layout.SetColumnSpan(tools, 2);
        layout.RowStyles.Add(new RowStyle(SizeType.AutoSize));
        Text = $"HoiSharp Launcher  v{AppVersion.Current}";
        Shown += (_, _) =>
        {
            if (AppLog.PreviousRunCrashReport is { } pr)
                MessageBox.Show(this, "The launcher did not close cleanly last time.\nA report was saved:\n" + pr, "HoiSharp", MessageBoxButtons.OK, MessageBoxIcon.Warning);
        };
        Shown += async (_, _) => { if (UpdateSettings.Load().AutoCheck) await CheckForUpdates(manual: false); };

        _scenario.SelectedIndexChanged += (_, _) => OnScenarioChanged();
        _mods.ItemCheck += (_, _) => BeginInvoke(new Action(RefreshScenarios));

        Controls.Add(layout);

        foreach (var (w, h) in Resolutions) _resolution.Items.Add($"{w} x {h}");
        _resolution.SelectedIndex = 1;

        LoadLists();
    }

    // ------------------------------------------------------------------ data
    private static string FindDataRoot()
    {
        var dir = new DirectoryInfo(AppContext.BaseDirectory);
        while (dir != null)
        {
            var candidate = Path.Combine(dir.FullName, "data");
            if (Directory.Exists(Path.Combine(candidate, "mod_base"))) return candidate;
            dir = dir.Parent;
        }
        return Path.Combine(AppContext.BaseDirectory, "data");
    }

    private void LoadLists()
    {
        // remember what was ticked so Refresh does not lose the selection
        var ticked = _mods.CheckedItems.Cast<string>().ToHashSet(StringComparer.OrdinalIgnoreCase);

        _available.Clear();
        _mods.Items.Clear();
        _country.Items.Clear();
        _scenario.Items.Clear();

        if (!Directory.Exists(Path.Combine(_dataRoot, "mod_base", "map")))
        {
            _status.Text = "No map data found. Run tools/mapgen.py (see README) to generate data/mod_base first.";
            _play.Enabled = false;
            return;
        }

        _available.AddRange(ModFileSystem.DiscoverMods(_dataRoot));
        foreach (var m in _available)
            _mods.Items.Add(m.Name, ticked.Contains(m.Name));

        try
        {
            // Read country names from the base data only; mods can add more at game start.
            var fs = ModFileSystem.Create(_dataRoot, Array.Empty<string>());
            var map = MapData.Load(fs);
            foreach (var c in map.CountryList.OrderBy(c => c.Name, StringComparer.OrdinalIgnoreCase))
                _country.Items.Add(new CountryItem(c.Tag, c.Name));
            int usa = _country.Items.Cast<CountryItem>().ToList().FindIndex(i => i.Tag == "USA");
            _country.SelectedIndex = usa >= 0 ? usa : 0;
            _status.Text = $"{map.CountryList.Count} countries, {map.States.Count} states, {map.Provinces.Length - 1:N0} provinces. {_available.Count} mod(s) found.";
            _play.Enabled = true;
            RefreshScenarios();
        }
        catch (Exception ex)
        {
            _status.Text = "Could not read base data: " + ex.Message;
            _play.Enabled = false;
        }
    }

    private sealed record ScenarioItem(ScenarioFile? File, string Label, string? Player, DateTime? Start)
    {
        public override string ToString() => Label;
    }

    /// <summary>Scenarios depend on the ticked mods, so the list is rebuilt when the ticks change.</summary>
    private void RefreshScenarios()
    {
        if (_syncing) return;
        string? keep = (_scenario.SelectedItem as ScenarioItem)?.File?.Id;
        _syncing = true;
        try
        {
            _scenario.Items.Clear();
            _scenario.Items.Add(new ScenarioItem(null, "Free play (choose country and date)", null, null));
            try
            {
                var mods = _mods.CheckedItems.Cast<string>().ToArray();
                var fs = ModFileSystem.Create(_dataRoot, mods);
                foreach (var f in ScenarioLibrary.Discover(fs, _dataRoot))
                {
                    string? player = null; DateTime? start = null;
                    try
                    {
                        var sc = Scenario.Load(f.Path);
                        player = sc.Player; start = sc.StartDate;
                    }
                    catch (Exception) { }
                    _scenario.Items.Add(new ScenarioItem(f, f.IsUser ? f.Name + "  (yours)" : f.Name, player, start));
                }
            }
            catch (Exception ex)
            {
                _status.Text = "Could not list scenarios: " + ex.Message;
            }
            int idx = 0;
            for (int i = 1; i < _scenario.Items.Count; i++)
                if (((ScenarioItem)_scenario.Items[i]!).File!.Id == keep) idx = i;
            _scenario.SelectedIndex = idx;
        }
        finally { _syncing = false; }
        OnScenarioChanged();
    }

    private void OnScenarioChanged()
    {
        if (_syncing || _scenario.SelectedItem is not ScenarioItem item) return;
        bool free = item.File == null;
        _date.Enabled = free;   // a scenario brings its own start date
        if (item.Start is { } d) _date.Value = d;
        if (item.Player != null)
        {
            for (int i = 0; i < _country.Items.Count; i++)
                if (_country.Items[i] is CountryItem c && string.Equals(c.Tag, item.Player, StringComparison.OrdinalIgnoreCase))
                { _country.SelectedIndex = i; break; }
        }
    }

    private void MoveMod(int delta)
    {
        int i = _mods.SelectedIndex;
        int j = i + delta;
        if (i < 0 || j < 0 || j >= _mods.Items.Count) return;
        var item = (string)_mods.Items[i];
        bool check = _mods.GetItemChecked(i);
        _mods.Items.RemoveAt(i);
        _mods.Items.Insert(j, item);
        _mods.SetItemChecked(j, check);
        _mods.SelectedIndex = j;
    }

    // ------------------------------------------------------------------ HOI4 import
    private void ImportHoi4()
    {
        string? path = SteamLocator.LoadSavedPath(_dataRoot) ?? SteamLocator.FindHoi4Install();
        if (path == null)
        {
            using var dlg = new FolderBrowserDialog
            {
                Description = "Select HOI4 game folder OR its map/ folder (needs definition.csv + provinces.bmp)",
                UseDescriptionForTitle = true,
            };
            if (dlg.ShowDialog(this) != DialogResult.OK) return;
            path = dlg.SelectedPath;
        }
        else
        {
            var ask = MessageBox.Show(this,
                "Found HOI4 at:\n" + path + "\n\nImport provinces, states & countries?\n\nYes = use this path\nNo = pick game folder or map/ folder",
                "Import HOI4 map", MessageBoxButtons.YesNoCancel, MessageBoxIcon.Question);
            if (ask == DialogResult.Cancel) return;
            if (ask == DialogResult.No)
            {
                using var dlg = new FolderBrowserDialog
                {
                    Description = "Select HOI4 game folder OR map/ folder",
                    UseDescriptionForTitle = true,
                    SelectedPath = path,
                };
                if (dlg.ShowDialog(this) != DialogResult.OK) return;
                path = dlg.SelectedPath;
            }
        }

        if (!SteamLocator.LooksLikeHoi4(path))
        {
            MessageBox.Show(this,
                "That folder does not look like HOI4.\n\nNeed either:\n  • Game root with map/definition.csv\n  • Or the map/ folder itself (definition.csv + provinces.bmp)",
                "Import HOI4", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            return;
        }

        _status.Text = "Importing HOI4 map — this can take a few minutes...";
        _importHoi4.Enabled = false;
        Application.DoEvents();

        try
        {
            var result = Hoi4Importer.Import(path, _dataRoot, progress: msg =>
            {
                _status.Text = msg;
                Application.DoEvents();
            });
            MessageBox.Show(this, result.Message + "\n\nTick \"HOI4 Import\" in the mods list, then Play.",
                "Import complete", MessageBoxButtons.OK, MessageBoxIcon.Information);
            LoadLists();
            // auto-check the imported mod by display name or folder id
            for (int i = 0; i < _mods.Items.Count; i++)
            {
                string name = _mods.Items[i]?.ToString() ?? "";
                if (name.Contains("HOI4", StringComparison.OrdinalIgnoreCase) ||
                    name.Contains(Hoi4Importer.DefaultModId, StringComparison.OrdinalIgnoreCase))
                    _mods.SetItemChecked(i, true);
            }
            _status.Text = "HOI4 import ready — mod checked. Press Play.";
        }
        catch (Exception ex)
        {
            MessageBox.Show(this, "Import failed:\n" + ex.Message, "Import HOI4", MessageBoxButtons.OK, MessageBoxIcon.Error);
            _status.Text = "Import failed.";
        }
        finally
        {
            _importHoi4.Enabled = true;
        }
    }

    // ------------------------------------------------------------------ launch
    private bool _updating;

    /// <summary>Asks the update server for a newer version; with manual = false it stays silent unless there is one.</summary>
    private async Task CheckForUpdates(bool manual)
    {
        if (_updating) return;
        var settings = UpdateSettings.Load();
        if (string.IsNullOrWhiteSpace(settings.ManifestUrl))
        {
            if (manual)
                MessageBox.Show(this, "No update server is set.\n\nPut the address of your update manifest into update.json (manifestUrl), see README.",
                    "Updates", MessageBoxButtons.OK, MessageBoxIcon.Information);
            return;
        }

        var info = await Updater.CheckAsync(settings);
        if (info == null)
        {
            if (manual) MessageBox.Show(this, $"You are up to date (version {AppVersion.Current}).", "Updates", MessageBoxButtons.OK, MessageBoxIcon.Information);
            return;
        }

        var ask = MessageBox.Show(this,
            $"Version {info.Version} is available (you have {AppVersion.Current}).\n\n{info.Notes}\n\nDownload and install it now? The game rebuilds afterwards.",
            "Update available", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
        if (ask != DialogResult.Yes) return;

        _updating = true;
        _play.Enabled = false;
        try
        {
            var progress = new Progress<double>(p => _status.Text = $"Downloading update... {p:P0}");
            string bat = await Updater.DownloadAsync(info, progress);
            Updater.StartApply(bat);
            Close();
        }
        catch (Exception ex)
        {
            AppLog.Error("Update failed: " + ex);
            MessageBox.Show(this, "The update failed:\n" + ex.Message + "\n\nDetails are in the logs folder.", "Updates", MessageBoxButtons.OK, MessageBoxIcon.Error);
            _play.Enabled = true;
        }
        finally { _updating = false; }
    }

    private void Launch(bool builder)
    {
        var exe = FindGameExecutable();
        if (exe == null)
        {
            MessageBox.Show(this,
                "HoiSharp.exe was not found next to the launcher.\n\nBuild everything with build.cmd (or 'dotnet build HoiSharp.sln') first.",
                "Game not found", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            return;
        }

        var (w, h) = Resolutions[Math.Max(0, _resolution.SelectedIndex)];
        var args = new List<string>
        {
            "--data", Quote(_dataRoot),
            "--width", w.ToString(),
            "--height", h.ToString(),
        };
        var scen = (_scenario.SelectedItem as ScenarioItem)?.File;
        if (scen != null) { args.Add("--scenario"); args.Add(Quote(scen.Id)); }
        else { args.Add("--date"); args.Add(_date.Value.ToString("yyyy-MM-dd")); }
        if (_country.SelectedItem is CountryItem c) { args.Add("--player"); args.Add(c.Tag); }
        if (builder) args.Add("--builder");
        if (_view3d.Checked) args.Add("--3d");
        if (_fullscreen.Checked) args.Add("--fullscreen");

        var mods = _mods.CheckedItems.Cast<string>().ToList();
        if (mods.Count > 0) { args.Add("--mods"); args.Add(Quote(string.Join(",", mods))); }

        try
        {
            AppLog.Info($"Starting game: {exe} {string.Join(" ", args)}");
            var psi = new ProcessStartInfo(exe, string.Join(" ", args))
            {
                WorkingDirectory = Path.GetDirectoryName(exe)!,
                UseShellExecute = false,
                RedirectStandardError = true,   // keep what the runtime prints when it dies before the game's own log exists
            };
            var proc = Process.Start(psi) ?? throw new InvalidOperationException("The game process did not start.");
            var errors = new System.Text.StringBuilder();
            proc.ErrorDataReceived += (_, e) => { if (e.Data != null) lock (errors) errors.AppendLine(e.Data); };
            proc.BeginErrorReadLine();
            var started = DateTime.Now;
            proc.EnableRaisingEvents = true;
            proc.Exited += (_, _) =>
            {
                proc.WaitForExit();
                int code = proc.ExitCode;
                var secs = (DateTime.Now - started).TotalSeconds;
                AppLog.Info($"Game exited with code {code} after {secs:0.0}s");
                string errText; lock (errors) errText = errors.ToString();
                if (IsHandleCreated && !IsDisposed)
                    BeginInvoke(new Action(() => OnGameExited(code, secs, errText)));
            };
            WindowState = FormWindowState.Minimized; // stay alive: the game needs the launcher, and we watch it for crashes
            _play.Enabled = false; _builder.Enabled = false;
            _status.Text = "Game running...";
        }
        catch (Exception ex)
        {
            AppLog.Error("Could not start the game: " + ex);
            MessageBox.Show(this, ex.Message, "Could not start the game", MessageBoxButtons.OK, MessageBoxIcon.Error);
        }
    }

    private void OnGameExited(int code, double seconds, string stderr)
    {
        WindowState = FormWindowState.Normal;
        Activate();
        _play.Enabled = true; _builder.Enabled = true;
        _status.Text = code == 0 ? "Game closed." : $"Game stopped with error code {code}.";
        if (code == 0) return;

        // The game normally writes its own crash report. If it died too early for that (missing DLL, runtime or
        // graphics failure) there is none, so the launcher writes one from what it saw.
        var recent = Directory.Exists(AppPaths.CrashesDir)
            ? Directory.GetFiles(AppPaths.CrashesDir, "crash_game_*.txt").Select(f => new FileInfo(f))
                .Where(f => f.LastWriteTime > DateTime.Now.AddSeconds(-seconds - 5)).OrderByDescending(f => f.LastWriteTime).FirstOrDefault()
            : null;
        string? report = recent?.FullName;
        if (report == null)
        {
            string lastLog = "";
            try
            {
                var gl = new DirectoryInfo(AppPaths.LogsDir).GetFiles("game_*.log").OrderByDescending(f => f.LastWriteTime).FirstOrDefault();
                if (gl != null) lastLog = string.Join(Environment.NewLine, File.ReadLines(gl.FullName).TakeLast(100));
            }
            catch (Exception) { }
            report = AppLog.WriteCrash(new Exception(
                $"The game exited with code {code} after {seconds:0.0} seconds without writing its own crash report.\r\n\r\n" +
                $"---- what the game printed ----\r\n{stderr}\r\n---- end of the game's log ----\r\n{lastLog}"), "Game exited abnormally");
        }
        var r = MessageBox.Show(this,
            $"The game stopped unexpectedly (code {code}, after {seconds:0.0} s).\n\nCrash report:\n{report}\n\nOpen the crashes folder?",
            "HoiSharp crashed", MessageBoxButtons.YesNo, MessageBoxIcon.Error);
        if (r == DialogResult.Yes) Program.OpenFolder(AppPaths.CrashesDir);
    }

    private static string Quote(string s) => "\"" + s.Replace("\"", "\\\"") + "\"";

    private static string? FindGameExecutable()
    {
        string name = OperatingSystem.IsWindows() ? "HoiSharp.exe" : "HoiSharp";
        var here = Path.Combine(AppContext.BaseDirectory, name);
        if (File.Exists(here)) return here;

        // development layout: ...\src\HoiSharp.Game\bin\<cfg>\net8.0\HoiSharp.exe
        var dir = new DirectoryInfo(AppContext.BaseDirectory);
        while (dir != null)
        {
            var game = Path.Combine(dir.FullName, "src", "HoiSharp.Game", "bin");
            if (Directory.Exists(game))
            {
                var hit = Directory.EnumerateFiles(game, name, SearchOption.AllDirectories)
                                   .OrderByDescending(File.GetLastWriteTimeUtc).FirstOrDefault();
                if (hit != null) return hit;
            }
            dir = dir.Parent;
        }
        return null;
    }

    private sealed record CountryItem(string Tag, string Name)
    {
        public override string ToString() => $"{Name} ({Tag})";
    }
}
