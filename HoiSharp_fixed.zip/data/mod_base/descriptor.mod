name = "HoiSharp Base World"
version = "1.0"
supported_version = "1.*"
