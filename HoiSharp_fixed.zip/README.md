# HoiSharp

HOI4-style grand strategy prototype in C# (.NET 8, MonoGame).

## Run (Windows)

Double-click **run.bat**. First run may download NuGet packages.

## Systems

| System | Notes |
|--------|--------|
| Map / armies / wars | Core gameplay |
| Flags, leaders, cities | Capitals + sparse majors |
| Focuses, uprisings | **F** for focuses |
| War score & capitulation | Capitals/cities matter; 100% = forced peace |
| Peace conferences | **K**; **T** cycles Annex / Occupy / Puppet rank |
| **Alliances** | Multi-alliance allowed; **L** forms pact with selected country; call-to-arms |
| **Puppets** | 5 ranks: Protectorate → Dominion → Satellite → Puppet → Integrated |
| Smarter AI | Alliances, strength checks, priority pathing |

### Puppet ranks

| Rank | Control | Wars | Tribute |
|------|---------|------|---------|
| Protectorate | Loose | May refuse | 5% |
| Dominion | Medium | Defensive auto | 10% |
| Satellite | Tight | Most wars | 18% |
| Puppet | Heavy | All wars | 28% |
| Integrated | Near-annex | All wars | 40% |

### Alliances

- Countries can be in **multiple** alliances.
- Members are called into wars (offensive/defensive flags).
- AI forms ideology-based pacts with neighbours.
- Subjects (Satellite+) leave independent alliances.

## Controls

| Key | Action |
|-----|--------|
| **L** | Form alliance with selected country |
| **F** / **K** | Focuses / peace conference |
| **T** | Cycle demand type in conference |
| Enter / P | War / peace |
| 1-9 | Focus or conference demands |

## Layout

`src/HoiSharp.Core`, `src/HoiSharp.Game`, `src/HoiSharp.Launcher`, `data/mod_base`, `tools`.


## Logs, crash reports, updates

- `logs/` holds one log file per run (`game_*.log`, `launcher_*.log`), the newest 20 are kept.
- `crashes/` gets a `crash_*.txt` whenever the game or launcher crashes: the exception, version, OS, and the last 200 log lines. Send that file when asking for help. The launcher has "Open logs" and "Open crash reports" buttons.
- **Auto-update:** put the address of a JSON file you host into `update.json` (`manifestUrl`):
  `{ "version": "0.3.0", "url": "https://.../HoiSharp_0.3.0.zip", "sha256": "optional", "notes": "what changed" }`.
  The launcher checks on start (and with "Check for updates"), downloads the zip, verifies the checksum, and installs it after closing,
  keeping `data/user`, `data/mods`, `logs`, `crashes` and `update.json`, then rebuilds with `run.bat rebuild`.
  The installed version is in `version.txt`. Updates are off until `manifestUrl` is set.
