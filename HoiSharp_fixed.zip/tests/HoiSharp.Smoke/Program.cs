using System.Diagnostics;
using HoiSharp.Core;
using HoiSharp.Core.Diagnostics;
using HoiSharp.Core.Data;
using HoiSharp.Core.Events;
using HoiSharp.Core.Modding;
using HoiSharp.Core.Paradox;
using HoiSharp.Core.Scenarios;
using HoiSharp.Core.Sim;

// Runs the non-graphical parts of HoiSharp against the real generated data and fails loudly on any problem.
string dataRoot = args.Length > 0 ? Path.GetFullPath(args[0]) : Path.GetFullPath("data");
int failures = 0;

void Check(bool ok, string what)
{
    Console.WriteLine((ok ? "  ok    " : "  FAIL  ") + what);
    if (!ok) failures++;
}

Console.WriteLine($"data root: {dataRoot}");

// ---------------------------------------------------------------- parser
Console.WriteLine("\n[parser]");
var p = ParadoxParser.Parse("""
    # comment
    a = 1
    name = "Hello World"   # trailing comment
    list = { 1 2 3 }
    nested = { inner = { x = 5 } y = yes }
    rep = { v = 1 } rep = { v = 2 }
    """);
Check(p.Int("a") == 1, "key = value");
Check(p.Str("name") == "Hello World", "quoted string");
Check(p.Child("list")!.Ints().SequenceEqual(new[] { 1, 2, 3 }), "bare list");
Check(p.Child("nested")!.Child("inner")!.Int("x") == 5, "nested block");
Check(p.ChildrenNamed("rep").Count() == 2, "repeated keys");

// ---------------------------------------------------------------- data
Console.WriteLine("\n[map data]");
var sw = Stopwatch.StartNew();
var fs = ModFileSystem.Create(dataRoot, Array.Empty<string>());
var map = MapData.Load(fs);
Console.WriteLine($"  loaded in {sw.ElapsedMilliseconds} ms: {map.Provinces.Length - 1} provinces, {map.States.Count} states, {map.CountryList.Count} countries, {map.Width}x{map.Height}");
Check(map.Provinces.Length > 100, "provinces loaded");
Check(map.States.Count > 10, "states loaded");
Check(map.CountryList.Count > 10, "countries loaded");

int land = 0, noState = 0, noEdges = 0, namedLand = 0;
for (int i = 1; i < map.Provinces.Length; i++)
{
    var pr = map.Provinces[i];
    if (!pr.IsLand) continue;
    land++;
    if (pr.StateId == 0) noState++;
    if (pr.Edges.Count == 0) noEdges++;
    if (!string.IsNullOrEmpty(pr.Name)) namedLand++;
}
Check(noState == 0, $"every land province belongs to a state ({noState} do not)");
Check(noEdges < land / 50 + 1, $"almost every land province has neighbours ({noEdges} isolated)");
Check(namedLand == land, $"every land province has a name ({namedLand}/{land})");
Check(map.States.Values.All(s => s.Owner.Length > 0 && map.CountryOf(s.Owner) != null), "every state has a known owner");
Check(map.CountryList.Select(c => c.Index).Distinct().Count() == map.CountryList.Count, "country indices are unique");
Check(map.CountryList.Count <= 255, "country count fits the shader (<= 255)");
Check(map.ColorToId.Count == map.Provinces.Length - 1, "province colours are unique");

// ---------------------------------------------------------------- mods
Console.WriteLine("\n[mods]");
var modFs = ModFileSystem.Create(dataRoot, new[] { "example_mod" });
if (modFs.Mods.Count > 1)
{
    var modMap = MapData.Load(modFs);
    Check(modMap.CountryOf("USA")?.Name == "United States of Example", "mod renames USA through descriptor/load order");
    Check(modMap.States.TryGetValue(1, out var s1) && s1.Name == "Example Renamed State", "mod localisation overrides base localisation");
}
else Console.WriteLine("  (no example_mod found, skipped)");

// ---------------------------------------------------------------- pathfinding
Console.WriteLine("\n[pathfinding]");
var rng = new Random(7);
int found = 0, tried = 0;
foreach (var c in map.CountryList.OrderByDescending(c => map.StatesOf(c.Tag).Sum(s => s.Provinces.Count)).Take(5))
{
    var provs = map.StatesOf(c.Tag).SelectMany(s => s.Provinces).Where(id => map.Provinces[id].IsLand).ToList();
    if (provs.Count < 4) continue;
    for (int k = 0; k < 20; k++)
    {
        int a = provs[rng.Next(provs.Count)], b = provs[rng.Next(provs.Count)];
        tried++;
        var path = Pathfinder.FindPath(map, a, b, _ => true);
        if (path != null) { found++; if (a != b && path.Last() != b) { Check(false, "path ends at target"); } }
    }
}
Check(tried > 0 && found >= tried * 0.5, $"paths found inside big countries: {found}/{tried}");

// ---------------------------------------------------------------- scenario round trip
Console.WriteLine("\n[scenario file]");
var tmp = Path.Combine(Path.GetTempPath(), "hoisharp_smoke_" + Guid.NewGuid().ToString("N") + ".txt");
var orig = new Scenario
{
    Id = "rt", Name = "Round \"Trip\"", Description = "Line one\nline two", StartDate = new DateTime(1939, 9, 1),
    Player = "DEU", ClearDefaultArmies = true,
};
orig.Countries["XYZ"] = new CountryDef { Tag = "XYZ", Name = "Xyzland", HasColor = true, R = 10, G = 120, B = 200 };
orig.StateOwners[12] = "XYZ";
orig.Wars.Add(new WarDef("DEU", "POL"));
orig.Armies.Add(new ArmyDef("DEU", 5, 80));
orig.Save(tmp);
var back = Scenario.Load(tmp);
File.Delete(tmp);
Check(back.Name == "Round 'Trip'", "name survives (quotes replaced)");
Check(back.StartDate == new DateTime(1939, 9, 1), "date survives");
Check(back.Player == "DEU" && back.ClearDefaultArmies, "player and flags survive");
Check(back.Countries["XYZ"].R == 10 && back.Countries["XYZ"].Name == "Xyzland", "country definition survives");
Check(back.StateOwners[12] == "XYZ" && back.Wars.Count == 1 && back.Armies[0].Strength == 80, "owners, wars, armies survive");
Check(ScenarioLibrary.MakeId("Eastern Front '39!") == "eastern_front_39", "scenario id from name");

// ---------------------------------------------------------------- shipped scenarios + simulation
Console.WriteLine("\n[scenarios and simulation]");
var scenarios = ScenarioLibrary.Discover(fs, dataRoot);
Check(scenarios.Count > 0, $"scenarios discovered: {string.Join(", ", scenarios.Select(s => s.Id))}");

foreach (var file in scenarios.Where(s => !s.IsUser))
{
    var m = MapData.Load(ModFileSystem.Create(dataRoot, Array.Empty<string>()));
    var sc = Scenario.Load(file.Path);
    var warnings = ScenarioApplier.Apply(m, sc);
    Check(warnings.Count == 0, $"{file.Id}: applies without warnings" + (warnings.Count > 0 ? " -> " + warnings[0] : ""));

    var w = new GameWorld(m, sc.StartDate ?? new DateTime(1936, 1, 1));
    string player = sc.Player ?? m.CountryList[0].Tag;
    w.Initialize(player, sc);
    Check(sc.Wars.All(x => w.AtWar(x.Attacker, x.Defender)), $"{file.Id}: scenario wars exist at start");
    Check(w.Armies.Count >= sc.Armies.Count, $"{file.Id}: armies spawned ({w.Armies.Count})");

    var captured = 0;
    w.MapChanged += () => captured++;
    var t = Stopwatch.StartNew();
    try
    {
        for (int d = 0; d < 365; d++) w.TickDay();
        Check(true, $"{file.Id}: simulated 365 days in {t.ElapsedMilliseconds} ms, {w.Wars.Count} wars, {w.Armies.Count} armies, map changed {captured}x");
    }
    catch (Exception ex)
    {
        Check(false, $"{file.Id}: simulation threw {ex.GetType().Name}: {ex.Message}");
    }
}

// free play world, long run
{
    var m = MapData.Load(ModFileSystem.Create(dataRoot, Array.Empty<string>()));
    var w = new GameWorld(m, new DateTime(1936, 1, 1));
    w.Initialize(m.CountryList[0].Tag);
    try
    {
        for (int d = 0; d < 365 * 3; d++) w.TickDay();
        Check(true, $"free play: 3 years simulated, {w.Wars.Count} wars, {w.Armies.Count} armies");
    }
    catch (Exception ex)
    {
        Check(false, "free play simulation threw " + ex);
    }

    // builder-style editing
    var us = m.CountryList.First(c => c.Tag == "USA");
    var fr = m.CountryList.First(c => c.Tag != "USA");
    var st = m.StatesOf(fr.Tag).First();
    Check(w.SetStateOwner(st.Id, us.Tag) && st.Owner == us.Tag && st.BaseOwner == fr.Tag, "builder: give a state to another country (BaseOwner kept)");
    var nc = m.AddCountry("QQQ", "Qqqland", ScenarioApplier.DefaultColor("QQQ"));
    Check(nc.Index == m.CountryList.Count && m.CountryOf("qqq") == nc, "builder: new country gets an index");
    int before = w.Armies.Count;
    var provId = m.StatesOf(us.Tag).SelectMany(s => s.Provinces).First(id => m.Provinces[id].IsLand);
    Check(w.AddArmy("QQQ", provId) != null && w.Armies.Count == before + 1 && w.RemoveArmiesAt(provId) >= 1, "builder: add and remove armies");
}

Console.WriteLine("\n[events]");
var evs = ScriptedEvent.LoadAll(fs);
Check(evs.Any(e => e.Id == "hoisharp.1" && e.Date == new DateTime(1936, 1, 2) && e.Options.Count == 2 && e.Options[1].Effects.Count == 1), $"example event loads ({evs.Count} events)");
Check(File.Exists(Path.Combine(dataRoot, "mod_base", "gui", "event_frame.png")) && File.Exists(Path.Combine(dataRoot, "mod_base", "gui", "leader_frame.png")), "gui frame sprites present");

Console.WriteLine("\n[logging and updates]");
Check(AppVersion.IsNewer("1.2.10", "1.2.9") && !AppVersion.IsNewer("1.2", "1.2.0") && AppVersion.IsNewer("v0.3.0", "0.2.0"), "version comparison");
// simulate a previous run that died hard: marker with a dead pid
Directory.CreateDirectory(AppPaths.LogsDir);
File.WriteAllText(Path.Combine(AppPaths.LogsDir, "smoke.running"), "999999\nmissing_previous.log");
AppLog.Init("smoke");
Check(AppLog.PreviousRunCrashReport != null && File.Exists(AppLog.PreviousRunCrashReport), "a run that never exited cleanly is reported at the next start");
if (AppLog.PreviousRunCrashReport != null) File.Delete(AppLog.PreviousRunCrashReport);
AppLog.MarkCleanExit();
Check(!File.Exists(Path.Combine(AppPaths.LogsDir, "smoke.running")), "clean exit removes the marker");
AppLog.Info("smoke test log line");
var crashPath = AppLog.WriteCrash(new InvalidOperationException("test crash"), "Smoke test");
Check(AppLog.CurrentLogFile != null && File.Exists(AppLog.CurrentLogFile), "log file created in logs/");
Check(crashPath != null && File.ReadAllText(crashPath).Contains("smoke test log line"), "crash report written with recent log lines");
if (crashPath != null) File.Delete(crashPath);
if (AppLog.CurrentLogFile != null) File.Delete(AppLog.CurrentLogFile);
Check((await Updater.CheckAsync(new UpdateSettings())) == null, "update check is off without a manifest url");

Console.WriteLine(failures == 0 ? "\nALL CHECKS PASSED" : $"\n{failures} CHECK(S) FAILED");
return failures == 0 ? 0 : 1;
