@echo off
setlocal EnableDelayedExpansion
cd /d "%~dp0"

rem ===========================================================================
rem  HoiSharp - one click build and run.
rem    run.bat            build if needed, open the launcher
rem    run.bat game       skip the launcher, start the game (extra arguments are passed on)
rem    run.bat builder    start the game in scenario builder mode
rem    run.bat 3d         start the game in the 2.5D view
rem    run.bat rebuild    force a rebuild
rem  If no .NET 8 SDK is installed, a private copy is downloaded into .\.dotnet
rem  (from dot.net, about 200 MB, nothing is installed system wide).
rem ===========================================================================

set "DOTNET_CLI_TELEMETRY_OPTOUT=1"
set "DOTNET_NOLOGO=1"
set "MODE=%~1"
set "OUT=%~dp0out"

rem ---- 1. find or install the .NET SDK (8 or newer)
set "DN="
for /f "tokens=1 delims=." %%v in ('dotnet --version 2^>nul') do set "MAJOR=%%v"
if defined MAJOR if !MAJOR! GEQ 8 set "DN=dotnet"

if not defined DN if exist "%~dp0.dotnet\dotnet.exe" (
  set "DOTNET_ROOT=%~dp0.dotnet"
  set "PATH=%~dp0.dotnet;%PATH%"
  set "DN=%~dp0.dotnet\dotnet.exe"
)

if not defined DN (
  echo No .NET 8 SDK found. Downloading a private copy into .dotnet ...
  powershell -NoProfile -ExecutionPolicy Bypass -Command "[Net.ServicePointManager]::SecurityProtocol=[Net.SecurityProtocolType]::Tls12; Invoke-WebRequest https://dot.net/v1/dotnet-install.ps1 -OutFile '%~dp0dotnet-install.ps1'"
  if errorlevel 1 goto :nodotnet
  powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0dotnet-install.ps1" -Channel 8.0 -InstallDir "%~dp0.dotnet"
  if errorlevel 1 goto :nodotnet
  set "DOTNET_ROOT=%~dp0.dotnet"
  set "PATH=%~dp0.dotnet;%PATH%"
  set "DN=%~dp0.dotnet\dotnet.exe"
)

rem ---- 2. map data (shipped; only generated when missing)
if not exist "data\mod_base\map\provinces.png" (
  echo Map data is missing, generating it with Python ...
  py -3 -m pip install pillow numpy scipy scikit-image
  py -3 tools\mapgen.py
  if errorlevel 1 goto :nodata
)

rem ---- 3. build when needed
set "NEEDBUILD="
if /i "%MODE%"=="rebuild" set "NEEDBUILD=1"
if not exist "%OUT%\HoiSharp.exe" set "NEEDBUILD=1"
if not exist "%OUT%\HoiSharpLauncher.exe" set "NEEDBUILD=1"

if defined NEEDBUILD (
  echo Building HoiSharp ...
  "%DN%" tool restore
  if errorlevel 1 goto :buildfail
  "%DN%" build src\HoiSharp.Game\HoiSharp.Game.csproj -c Release -o "%OUT%"
  if errorlevel 1 goto :buildfail
  "%DN%" build src\HoiSharp.Launcher\HoiSharp.Launcher.csproj -c Release -o "%OUT%"
  if errorlevel 1 goto :buildfail
)

rem ---- 4. run
if /i "%MODE%"=="game" (
  shift
  "%OUT%\HoiSharp.exe" %1 %2 %3 %4 %5 %6 %7 %8 %9
  goto :eof
)
if /i "%MODE%"=="builder" ( "%OUT%\HoiSharp.exe" --builder & goto :eof )
if /i "%MODE%"=="3d" ( "%OUT%\HoiSharp.exe" --3d & goto :eof )
start "" "%OUT%\HoiSharpLauncher.exe"
goto :eof

:nodotnet
echo.
echo Could not download .NET. Install the .NET 8 SDK from https://dotnet.microsoft.com/download/dotnet/8.0 and run this file again.
pause
exit /b 1

:nodata
echo.
echo Could not generate the map data. See README.md.
pause
exit /b 1

:buildfail
echo.
echo Build failed. The messages above say why. Copy them if you want help.
pause
exit /b 1
