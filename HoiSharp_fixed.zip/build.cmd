@echo off
rem Same as run.bat rebuild, but does not start anything.
call "%~dp0run.bat" rebuild
